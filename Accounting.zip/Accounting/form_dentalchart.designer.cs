﻿namespace Accounting
{
    partial class form_dentalchart
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.Label label3;
            System.Windows.Forms.Label label5;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(form_dentalchart));
            this.treatment_id = new System.Windows.Forms.Label();
            this.panel_chart = new System.Windows.Forms.Panel();
            this.L30 = new System.Windows.Forms.CheckBox();
            this.L24 = new System.Windows.Forms.CheckBox();
            this.L22 = new System.Windows.Forms.CheckBox();
            this.L29 = new System.Windows.Forms.CheckBox();
            this.L25 = new System.Windows.Forms.CheckBox();
            this.U5 = new System.Windows.Forms.CheckBox();
            this.L23 = new System.Windows.Forms.CheckBox();
            this.L26 = new System.Windows.Forms.CheckBox();
            this.U6 = new System.Windows.Forms.CheckBox();
            this.U10 = new System.Windows.Forms.CheckBox();
            this.L27 = new System.Windows.Forms.CheckBox();
            this.U7 = new System.Windows.Forms.CheckBox();
            this.U11 = new System.Windows.Forms.CheckBox();
            this.L28 = new System.Windows.Forms.CheckBox();
            this.U8 = new System.Windows.Forms.CheckBox();
            this.U12 = new System.Windows.Forms.CheckBox();
            this.U3 = new System.Windows.Forms.CheckBox();
            this.U9 = new System.Windows.Forms.CheckBox();
            this.U13 = new System.Windows.Forms.CheckBox();
            this.L31 = new System.Windows.Forms.CheckBox();
            this.L21 = new System.Windows.Forms.CheckBox();
            this.U14 = new System.Windows.Forms.CheckBox();
            this.U4 = new System.Windows.Forms.CheckBox();
            this.L20 = new System.Windows.Forms.CheckBox();
            this.U15 = new System.Windows.Forms.CheckBox();
            this.U2 = new System.Windows.Forms.CheckBox();
            this.L19 = new System.Windows.Forms.CheckBox();
            this.U16 = new System.Windows.Forms.CheckBox();
            this.U1 = new System.Windows.Forms.CheckBox();
            this.L17 = new System.Windows.Forms.CheckBox();
            this.L18 = new System.Windows.Forms.CheckBox();
            this.L32 = new System.Windows.Forms.CheckBox();
            this.L = new System.Windows.Forms.PictureBox();
            this.button_edit = new Bunifu.Framework.UI.BunifuFlatButton();
            this.toothcnt = new System.Windows.Forms.TextBox();
            this.resetbut = new Bunifu.Framework.UI.BunifuFlatButton();
            this.textBox_grandtotal = new System.Windows.Forms.TextBox();
            this.textBox_Charges = new System.Windows.Forms.TextBox();
            this.grandtotal = new System.Windows.Forms.Label();
            this.charges = new System.Windows.Forms.Label();
            this.textBox_toothinv = new System.Windows.Forms.TextBox();
            this.toothinvolved = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.scd_dte = new System.Windows.Forms.DateTimePicker();
            this.label35 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.appid = new System.Windows.Forms.TextBox();
            this.patn = new System.Windows.Forms.TextBox();
            this.patid = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.ptn_lst_pnl = new System.Windows.Forms.Panel();
            this.scd_id = new System.Windows.Forms.Label();
            this.ptn_nme = new System.Windows.Forms.TextBox();
            this.sched_id1 = new System.Windows.Forms.Label();
            this.closeb = new System.Windows.Forms.Button();
            this.ptn_grid = new System.Windows.Forms.DataGridView();
            this.ptn_add = new System.Windows.Forms.Button();
            this.label21 = new System.Windows.Forms.Label();
            this.pr_id = new System.Windows.Forms.Label();
            this.groupBox_dccash = new System.Windows.Forms.GroupBox();
            this.button_pay = new System.Windows.Forms.Button();
            this.button_paycash = new System.Windows.Forms.Button();
            this.textBox_total_paid = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.treatmentcash = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.grandtotalcash = new System.Windows.Forms.TextBox();
            this.chargescash = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.toothinvcash = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.dccashid = new System.Windows.Forms.Label();
            this.dccheckid = new System.Windows.Forms.Label();
            this.button_finalizecash = new Bunifu.Framework.UI.BunifuFlatButton();
            this.panel_pay = new System.Windows.Forms.Panel();
            this.balance = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.date_pdc = new System.Windows.Forms.DateTimePicker();
            this.label_pdc = new System.Windows.Forms.Label();
            this.comboBox_bank = new System.Windows.Forms.ComboBox();
            this.label_bank = new System.Windows.Forms.Label();
            this.dptdue = new System.Windows.Forms.DateTimePicker();
            this.paymentdue = new System.Windows.Forms.Label();
            this.textBox_amntpaid = new System.Windows.Forms.TextBox();
            this.llabel = new System.Windows.Forms.Label();
            this.checknumber = new System.Windows.Forms.Label();
            this.textBox_Checknumber = new System.Windows.Forms.TextBox();
            this.bunifuFlatButton1 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.comboBox_Type = new System.Windows.Forms.ComboBox();
            this.label32 = new System.Windows.Forms.Label();
            this.comboBox_mode = new System.Windows.Forms.ComboBox();
            this.label27 = new System.Windows.Forms.Label();
            this.trt_grd = new System.Windows.Forms.DataGridView();
            this.textBox_trtment1 = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.button_Addcheck = new Bunifu.Framework.UI.BunifuFlatButton();
            this.panel_Check = new System.Windows.Forms.Panel();
            this.panel_pay2 = new System.Windows.Forms.Panel();
            this.button_cancel_pay = new Bunifu.Framework.UI.BunifuFlatButton();
            this.button_pay2 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.textBox_change = new System.Windows.Forms.TextBox();
            this.lllabel = new System.Windows.Forms.Label();
            this.summary_grd = new System.Windows.Forms.DataGridView();
            this.label6 = new System.Windows.Forms.Label();
            this.trt_chart = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.amnt_due = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.button_inventory = new Bunifu.Framework.UI.BunifuFlatButton();
            this.panel_inv = new System.Windows.Forms.Panel();
            this.label_label = new System.Windows.Forms.Label();
            this.label_inv = new System.Windows.Forms.Label();
            this.label_inv_id = new System.Windows.Forms.Label();
            this.label_expirey = new System.Windows.Forms.Label();
            this.box_expiry = new System.Windows.Forms.DateTimePicker();
            this.button_cancel_inv = new Bunifu.Framework.UI.BunifuFlatButton();
            this.label_quant = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label_desc = new System.Windows.Forms.Label();
            this.label_item = new System.Windows.Forms.Label();
            this.button_deduct = new Bunifu.Framework.UI.BunifuThinButton2();
            this.button_add = new Bunifu.Framework.UI.BunifuThinButton2();
            this.label_desription = new System.Windows.Forms.Label();
            this.label_inventory_name = new System.Windows.Forms.Label();
            this.dataGridView_inventory = new System.Windows.Forms.DataGridView();
            this.button_finish = new Bunifu.Framework.UI.BunifuFlatButton();
            this.panel_alert = new System.Windows.Forms.Panel();
            this.button_check_inv = new Bunifu.Framework.UI.BunifuFlatButton();
            this.label7 = new System.Windows.Forms.Label();
            this.button_yes = new Bunifu.Framework.UI.BunifuFlatButton();
            this.label_unq = new System.Windows.Forms.Label();
            label3 = new System.Windows.Forms.Label();
            label5 = new System.Windows.Forms.Label();
            this.panel_chart.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.L)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.ptn_lst_pnl.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ptn_grid)).BeginInit();
            this.groupBox_dccash.SuspendLayout();
            this.panel_pay.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trt_grd)).BeginInit();
            this.panel_Check.SuspendLayout();
            this.panel_pay2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.summary_grd)).BeginInit();
            this.panel_inv.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_inventory)).BeginInit();
            this.panel_alert.SuspendLayout();
            this.SuspendLayout();
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label3.ForeColor = System.Drawing.Color.Black;
            label3.Location = new System.Drawing.Point(36, 53);
            label3.Name = "label3";
            label3.Size = new System.Drawing.Size(93, 20);
            label3.TabIndex = 268;
            label3.Text = "Patient ID :";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label5.ForeColor = System.Drawing.Color.Black;
            label5.Location = new System.Drawing.Point(35, 20);
            label5.Name = "label5";
            label5.Size = new System.Drawing.Size(134, 20);
            label5.TabIndex = 338;
            label5.Text = "Appointment ID :";
            // 
            // treatment_id
            // 
            this.treatment_id.AutoSize = true;
            this.treatment_id.Location = new System.Drawing.Point(1080, 9);
            this.treatment_id.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.treatment_id.Name = "treatment_id";
            this.treatment_id.Size = new System.Drawing.Size(40, 17);
            this.treatment_id.TabIndex = 353;
            this.treatment_id.Text = "trt_id";
            this.treatment_id.Visible = false;
            // 
            // panel_chart
            // 
            this.panel_chart.Controls.Add(this.L30);
            this.panel_chart.Controls.Add(this.L24);
            this.panel_chart.Controls.Add(this.L22);
            this.panel_chart.Controls.Add(this.L29);
            this.panel_chart.Controls.Add(this.L25);
            this.panel_chart.Controls.Add(this.U5);
            this.panel_chart.Controls.Add(this.L23);
            this.panel_chart.Controls.Add(this.L26);
            this.panel_chart.Controls.Add(this.U6);
            this.panel_chart.Controls.Add(this.U10);
            this.panel_chart.Controls.Add(this.L27);
            this.panel_chart.Controls.Add(this.U7);
            this.panel_chart.Controls.Add(this.U11);
            this.panel_chart.Controls.Add(this.L28);
            this.panel_chart.Controls.Add(this.U8);
            this.panel_chart.Controls.Add(this.U12);
            this.panel_chart.Controls.Add(this.U3);
            this.panel_chart.Controls.Add(this.U9);
            this.panel_chart.Controls.Add(this.U13);
            this.panel_chart.Controls.Add(this.L31);
            this.panel_chart.Controls.Add(this.L21);
            this.panel_chart.Controls.Add(this.U14);
            this.panel_chart.Controls.Add(this.U4);
            this.panel_chart.Controls.Add(this.L20);
            this.panel_chart.Controls.Add(this.U15);
            this.panel_chart.Controls.Add(this.U2);
            this.panel_chart.Controls.Add(this.L19);
            this.panel_chart.Controls.Add(this.U16);
            this.panel_chart.Controls.Add(this.U1);
            this.panel_chart.Controls.Add(this.L17);
            this.panel_chart.Controls.Add(this.L18);
            this.panel_chart.Controls.Add(this.L32);
            this.panel_chart.Controls.Add(this.L);
            this.panel_chart.Location = new System.Drawing.Point(507, 4);
            this.panel_chart.Margin = new System.Windows.Forms.Padding(4);
            this.panel_chart.Name = "panel_chart";
            this.panel_chart.Size = new System.Drawing.Size(500, 561);
            this.panel_chart.TabIndex = 360;
            this.panel_chart.Visible = false;
            // 
            // L30
            // 
            this.L30.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.L30.AutoSize = true;
            this.L30.Location = new System.Drawing.Point(95, 366);
            this.L30.Margin = new System.Windows.Forms.Padding(4);
            this.L30.Name = "L30";
            this.L30.Size = new System.Drawing.Size(18, 17);
            this.L30.TabIndex = 243;
            this.L30.UseVisualStyleBackColor = true;
            this.L30.CheckedChanged += new System.EventHandler(this.L30_CheckedChanged);
            // 
            // L24
            // 
            this.L24.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.L24.AutoSize = true;
            this.L24.Location = new System.Drawing.Point(256, 466);
            this.L24.Margin = new System.Windows.Forms.Padding(4);
            this.L24.Name = "L24";
            this.L24.Size = new System.Drawing.Size(18, 17);
            this.L24.TabIndex = 222;
            this.L24.UseVisualStyleBackColor = true;
            this.L24.CheckedChanged += new System.EventHandler(this.L24_CheckedChanged);
            // 
            // L22
            // 
            this.L22.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.L22.AutoSize = true;
            this.L22.Location = new System.Drawing.Point(312, 449);
            this.L22.Margin = new System.Windows.Forms.Padding(4);
            this.L22.Name = "L22";
            this.L22.Size = new System.Drawing.Size(18, 17);
            this.L22.TabIndex = 223;
            this.L22.UseVisualStyleBackColor = true;
            this.L22.CheckedChanged += new System.EventHandler(this.L22_CheckedChanged);
            // 
            // L29
            // 
            this.L29.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.L29.AutoSize = true;
            this.L29.Location = new System.Drawing.Point(113, 398);
            this.L29.Margin = new System.Windows.Forms.Padding(4);
            this.L29.Name = "L29";
            this.L29.Size = new System.Drawing.Size(18, 17);
            this.L29.TabIndex = 242;
            this.L29.UseVisualStyleBackColor = true;
            this.L29.CheckedChanged += new System.EventHandler(this.L29_CheckedChanged);
            // 
            // L25
            // 
            this.L25.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.L25.AutoSize = true;
            this.L25.Location = new System.Drawing.Point(225, 468);
            this.L25.Margin = new System.Windows.Forms.Padding(4);
            this.L25.Name = "L25";
            this.L25.Size = new System.Drawing.Size(18, 17);
            this.L25.TabIndex = 221;
            this.L25.UseVisualStyleBackColor = true;
            this.L25.CheckedChanged += new System.EventHandler(this.L25_CheckedChanged);
            // 
            // U5
            // 
            this.U5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.U5.AutoSize = true;
            this.U5.Location = new System.Drawing.Point(125, 117);
            this.U5.Margin = new System.Windows.Forms.Padding(4);
            this.U5.Name = "U5";
            this.U5.Size = new System.Drawing.Size(18, 17);
            this.U5.TabIndex = 224;
            this.U5.UseVisualStyleBackColor = true;
            this.U5.CheckedChanged += new System.EventHandler(this.U5_CheckedChanged);
            // 
            // L23
            // 
            this.L23.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.L23.AutoSize = true;
            this.L23.Location = new System.Drawing.Point(287, 460);
            this.L23.Margin = new System.Windows.Forms.Padding(4);
            this.L23.Name = "L23";
            this.L23.Size = new System.Drawing.Size(18, 17);
            this.L23.TabIndex = 241;
            this.L23.UseVisualStyleBackColor = true;
            this.L23.CheckedChanged += new System.EventHandler(this.L23_CheckedChanged);
            // 
            // L26
            // 
            this.L26.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.L26.AutoSize = true;
            this.L26.Location = new System.Drawing.Point(192, 462);
            this.L26.Margin = new System.Windows.Forms.Padding(4);
            this.L26.Name = "L26";
            this.L26.Size = new System.Drawing.Size(18, 17);
            this.L26.TabIndex = 220;
            this.L26.UseVisualStyleBackColor = true;
            this.L26.CheckedChanged += new System.EventHandler(this.L26_CheckedChanged);
            // 
            // U6
            // 
            this.U6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.U6.AutoSize = true;
            this.U6.Location = new System.Drawing.Point(145, 94);
            this.U6.Margin = new System.Windows.Forms.Padding(4);
            this.U6.Name = "U6";
            this.U6.Size = new System.Drawing.Size(18, 17);
            this.U6.TabIndex = 225;
            this.U6.UseVisualStyleBackColor = true;
            this.U6.CheckedChanged += new System.EventHandler(this.U6_CheckedChanged);
            // 
            // U10
            // 
            this.U10.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.U10.AutoSize = true;
            this.U10.Location = new System.Drawing.Point(300, 76);
            this.U10.Margin = new System.Windows.Forms.Padding(4);
            this.U10.Name = "U10";
            this.U10.Size = new System.Drawing.Size(18, 17);
            this.U10.TabIndex = 240;
            this.U10.UseVisualStyleBackColor = true;
            this.U10.CheckedChanged += new System.EventHandler(this.U10_CheckedChanged);
            // 
            // L27
            // 
            this.L27.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.L27.AutoSize = true;
            this.L27.Location = new System.Drawing.Point(167, 449);
            this.L27.Margin = new System.Windows.Forms.Padding(4);
            this.L27.Name = "L27";
            this.L27.Size = new System.Drawing.Size(18, 17);
            this.L27.TabIndex = 219;
            this.L27.UseVisualStyleBackColor = true;
            this.L27.CheckedChanged += new System.EventHandler(this.L27_CheckedChanged);
            // 
            // U7
            // 
            this.U7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.U7.AutoSize = true;
            this.U7.Location = new System.Drawing.Point(176, 76);
            this.U7.Margin = new System.Windows.Forms.Padding(4);
            this.U7.Name = "U7";
            this.U7.Size = new System.Drawing.Size(18, 17);
            this.U7.TabIndex = 226;
            this.U7.UseVisualStyleBackColor = true;
            this.U7.CheckedChanged += new System.EventHandler(this.U7_CheckedChanged);
            // 
            // U11
            // 
            this.U11.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.U11.AutoSize = true;
            this.U11.Location = new System.Drawing.Point(328, 96);
            this.U11.Margin = new System.Windows.Forms.Padding(4);
            this.U11.Name = "U11";
            this.U11.Size = new System.Drawing.Size(18, 17);
            this.U11.TabIndex = 239;
            this.U11.UseVisualStyleBackColor = true;
            this.U11.CheckedChanged += new System.EventHandler(this.U11_CheckedChanged);
            // 
            // L28
            // 
            this.L28.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.L28.AutoSize = true;
            this.L28.Location = new System.Drawing.Point(143, 427);
            this.L28.Margin = new System.Windows.Forms.Padding(4);
            this.L28.Name = "L28";
            this.L28.Size = new System.Drawing.Size(18, 17);
            this.L28.TabIndex = 218;
            this.L28.UseVisualStyleBackColor = true;
            this.L28.CheckedChanged += new System.EventHandler(this.L28_CheckedChanged);
            // 
            // U8
            // 
            this.U8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.U8.AutoSize = true;
            this.U8.Location = new System.Drawing.Point(215, 66);
            this.U8.Margin = new System.Windows.Forms.Padding(4);
            this.U8.Name = "U8";
            this.U8.Size = new System.Drawing.Size(18, 17);
            this.U8.TabIndex = 227;
            this.U8.UseVisualStyleBackColor = true;
            this.U8.CheckedChanged += new System.EventHandler(this.U8_CheckedChanged);
            // 
            // U12
            // 
            this.U12.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.U12.AutoSize = true;
            this.U12.Location = new System.Drawing.Point(347, 122);
            this.U12.Margin = new System.Windows.Forms.Padding(4);
            this.U12.Name = "U12";
            this.U12.Size = new System.Drawing.Size(18, 17);
            this.U12.TabIndex = 238;
            this.U12.UseVisualStyleBackColor = true;
            this.U12.CheckedChanged += new System.EventHandler(this.U12_CheckedChanged);
            // 
            // U3
            // 
            this.U3.AutoSize = true;
            this.U3.Location = new System.Drawing.Point(91, 175);
            this.U3.Margin = new System.Windows.Forms.Padding(4);
            this.U3.Name = "U3";
            this.U3.Size = new System.Drawing.Size(18, 17);
            this.U3.TabIndex = 217;
            this.U3.UseVisualStyleBackColor = true;
            this.U3.CheckedChanged += new System.EventHandler(this.U3_CheckedChanged);
            // 
            // U9
            // 
            this.U9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.U9.AutoSize = true;
            this.U9.Location = new System.Drawing.Point(259, 65);
            this.U9.Margin = new System.Windows.Forms.Padding(4);
            this.U9.Name = "U9";
            this.U9.Size = new System.Drawing.Size(18, 17);
            this.U9.TabIndex = 228;
            this.U9.UseVisualStyleBackColor = true;
            this.U9.CheckedChanged += new System.EventHandler(this.U9_CheckedChanged);
            // 
            // U13
            // 
            this.U13.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.U13.AutoSize = true;
            this.U13.Location = new System.Drawing.Point(369, 148);
            this.U13.Margin = new System.Windows.Forms.Padding(4);
            this.U13.Name = "U13";
            this.U13.Size = new System.Drawing.Size(18, 17);
            this.U13.TabIndex = 237;
            this.U13.UseVisualStyleBackColor = true;
            this.U13.CheckedChanged += new System.EventHandler(this.U13_CheckedChanged);
            // 
            // L31
            // 
            this.L31.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.L31.AutoSize = true;
            this.L31.Location = new System.Drawing.Point(85, 331);
            this.L31.Margin = new System.Windows.Forms.Padding(4);
            this.L31.Name = "L31";
            this.L31.Size = new System.Drawing.Size(18, 17);
            this.L31.TabIndex = 216;
            this.L31.UseVisualStyleBackColor = true;
            this.L31.CheckedChanged += new System.EventHandler(this.L31_CheckedChanged);
            // 
            // L21
            // 
            this.L21.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.L21.AutoSize = true;
            this.L21.Location = new System.Drawing.Point(336, 426);
            this.L21.Margin = new System.Windows.Forms.Padding(4);
            this.L21.Name = "L21";
            this.L21.Size = new System.Drawing.Size(18, 17);
            this.L21.TabIndex = 229;
            this.L21.UseVisualStyleBackColor = true;
            this.L21.CheckedChanged += new System.EventHandler(this.L21_CheckedChanged);
            // 
            // U14
            // 
            this.U14.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.U14.AutoSize = true;
            this.U14.Location = new System.Drawing.Point(384, 178);
            this.U14.Margin = new System.Windows.Forms.Padding(4);
            this.U14.Name = "U14";
            this.U14.Size = new System.Drawing.Size(18, 17);
            this.U14.TabIndex = 236;
            this.U14.UseVisualStyleBackColor = true;
            this.U14.CheckedChanged += new System.EventHandler(this.U14_CheckedChanged);
            // 
            // U4
            // 
            this.U4.AutoSize = true;
            this.U4.Location = new System.Drawing.Point(107, 144);
            this.U4.Margin = new System.Windows.Forms.Padding(4);
            this.U4.Name = "U4";
            this.U4.Size = new System.Drawing.Size(18, 17);
            this.U4.TabIndex = 215;
            this.U4.UseVisualStyleBackColor = true;
            this.U4.CheckedChanged += new System.EventHandler(this.U4_CheckedChanged);
            // 
            // L20
            // 
            this.L20.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.L20.AutoSize = true;
            this.L20.Location = new System.Drawing.Point(364, 395);
            this.L20.Margin = new System.Windows.Forms.Padding(4);
            this.L20.Name = "L20";
            this.L20.Size = new System.Drawing.Size(18, 17);
            this.L20.TabIndex = 230;
            this.L20.UseVisualStyleBackColor = true;
            this.L20.CheckedChanged += new System.EventHandler(this.L20_CheckedChanged);
            // 
            // U15
            // 
            this.U15.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.U15.AutoSize = true;
            this.U15.Location = new System.Drawing.Point(392, 212);
            this.U15.Margin = new System.Windows.Forms.Padding(4);
            this.U15.Name = "U15";
            this.U15.Size = new System.Drawing.Size(18, 17);
            this.U15.TabIndex = 235;
            this.U15.UseVisualStyleBackColor = true;
            this.U15.CheckedChanged += new System.EventHandler(this.U15_CheckedChanged);
            // 
            // U2
            // 
            this.U2.AutoSize = true;
            this.U2.Location = new System.Drawing.Point(81, 204);
            this.U2.Margin = new System.Windows.Forms.Padding(4);
            this.U2.Name = "U2";
            this.U2.Size = new System.Drawing.Size(18, 17);
            this.U2.TabIndex = 214;
            this.U2.UseVisualStyleBackColor = true;
            this.U2.CheckedChanged += new System.EventHandler(this.U2_CheckedChanged);
            // 
            // L19
            // 
            this.L19.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.L19.AutoSize = true;
            this.L19.Location = new System.Drawing.Point(387, 363);
            this.L19.Margin = new System.Windows.Forms.Padding(4);
            this.L19.Name = "L19";
            this.L19.Size = new System.Drawing.Size(18, 17);
            this.L19.TabIndex = 231;
            this.L19.UseVisualStyleBackColor = true;
            this.L19.CheckedChanged += new System.EventHandler(this.L19_CheckedChanged);
            // 
            // U16
            // 
            this.U16.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.U16.AutoSize = true;
            this.U16.Location = new System.Drawing.Point(387, 244);
            this.U16.Margin = new System.Windows.Forms.Padding(4);
            this.U16.Name = "U16";
            this.U16.Size = new System.Drawing.Size(18, 17);
            this.U16.TabIndex = 234;
            this.U16.UseVisualStyleBackColor = true;
            this.U16.CheckedChanged += new System.EventHandler(this.U16_CheckedChanged);
            // 
            // U1
            // 
            this.U1.AutoSize = true;
            this.U1.Location = new System.Drawing.Point(81, 240);
            this.U1.Margin = new System.Windows.Forms.Padding(4);
            this.U1.Name = "U1";
            this.U1.Size = new System.Drawing.Size(18, 17);
            this.U1.TabIndex = 213;
            this.U1.UseVisualStyleBackColor = true;
            this.U1.CheckedChanged += new System.EventHandler(this.U1_CheckedChanged);
            // 
            // L17
            // 
            this.L17.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.L17.AutoSize = true;
            this.L17.Location = new System.Drawing.Point(391, 295);
            this.L17.Margin = new System.Windows.Forms.Padding(4);
            this.L17.Name = "L17";
            this.L17.Size = new System.Drawing.Size(18, 17);
            this.L17.TabIndex = 233;
            this.L17.UseVisualStyleBackColor = true;
            this.L17.CheckedChanged += new System.EventHandler(this.L17_CheckedChanged);
            // 
            // L18
            // 
            this.L18.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.L18.AutoSize = true;
            this.L18.Location = new System.Drawing.Point(392, 329);
            this.L18.Margin = new System.Windows.Forms.Padding(4);
            this.L18.Name = "L18";
            this.L18.Size = new System.Drawing.Size(18, 17);
            this.L18.TabIndex = 232;
            this.L18.UseVisualStyleBackColor = true;
            this.L18.CheckedChanged += new System.EventHandler(this.L18_CheckedChanged);
            // 
            // L32
            // 
            this.L32.AutoSize = true;
            this.L32.Location = new System.Drawing.Point(84, 294);
            this.L32.Margin = new System.Windows.Forms.Padding(4);
            this.L32.Name = "L32";
            this.L32.Size = new System.Drawing.Size(18, 17);
            this.L32.TabIndex = 212;
            this.L32.UseVisualStyleBackColor = true;
            this.L32.CheckedChanged += new System.EventHandler(this.L32_CheckedChanged);
            // 
            // L
            // 
            this.L.Image = ((System.Drawing.Image)(resources.GetObject("L.Image")));
            this.L.Location = new System.Drawing.Point(8, 4);
            this.L.Margin = new System.Windows.Forms.Padding(4);
            this.L.Name = "L";
            this.L.Size = new System.Drawing.Size(488, 555);
            this.L.TabIndex = 211;
            this.L.TabStop = false;
            this.L.Click += new System.EventHandler(this.L_Click);
            // 
            // button_edit
            // 
            this.button_edit.Activecolor = System.Drawing.Color.Teal;
            this.button_edit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(229)))), ((int)(((byte)(229)))));
            this.button_edit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button_edit.BorderRadius = 0;
            this.button_edit.ButtonText = "Edit";
            this.button_edit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_edit.DisabledColor = System.Drawing.Color.Gray;
            this.button_edit.Iconcolor = System.Drawing.Color.Transparent;
            this.button_edit.Iconimage = null;
            this.button_edit.Iconimage_right = null;
            this.button_edit.Iconimage_right_Selected = null;
            this.button_edit.Iconimage_Selected = null;
            this.button_edit.IconMarginLeft = 0;
            this.button_edit.IconMarginRight = 0;
            this.button_edit.IconRightVisible = true;
            this.button_edit.IconRightZoom = 0D;
            this.button_edit.IconVisible = true;
            this.button_edit.IconZoom = 70D;
            this.button_edit.IsTab = false;
            this.button_edit.Location = new System.Drawing.Point(721, 411);
            this.button_edit.Margin = new System.Windows.Forms.Padding(5);
            this.button_edit.Name = "button_edit";
            this.button_edit.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(229)))), ((int)(((byte)(229)))));
            this.button_edit.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(216)))), ((int)(((byte)(216)))));
            this.button_edit.OnHoverTextColor = System.Drawing.Color.White;
            this.button_edit.selected = false;
            this.button_edit.Size = new System.Drawing.Size(124, 44);
            this.button_edit.TabIndex = 352;
            this.button_edit.Text = "Edit";
            this.button_edit.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.button_edit.Textcolor = System.Drawing.Color.Black;
            this.button_edit.TextFont = new System.Drawing.Font("Lucida Console", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_edit.Click += new System.EventHandler(this.button_edit_Click);
            // 
            // toothcnt
            // 
            this.toothcnt.Enabled = false;
            this.toothcnt.Location = new System.Drawing.Point(367, 52);
            this.toothcnt.Margin = new System.Windows.Forms.Padding(4);
            this.toothcnt.Name = "toothcnt";
            this.toothcnt.ReadOnly = true;
            this.toothcnt.Size = new System.Drawing.Size(41, 22);
            this.toothcnt.TabIndex = 0;
            // 
            // resetbut
            // 
            this.resetbut.Activecolor = System.Drawing.Color.Teal;
            this.resetbut.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(229)))), ((int)(((byte)(229)))));
            this.resetbut.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.resetbut.BorderRadius = 0;
            this.resetbut.ButtonText = "Reset";
            this.resetbut.Cursor = System.Windows.Forms.Cursors.Hand;
            this.resetbut.DisabledColor = System.Drawing.Color.Gray;
            this.resetbut.Iconcolor = System.Drawing.Color.Transparent;
            this.resetbut.Iconimage = null;
            this.resetbut.Iconimage_right = null;
            this.resetbut.Iconimage_right_Selected = null;
            this.resetbut.Iconimage_Selected = null;
            this.resetbut.IconMarginLeft = 0;
            this.resetbut.IconMarginRight = 0;
            this.resetbut.IconRightVisible = true;
            this.resetbut.IconRightZoom = 0D;
            this.resetbut.IconVisible = true;
            this.resetbut.IconZoom = 70D;
            this.resetbut.IsTab = false;
            this.resetbut.Location = new System.Drawing.Point(268, 167);
            this.resetbut.Margin = new System.Windows.Forms.Padding(5);
            this.resetbut.Name = "resetbut";
            this.resetbut.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(229)))), ((int)(((byte)(229)))));
            this.resetbut.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(216)))), ((int)(((byte)(216)))));
            this.resetbut.OnHoverTextColor = System.Drawing.Color.White;
            this.resetbut.selected = false;
            this.resetbut.Size = new System.Drawing.Size(115, 36);
            this.resetbut.TabIndex = 18;
            this.resetbut.Text = "Reset";
            this.resetbut.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.resetbut.Textcolor = System.Drawing.Color.Black;
            this.resetbut.TextFont = new System.Drawing.Font("Lucida Console", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.resetbut.Click += new System.EventHandler(this.resetbut_Click);
            // 
            // textBox_grandtotal
            // 
            this.textBox_grandtotal.Enabled = false;
            this.textBox_grandtotal.Location = new System.Drawing.Point(157, 117);
            this.textBox_grandtotal.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_grandtotal.Name = "textBox_grandtotal";
            this.textBox_grandtotal.ReadOnly = true;
            this.textBox_grandtotal.Size = new System.Drawing.Size(200, 22);
            this.textBox_grandtotal.TabIndex = 0;
            this.textBox_grandtotal.TextChanged += new System.EventHandler(this.textBox_grandtotal_TextChanged);
            // 
            // textBox_Charges
            // 
            this.textBox_Charges.Enabled = false;
            this.textBox_Charges.Location = new System.Drawing.Point(157, 85);
            this.textBox_Charges.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_Charges.Name = "textBox_Charges";
            this.textBox_Charges.ReadOnly = true;
            this.textBox_Charges.Size = new System.Drawing.Size(200, 22);
            this.textBox_Charges.TabIndex = 0;
            // 
            // grandtotal
            // 
            this.grandtotal.AutoSize = true;
            this.grandtotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grandtotal.Location = new System.Drawing.Point(17, 123);
            this.grandtotal.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.grandtotal.Name = "grandtotal";
            this.grandtotal.Size = new System.Drawing.Size(102, 20);
            this.grandtotal.TabIndex = 8;
            this.grandtotal.Text = "Grand Total:";
            // 
            // charges
            // 
            this.charges.AutoSize = true;
            this.charges.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.charges.Location = new System.Drawing.Point(19, 89);
            this.charges.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.charges.Name = "charges";
            this.charges.Size = new System.Drawing.Size(77, 20);
            this.charges.TabIndex = 7;
            this.charges.Text = "Charges:";
            // 
            // textBox_toothinv
            // 
            this.textBox_toothinv.Enabled = false;
            this.textBox_toothinv.Location = new System.Drawing.Point(157, 52);
            this.textBox_toothinv.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_toothinv.Name = "textBox_toothinv";
            this.textBox_toothinv.ReadOnly = true;
            this.textBox_toothinv.Size = new System.Drawing.Size(200, 22);
            this.textBox_toothinv.TabIndex = 0;
            this.textBox_toothinv.TextChanged += new System.EventHandler(this.textBox_toothinv_TextChanged);
            // 
            // toothinvolved
            // 
            this.toothinvolved.AutoSize = true;
            this.toothinvolved.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toothinvolved.Location = new System.Drawing.Point(17, 54);
            this.toothinvolved.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.toothinvolved.Name = "toothinvolved";
            this.toothinvolved.Size = new System.Drawing.Size(121, 20);
            this.toothinvolved.TabIndex = 5;
            this.toothinvolved.Text = "Tooth Involved:";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.scd_dte);
            this.groupBox3.Controls.Add(this.label35);
            this.groupBox3.Controls.Add(this.button2);
            this.groupBox3.Controls.Add(this.appid);
            this.groupBox3.Controls.Add(label5);
            this.groupBox3.Controls.Add(this.patn);
            this.groupBox3.Controls.Add(this.patid);
            this.groupBox3.Controls.Add(this.label2);
            this.groupBox3.Controls.Add(label3);
            this.groupBox3.Location = new System.Drawing.Point(16, 22);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox3.Size = new System.Drawing.Size(468, 164);
            this.groupBox3.TabIndex = 354;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Patient Info";
            this.groupBox3.Enter += new System.EventHandler(this.groupBox3_Enter);
            // 
            // scd_dte
            // 
            this.scd_dte.Location = new System.Drawing.Point(171, 119);
            this.scd_dte.Margin = new System.Windows.Forms.Padding(4);
            this.scd_dte.Name = "scd_dte";
            this.scd_dte.Size = new System.Drawing.Size(265, 22);
            this.scd_dte.TabIndex = 340;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(36, 119);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(55, 20);
            this.label35.TabIndex = 339;
            this.label35.Text = "Date :";
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(337, 14);
            this.button2.Margin = new System.Windows.Forms.Padding(4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(84, 26);
            this.button2.TabIndex = 337;
            this.button2.Text = "Search";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // appid
            // 
            this.appid.Cursor = System.Windows.Forms.Cursors.Default;
            this.appid.Location = new System.Drawing.Point(172, 14);
            this.appid.Margin = new System.Windows.Forms.Padding(4);
            this.appid.Name = "appid";
            this.appid.ReadOnly = true;
            this.appid.Size = new System.Drawing.Size(147, 22);
            this.appid.TabIndex = 336;
            // 
            // patn
            // 
            this.patn.Location = new System.Drawing.Point(171, 81);
            this.patn.Margin = new System.Windows.Forms.Padding(4);
            this.patn.Name = "patn";
            this.patn.ReadOnly = true;
            this.patn.Size = new System.Drawing.Size(224, 22);
            this.patn.TabIndex = 3;
            // 
            // patid
            // 
            this.patid.Cursor = System.Windows.Forms.Cursors.Default;
            this.patid.Location = new System.Drawing.Point(171, 47);
            this.patid.Margin = new System.Windows.Forms.Padding(4);
            this.patid.Name = "patid";
            this.patid.ReadOnly = true;
            this.patid.Size = new System.Drawing.Size(147, 22);
            this.patid.TabIndex = 0;
            this.patid.TextChanged += new System.EventHandler(this.patid_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(36, 84);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(115, 20);
            this.label2.TabIndex = 335;
            this.label2.Text = "Patient Name:";
            // 
            // ptn_lst_pnl
            // 
            this.ptn_lst_pnl.Controls.Add(this.scd_id);
            this.ptn_lst_pnl.Controls.Add(this.ptn_nme);
            this.ptn_lst_pnl.Controls.Add(this.sched_id1);
            this.ptn_lst_pnl.Controls.Add(this.closeb);
            this.ptn_lst_pnl.Controls.Add(this.ptn_grid);
            this.ptn_lst_pnl.Controls.Add(this.ptn_add);
            this.ptn_lst_pnl.Controls.Add(this.label21);
            this.ptn_lst_pnl.Controls.Add(this.pr_id);
            this.ptn_lst_pnl.Location = new System.Drawing.Point(5, 5);
            this.ptn_lst_pnl.Margin = new System.Windows.Forms.Padding(4);
            this.ptn_lst_pnl.Name = "ptn_lst_pnl";
            this.ptn_lst_pnl.Size = new System.Drawing.Size(529, 350);
            this.ptn_lst_pnl.TabIndex = 361;
            this.ptn_lst_pnl.Visible = false;
            this.ptn_lst_pnl.Paint += new System.Windows.Forms.PaintEventHandler(this.ptn_lst_pnl_Paint);
            // 
            // scd_id
            // 
            this.scd_id.AutoSize = true;
            this.scd_id.Location = new System.Drawing.Point(340, 52);
            this.scd_id.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.scd_id.Name = "scd_id";
            this.scd_id.Size = new System.Drawing.Size(54, 17);
            this.scd_id.TabIndex = 107;
            this.scd_id.Text = "label22";
            this.scd_id.Visible = false;
            // 
            // ptn_nme
            // 
            this.ptn_nme.Location = new System.Drawing.Point(13, 74);
            this.ptn_nme.Margin = new System.Windows.Forms.Padding(4);
            this.ptn_nme.Name = "ptn_nme";
            this.ptn_nme.Size = new System.Drawing.Size(185, 22);
            this.ptn_nme.TabIndex = 94;
            this.ptn_nme.TextChanged += new System.EventHandler(this.ptn_nme_TextChanged_1);
            // 
            // sched_id1
            // 
            this.sched_id1.AutoSize = true;
            this.sched_id1.Location = new System.Drawing.Point(340, 68);
            this.sched_id1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.sched_id1.Name = "sched_id1";
            this.sched_id1.Size = new System.Drawing.Size(54, 17);
            this.sched_id1.TabIndex = 106;
            this.sched_id1.Text = "label22";
            this.sched_id1.Visible = false;
            // 
            // closeb
            // 
            this.closeb.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.closeb.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.closeb.Font = new System.Drawing.Font("Lucida Console", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.closeb.Location = new System.Drawing.Point(509, 410);
            this.closeb.Margin = new System.Windows.Forms.Padding(4);
            this.closeb.Name = "closeb";
            this.closeb.Size = new System.Drawing.Size(95, 25);
            this.closeb.TabIndex = 58;
            this.closeb.Text = "Close";
            this.closeb.UseVisualStyleBackColor = false;
            this.closeb.Click += new System.EventHandler(this.closeb_Click_1);
            // 
            // ptn_grid
            // 
            this.ptn_grid.AllowUserToAddRows = false;
            this.ptn_grid.AllowUserToDeleteRows = false;
            this.ptn_grid.AllowUserToResizeColumns = false;
            this.ptn_grid.AllowUserToResizeRows = false;
            this.ptn_grid.BackgroundColor = System.Drawing.Color.White;
            this.ptn_grid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.ptn_grid.Location = new System.Drawing.Point(13, 114);
            this.ptn_grid.Margin = new System.Windows.Forms.Padding(4);
            this.ptn_grid.Name = "ptn_grid";
            this.ptn_grid.ReadOnly = true;
            this.ptn_grid.RowHeadersVisible = false;
            this.ptn_grid.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.ptn_grid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.ptn_grid.Size = new System.Drawing.Size(505, 217);
            this.ptn_grid.TabIndex = 27;
            this.ptn_grid.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.ptn_grid_CellContentClick_1);
            // 
            // ptn_add
            // 
            this.ptn_add.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ptn_add.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ptn_add.Font = new System.Drawing.Font("Lucida Console", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ptn_add.Location = new System.Drawing.Point(208, 73);
            this.ptn_add.Margin = new System.Windows.Forms.Padding(4);
            this.ptn_add.Name = "ptn_add";
            this.ptn_add.Size = new System.Drawing.Size(83, 26);
            this.ptn_add.TabIndex = 93;
            this.ptn_add.Text = "Find";
            this.ptn_add.UseVisualStyleBackColor = false;
            this.ptn_add.Click += new System.EventHandler(this.ptn_add_Click);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(141, 22);
            this.label21.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(237, 20);
            this.label21.TabIndex = 88;
            this.label21.Text = "Appointment Listing";
            // 
            // pr_id
            // 
            this.pr_id.AutoSize = true;
            this.pr_id.Location = new System.Drawing.Point(17, 20);
            this.pr_id.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.pr_id.Name = "pr_id";
            this.pr_id.Size = new System.Drawing.Size(54, 17);
            this.pr_id.TabIndex = 108;
            this.pr_id.Text = "label22";
            this.pr_id.Visible = false;
            // 
            // groupBox_dccash
            // 
            this.groupBox_dccash.Controls.Add(this.button_pay);
            this.groupBox_dccash.Controls.Add(this.button_paycash);
            this.groupBox_dccash.Controls.Add(this.textBox_total_paid);
            this.groupBox_dccash.Controls.Add(this.label26);
            this.groupBox_dccash.Controls.Add(this.treatmentcash);
            this.groupBox_dccash.Controls.Add(this.label1);
            this.groupBox_dccash.Controls.Add(this.grandtotalcash);
            this.groupBox_dccash.Controls.Add(this.chargescash);
            this.groupBox_dccash.Controls.Add(this.label19);
            this.groupBox_dccash.Controls.Add(this.label20);
            this.groupBox_dccash.Controls.Add(this.toothinvcash);
            this.groupBox_dccash.Controls.Add(this.label22);
            this.groupBox_dccash.Location = new System.Drawing.Point(497, 14);
            this.groupBox_dccash.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox_dccash.Name = "groupBox_dccash";
            this.groupBox_dccash.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox_dccash.Size = new System.Drawing.Size(487, 192);
            this.groupBox_dccash.TabIndex = 364;
            this.groupBox_dccash.TabStop = false;
            this.groupBox_dccash.Text = "Dental Details:";
            this.groupBox_dccash.Enter += new System.EventHandler(this.groupBox5_Enter);
            // 
            // button_pay
            // 
            this.button_pay.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.button_pay.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_pay.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button_pay.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_pay.Location = new System.Drawing.Point(389, 151);
            this.button_pay.Margin = new System.Windows.Forms.Padding(4);
            this.button_pay.Name = "button_pay";
            this.button_pay.Size = new System.Drawing.Size(79, 27);
            this.button_pay.TabIndex = 407;
            this.button_pay.Text = "Pay";
            this.button_pay.UseVisualStyleBackColor = false;
            this.button_pay.Click += new System.EventHandler(this.button_pay_Click);
            // 
            // button_paycash
            // 
            this.button_paycash.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.button_paycash.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_paycash.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button_paycash.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_paycash.Location = new System.Drawing.Point(389, 112);
            this.button_paycash.Margin = new System.Windows.Forms.Padding(4);
            this.button_paycash.Name = "button_paycash";
            this.button_paycash.Size = new System.Drawing.Size(79, 27);
            this.button_paycash.TabIndex = 406;
            this.button_paycash.Text = "Proceed";
            this.button_paycash.UseVisualStyleBackColor = false;
            this.button_paycash.Click += new System.EventHandler(this.button3_Click);
            // 
            // textBox_total_paid
            // 
            this.textBox_total_paid.Enabled = false;
            this.textBox_total_paid.Location = new System.Drawing.Point(171, 151);
            this.textBox_total_paid.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_total_paid.Name = "textBox_total_paid";
            this.textBox_total_paid.ReadOnly = true;
            this.textBox_total_paid.Size = new System.Drawing.Size(200, 22);
            this.textBox_total_paid.TabIndex = 404;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(33, 154);
            this.label26.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(92, 20);
            this.label26.TabIndex = 405;
            this.label26.Text = "Total paid :";
            // 
            // treatmentcash
            // 
            this.treatmentcash.Enabled = false;
            this.treatmentcash.Location = new System.Drawing.Point(171, 17);
            this.treatmentcash.Margin = new System.Windows.Forms.Padding(4);
            this.treatmentcash.Name = "treatmentcash";
            this.treatmentcash.ReadOnly = true;
            this.treatmentcash.Size = new System.Drawing.Size(200, 22);
            this.treatmentcash.TabIndex = 397;
            this.treatmentcash.TextChanged += new System.EventHandler(this.treatmentcash_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(32, 20);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(85, 20);
            this.label1.TabIndex = 398;
            this.label1.Text = "Treatment";
            // 
            // grandtotalcash
            // 
            this.grandtotalcash.Enabled = false;
            this.grandtotalcash.Location = new System.Drawing.Point(171, 114);
            this.grandtotalcash.Margin = new System.Windows.Forms.Padding(4);
            this.grandtotalcash.Name = "grandtotalcash";
            this.grandtotalcash.ReadOnly = true;
            this.grandtotalcash.Size = new System.Drawing.Size(200, 22);
            this.grandtotalcash.TabIndex = 379;
            // 
            // chargescash
            // 
            this.chargescash.Enabled = false;
            this.chargescash.Location = new System.Drawing.Point(171, 82);
            this.chargescash.Margin = new System.Windows.Forms.Padding(4);
            this.chargescash.Name = "chargescash";
            this.chargescash.ReadOnly = true;
            this.chargescash.Size = new System.Drawing.Size(200, 22);
            this.chargescash.TabIndex = 380;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(31, 121);
            this.label19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(102, 20);
            this.label19.TabIndex = 384;
            this.label19.Text = "Grand Total:";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(32, 87);
            this.label20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(77, 20);
            this.label20.TabIndex = 383;
            this.label20.Text = "Charges:";
            // 
            // toothinvcash
            // 
            this.toothinvcash.Enabled = false;
            this.toothinvcash.Location = new System.Drawing.Point(171, 50);
            this.toothinvcash.Margin = new System.Windows.Forms.Padding(4);
            this.toothinvcash.Name = "toothinvcash";
            this.toothinvcash.ReadOnly = true;
            this.toothinvcash.Size = new System.Drawing.Size(200, 22);
            this.toothinvcash.TabIndex = 381;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(32, 52);
            this.label22.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(121, 20);
            this.label22.TabIndex = 382;
            this.label22.Text = "Tooth Involved:";
            // 
            // dccashid
            // 
            this.dccashid.AutoSize = true;
            this.dccashid.Location = new System.Drawing.Point(13, 377);
            this.dccashid.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.dccashid.Name = "dccashid";
            this.dccashid.Size = new System.Drawing.Size(0, 17);
            this.dccashid.TabIndex = 362;
            this.dccashid.Visible = false;
            // 
            // dccheckid
            // 
            this.dccheckid.AutoSize = true;
            this.dccheckid.Location = new System.Drawing.Point(12, 400);
            this.dccheckid.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.dccheckid.Name = "dccheckid";
            this.dccheckid.Size = new System.Drawing.Size(0, 17);
            this.dccheckid.TabIndex = 363;
            this.dccheckid.Visible = false;
            // 
            // button_finalizecash
            // 
            this.button_finalizecash.Activecolor = System.Drawing.Color.Teal;
            this.button_finalizecash.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(229)))), ((int)(((byte)(229)))));
            this.button_finalizecash.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button_finalizecash.BorderRadius = 0;
            this.button_finalizecash.ButtonText = "Finalize Treatment";
            this.button_finalizecash.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_finalizecash.DisabledColor = System.Drawing.Color.Gray;
            this.button_finalizecash.Iconcolor = System.Drawing.Color.Transparent;
            this.button_finalizecash.Iconimage = null;
            this.button_finalizecash.Iconimage_right = null;
            this.button_finalizecash.Iconimage_right_Selected = null;
            this.button_finalizecash.Iconimage_Selected = null;
            this.button_finalizecash.IconMarginLeft = 0;
            this.button_finalizecash.IconMarginRight = 0;
            this.button_finalizecash.IconRightVisible = true;
            this.button_finalizecash.IconRightZoom = 0D;
            this.button_finalizecash.IconVisible = true;
            this.button_finalizecash.IconZoom = 70D;
            this.button_finalizecash.IsTab = false;
            this.button_finalizecash.Location = new System.Drawing.Point(575, 411);
            this.button_finalizecash.Margin = new System.Windows.Forms.Padding(5);
            this.button_finalizecash.Name = "button_finalizecash";
            this.button_finalizecash.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(229)))), ((int)(((byte)(229)))));
            this.button_finalizecash.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(216)))), ((int)(((byte)(216)))));
            this.button_finalizecash.OnHoverTextColor = System.Drawing.Color.White;
            this.button_finalizecash.selected = false;
            this.button_finalizecash.Size = new System.Drawing.Size(124, 42);
            this.button_finalizecash.TabIndex = 365;
            this.button_finalizecash.Text = "Finalize Treatment";
            this.button_finalizecash.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.button_finalizecash.Textcolor = System.Drawing.Color.Black;
            this.button_finalizecash.TextFont = new System.Drawing.Font("Lucida Console", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_finalizecash.Click += new System.EventHandler(this.button_finalizecash_Click);
            // 
            // panel_pay
            // 
            this.panel_pay.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel_pay.Controls.Add(this.balance);
            this.panel_pay.Controls.Add(this.label9);
            this.panel_pay.Controls.Add(this.date_pdc);
            this.panel_pay.Controls.Add(this.label_pdc);
            this.panel_pay.Controls.Add(this.comboBox_bank);
            this.panel_pay.Controls.Add(this.label_bank);
            this.panel_pay.Controls.Add(this.dptdue);
            this.panel_pay.Controls.Add(this.paymentdue);
            this.panel_pay.Controls.Add(this.textBox_amntpaid);
            this.panel_pay.Controls.Add(this.llabel);
            this.panel_pay.Controls.Add(this.checknumber);
            this.panel_pay.Controls.Add(this.textBox_Checknumber);
            this.panel_pay.Controls.Add(this.bunifuFlatButton1);
            this.panel_pay.Controls.Add(this.comboBox_Type);
            this.panel_pay.Controls.Add(this.label32);
            this.panel_pay.Controls.Add(this.comboBox_mode);
            this.panel_pay.Controls.Add(this.label27);
            this.panel_pay.Location = new System.Drawing.Point(995, 260);
            this.panel_pay.Margin = new System.Windows.Forms.Padding(4);
            this.panel_pay.Name = "panel_pay";
            this.panel_pay.Size = new System.Drawing.Size(426, 359);
            this.panel_pay.TabIndex = 363;
            this.panel_pay.Paint += new System.Windows.Forms.PaintEventHandler(this.panel_pay_Paint);
            // 
            // balance
            // 
            this.balance.Enabled = false;
            this.balance.Location = new System.Drawing.Point(160, 99);
            this.balance.Margin = new System.Windows.Forms.Padding(4);
            this.balance.Name = "balance";
            this.balance.ReadOnly = true;
            this.balance.Size = new System.Drawing.Size(132, 22);
            this.balance.TabIndex = 378;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(16, 103);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(75, 20);
            this.label9.TabIndex = 377;
            this.label9.Text = "Balance:";
            // 
            // date_pdc
            // 
            this.date_pdc.CustomFormat = "yyyy-MM-dd";
            this.date_pdc.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.date_pdc.Location = new System.Drawing.Point(160, 239);
            this.date_pdc.Margin = new System.Windows.Forms.Padding(4);
            this.date_pdc.Name = "date_pdc";
            this.date_pdc.Size = new System.Drawing.Size(200, 22);
            this.date_pdc.TabIndex = 376;
            // 
            // label_pdc
            // 
            this.label_pdc.AutoSize = true;
            this.label_pdc.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_pdc.Location = new System.Drawing.Point(23, 239);
            this.label_pdc.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_pdc.Name = "label_pdc";
            this.label_pdc.Size = new System.Drawing.Size(89, 20);
            this.label_pdc.TabIndex = 375;
            this.label_pdc.Text = "Post Date:";
            // 
            // comboBox_bank
            // 
            this.comboBox_bank.FormattingEnabled = true;
            this.comboBox_bank.Items.AddRange(new object[] {
            "BPI",
            "BDO",
            "SECURITY"});
            this.comboBox_bank.Location = new System.Drawing.Point(160, 205);
            this.comboBox_bank.Margin = new System.Windows.Forms.Padding(4);
            this.comboBox_bank.Name = "comboBox_bank";
            this.comboBox_bank.Size = new System.Drawing.Size(200, 24);
            this.comboBox_bank.TabIndex = 374;
            // 
            // label_bank
            // 
            this.label_bank.AutoSize = true;
            this.label_bank.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_bank.Location = new System.Drawing.Point(22, 206);
            this.label_bank.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_bank.Name = "label_bank";
            this.label_bank.Size = new System.Drawing.Size(52, 20);
            this.label_bank.TabIndex = 373;
            this.label_bank.Text = "Bank:";
            // 
            // dptdue
            // 
            this.dptdue.CustomFormat = "yyyy-MM-dd";
            this.dptdue.Enabled = false;
            this.dptdue.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dptdue.Location = new System.Drawing.Point(160, 135);
            this.dptdue.Margin = new System.Windows.Forms.Padding(4);
            this.dptdue.Name = "dptdue";
            this.dptdue.Size = new System.Drawing.Size(200, 22);
            this.dptdue.TabIndex = 371;
            // 
            // paymentdue
            // 
            this.paymentdue.AutoSize = true;
            this.paymentdue.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.paymentdue.Location = new System.Drawing.Point(20, 137);
            this.paymentdue.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.paymentdue.Name = "paymentdue";
            this.paymentdue.Size = new System.Drawing.Size(115, 20);
            this.paymentdue.TabIndex = 370;
            this.paymentdue.Text = "Payment Due:";
            // 
            // textBox_amntpaid
            // 
            this.textBox_amntpaid.Location = new System.Drawing.Point(160, 70);
            this.textBox_amntpaid.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_amntpaid.Name = "textBox_amntpaid";
            this.textBox_amntpaid.Size = new System.Drawing.Size(200, 22);
            this.textBox_amntpaid.TabIndex = 357;
            this.textBox_amntpaid.TextChanged += new System.EventHandler(this.textBox_amntpaid_TextChanged);
            // 
            // llabel
            // 
            this.llabel.AutoSize = true;
            this.llabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.llabel.Location = new System.Drawing.Point(17, 71);
            this.llabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.llabel.Name = "llabel";
            this.llabel.Size = new System.Drawing.Size(109, 20);
            this.llabel.TabIndex = 0;
            this.llabel.Text = "Amount Paid:";
            // 
            // checknumber
            // 
            this.checknumber.AutoSize = true;
            this.checknumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checknumber.Location = new System.Drawing.Point(20, 175);
            this.checknumber.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.checknumber.Name = "checknumber";
            this.checknumber.Size = new System.Drawing.Size(125, 20);
            this.checknumber.TabIndex = 369;
            this.checknumber.Text = "Check Number:";
            // 
            // textBox_Checknumber
            // 
            this.textBox_Checknumber.Enabled = false;
            this.textBox_Checknumber.Location = new System.Drawing.Point(160, 173);
            this.textBox_Checknumber.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_Checknumber.Name = "textBox_Checknumber";
            this.textBox_Checknumber.Size = new System.Drawing.Size(200, 22);
            this.textBox_Checknumber.TabIndex = 368;
            // 
            // bunifuFlatButton1
            // 
            this.bunifuFlatButton1.Activecolor = System.Drawing.Color.Teal;
            this.bunifuFlatButton1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(229)))), ((int)(((byte)(229)))));
            this.bunifuFlatButton1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton1.BorderRadius = 0;
            this.bunifuFlatButton1.ButtonText = "Checkout";
            this.bunifuFlatButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton1.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton1.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton1.Iconimage = null;
            this.bunifuFlatButton1.Iconimage_right = null;
            this.bunifuFlatButton1.Iconimage_right_Selected = null;
            this.bunifuFlatButton1.Iconimage_Selected = null;
            this.bunifuFlatButton1.IconMarginLeft = 0;
            this.bunifuFlatButton1.IconMarginRight = 0;
            this.bunifuFlatButton1.IconRightVisible = true;
            this.bunifuFlatButton1.IconRightZoom = 0D;
            this.bunifuFlatButton1.IconVisible = true;
            this.bunifuFlatButton1.IconZoom = 70D;
            this.bunifuFlatButton1.IsTab = false;
            this.bunifuFlatButton1.Location = new System.Drawing.Point(251, 273);
            this.bunifuFlatButton1.Margin = new System.Windows.Forms.Padding(5);
            this.bunifuFlatButton1.Name = "bunifuFlatButton1";
            this.bunifuFlatButton1.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(229)))), ((int)(((byte)(229)))));
            this.bunifuFlatButton1.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(216)))), ((int)(((byte)(216)))));
            this.bunifuFlatButton1.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton1.selected = false;
            this.bunifuFlatButton1.Size = new System.Drawing.Size(111, 31);
            this.bunifuFlatButton1.TabIndex = 360;
            this.bunifuFlatButton1.Text = "Checkout";
            this.bunifuFlatButton1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuFlatButton1.Textcolor = System.Drawing.Color.Black;
            this.bunifuFlatButton1.TextFont = new System.Drawing.Font("Lucida Console", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton1.Click += new System.EventHandler(this.bunifuFlatButton1_Click);
            // 
            // comboBox_Type
            // 
            this.comboBox_Type.FormattingEnabled = true;
            this.comboBox_Type.Items.AddRange(new object[] {
            "Full",
            "Staggered"});
            this.comboBox_Type.Location = new System.Drawing.Point(200, 25);
            this.comboBox_Type.Margin = new System.Windows.Forms.Padding(4);
            this.comboBox_Type.Name = "comboBox_Type";
            this.comboBox_Type.Size = new System.Drawing.Size(160, 24);
            this.comboBox_Type.TabIndex = 367;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(199, 7);
            this.label32.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(115, 20);
            this.label32.TabIndex = 366;
            this.label32.Text = "Payment Type";
            // 
            // comboBox_mode
            // 
            this.comboBox_mode.FormattingEnabled = true;
            this.comboBox_mode.Items.AddRange(new object[] {
            "Cash",
            "Check"});
            this.comboBox_mode.Location = new System.Drawing.Point(19, 25);
            this.comboBox_mode.Margin = new System.Windows.Forms.Padding(4);
            this.comboBox_mode.Name = "comboBox_mode";
            this.comboBox_mode.Size = new System.Drawing.Size(160, 24);
            this.comboBox_mode.TabIndex = 365;
            this.comboBox_mode.SelectedIndexChanged += new System.EventHandler(this.comboBox_mode_SelectedIndexChanged);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(17, 7);
            this.label27.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(120, 20);
            this.label27.TabIndex = 364;
            this.label27.Text = "Payment Mode";
            // 
            // trt_grd
            // 
            this.trt_grd.AllowUserToAddRows = false;
            this.trt_grd.AllowUserToDeleteRows = false;
            this.trt_grd.AllowUserToResizeColumns = false;
            this.trt_grd.AllowUserToResizeRows = false;
            this.trt_grd.BackgroundColor = System.Drawing.Color.White;
            this.trt_grd.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.trt_grd.Location = new System.Drawing.Point(16, 190);
            this.trt_grd.Margin = new System.Windows.Forms.Padding(4);
            this.trt_grd.Name = "trt_grd";
            this.trt_grd.ReadOnly = true;
            this.trt_grd.RowHeadersVisible = false;
            this.trt_grd.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.trt_grd.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.trt_grd.Size = new System.Drawing.Size(468, 167);
            this.trt_grd.TabIndex = 368;
            this.trt_grd.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.trt_grd_CellClick);
            this.trt_grd.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.trt_grd_CellContentClick);
            // 
            // textBox_trtment1
            // 
            this.textBox_trtment1.Enabled = false;
            this.textBox_trtment1.Location = new System.Drawing.Point(157, 16);
            this.textBox_trtment1.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_trtment1.Name = "textBox_trtment1";
            this.textBox_trtment1.ReadOnly = true;
            this.textBox_trtment1.Size = new System.Drawing.Size(200, 22);
            this.textBox_trtment1.TabIndex = 363;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.ForeColor = System.Drawing.Color.LightSkyBlue;
            this.label28.Location = new System.Drawing.Point(367, 6);
            this.label28.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(54, 17);
            this.label28.TabIndex = 211;
            this.label28.Text = "label58";
            this.label28.Visible = false;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(17, 22);
            this.label33.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(90, 20);
            this.label33.TabIndex = 1;
            this.label33.Text = "Treatment:";
            // 
            // button_Addcheck
            // 
            this.button_Addcheck.Activecolor = System.Drawing.Color.Teal;
            this.button_Addcheck.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(229)))), ((int)(((byte)(229)))));
            this.button_Addcheck.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button_Addcheck.BorderRadius = 0;
            this.button_Addcheck.ButtonText = "Add";
            this.button_Addcheck.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_Addcheck.DisabledColor = System.Drawing.Color.Gray;
            this.button_Addcheck.Iconcolor = System.Drawing.Color.Transparent;
            this.button_Addcheck.Iconimage = null;
            this.button_Addcheck.Iconimage_right = null;
            this.button_Addcheck.Iconimage_right_Selected = null;
            this.button_Addcheck.Iconimage_Selected = null;
            this.button_Addcheck.IconMarginLeft = 0;
            this.button_Addcheck.IconMarginRight = 0;
            this.button_Addcheck.IconRightVisible = true;
            this.button_Addcheck.IconRightZoom = 0D;
            this.button_Addcheck.IconVisible = true;
            this.button_Addcheck.IconZoom = 70D;
            this.button_Addcheck.IsTab = false;
            this.button_Addcheck.Location = new System.Drawing.Point(45, 167);
            this.button_Addcheck.Margin = new System.Windows.Forms.Padding(5);
            this.button_Addcheck.Name = "button_Addcheck";
            this.button_Addcheck.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(229)))), ((int)(((byte)(229)))));
            this.button_Addcheck.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(216)))), ((int)(((byte)(216)))));
            this.button_Addcheck.OnHoverTextColor = System.Drawing.Color.White;
            this.button_Addcheck.selected = false;
            this.button_Addcheck.Size = new System.Drawing.Size(133, 36);
            this.button_Addcheck.TabIndex = 15;
            this.button_Addcheck.Text = "Add";
            this.button_Addcheck.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.button_Addcheck.Textcolor = System.Drawing.Color.Black;
            this.button_Addcheck.TextFont = new System.Drawing.Font("Lucida Console", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_Addcheck.Click += new System.EventHandler(this.button_Addcheck_Click);
            // 
            // panel_Check
            // 
            this.panel_Check.Controls.Add(this.textBox_trtment1);
            this.panel_Check.Controls.Add(this.label33);
            this.panel_Check.Controls.Add(this.textBox_toothinv);
            this.panel_Check.Controls.Add(this.label28);
            this.panel_Check.Controls.Add(this.button_Addcheck);
            this.panel_Check.Controls.Add(this.toothcnt);
            this.panel_Check.Controls.Add(this.toothinvolved);
            this.panel_Check.Controls.Add(this.charges);
            this.panel_Check.Controls.Add(this.resetbut);
            this.panel_Check.Controls.Add(this.grandtotal);
            this.panel_Check.Controls.Add(this.textBox_Charges);
            this.panel_Check.Controls.Add(this.textBox_grandtotal);
            this.panel_Check.Location = new System.Drawing.Point(993, 32);
            this.panel_Check.Margin = new System.Windows.Forms.Padding(4);
            this.panel_Check.Name = "panel_Check";
            this.panel_Check.Size = new System.Drawing.Size(427, 220);
            this.panel_Check.TabIndex = 371;
            this.panel_Check.Paint += new System.Windows.Forms.PaintEventHandler(this.panel_Check_Paint);
            // 
            // panel_pay2
            // 
            this.panel_pay2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel_pay2.Controls.Add(this.button_cancel_pay);
            this.panel_pay2.Controls.Add(this.button_pay2);
            this.panel_pay2.Controls.Add(this.textBox_change);
            this.panel_pay2.Controls.Add(this.lllabel);
            this.panel_pay2.Location = new System.Drawing.Point(543, 214);
            this.panel_pay2.Margin = new System.Windows.Forms.Padding(4);
            this.panel_pay2.Name = "panel_pay2";
            this.panel_pay2.Size = new System.Drawing.Size(365, 189);
            this.panel_pay2.TabIndex = 372;
            this.panel_pay2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel_pay2_Paint);
            // 
            // button_cancel_pay
            // 
            this.button_cancel_pay.Activecolor = System.Drawing.Color.Teal;
            this.button_cancel_pay.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(229)))), ((int)(((byte)(229)))));
            this.button_cancel_pay.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button_cancel_pay.BorderRadius = 0;
            this.button_cancel_pay.ButtonText = "X";
            this.button_cancel_pay.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_cancel_pay.DisabledColor = System.Drawing.Color.Gray;
            this.button_cancel_pay.Iconcolor = System.Drawing.Color.Transparent;
            this.button_cancel_pay.Iconimage = null;
            this.button_cancel_pay.Iconimage_right = null;
            this.button_cancel_pay.Iconimage_right_Selected = null;
            this.button_cancel_pay.Iconimage_Selected = null;
            this.button_cancel_pay.IconMarginLeft = 0;
            this.button_cancel_pay.IconMarginRight = 0;
            this.button_cancel_pay.IconRightVisible = true;
            this.button_cancel_pay.IconRightZoom = 0D;
            this.button_cancel_pay.IconVisible = true;
            this.button_cancel_pay.IconZoom = 70D;
            this.button_cancel_pay.IsTab = false;
            this.button_cancel_pay.Location = new System.Drawing.Point(321, 1);
            this.button_cancel_pay.Margin = new System.Windows.Forms.Padding(5);
            this.button_cancel_pay.Name = "button_cancel_pay";
            this.button_cancel_pay.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(229)))), ((int)(((byte)(229)))));
            this.button_cancel_pay.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(216)))), ((int)(((byte)(216)))));
            this.button_cancel_pay.OnHoverTextColor = System.Drawing.Color.White;
            this.button_cancel_pay.selected = false;
            this.button_cancel_pay.Size = new System.Drawing.Size(40, 30);
            this.button_cancel_pay.TabIndex = 364;
            this.button_cancel_pay.Text = "X";
            this.button_cancel_pay.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.button_cancel_pay.Textcolor = System.Drawing.Color.Black;
            this.button_cancel_pay.TextFont = new System.Drawing.Font("Lucida Console", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_cancel_pay.Click += new System.EventHandler(this.button_cancel_pay_Click);
            // 
            // button_pay2
            // 
            this.button_pay2.Activecolor = System.Drawing.Color.Teal;
            this.button_pay2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(229)))), ((int)(((byte)(229)))));
            this.button_pay2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button_pay2.BorderRadius = 0;
            this.button_pay2.ButtonText = "Pay";
            this.button_pay2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_pay2.DisabledColor = System.Drawing.Color.Gray;
            this.button_pay2.Iconcolor = System.Drawing.Color.Transparent;
            this.button_pay2.Iconimage = null;
            this.button_pay2.Iconimage_right = null;
            this.button_pay2.Iconimage_right_Selected = null;
            this.button_pay2.Iconimage_Selected = null;
            this.button_pay2.IconMarginLeft = 0;
            this.button_pay2.IconMarginRight = 0;
            this.button_pay2.IconRightVisible = true;
            this.button_pay2.IconRightZoom = 0D;
            this.button_pay2.IconVisible = true;
            this.button_pay2.IconZoom = 70D;
            this.button_pay2.IsTab = false;
            this.button_pay2.Location = new System.Drawing.Point(117, 133);
            this.button_pay2.Margin = new System.Windows.Forms.Padding(5);
            this.button_pay2.Name = "button_pay2";
            this.button_pay2.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(229)))), ((int)(((byte)(229)))));
            this.button_pay2.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(216)))), ((int)(((byte)(216)))));
            this.button_pay2.OnHoverTextColor = System.Drawing.Color.White;
            this.button_pay2.selected = false;
            this.button_pay2.Size = new System.Drawing.Size(111, 31);
            this.button_pay2.TabIndex = 360;
            this.button_pay2.Text = "Pay";
            this.button_pay2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.button_pay2.Textcolor = System.Drawing.Color.Black;
            this.button_pay2.TextFont = new System.Drawing.Font("Lucida Console", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_pay2.Click += new System.EventHandler(this.bunifuFlatButton2_Click);
            // 
            // textBox_change
            // 
            this.textBox_change.Enabled = false;
            this.textBox_change.Location = new System.Drawing.Point(177, 91);
            this.textBox_change.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_change.Name = "textBox_change";
            this.textBox_change.ReadOnly = true;
            this.textBox_change.Size = new System.Drawing.Size(132, 22);
            this.textBox_change.TabIndex = 359;
            this.textBox_change.TextChanged += new System.EventHandler(this.textBox_change_TextChanged);
            // 
            // lllabel
            // 
            this.lllabel.AutoSize = true;
            this.lllabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lllabel.Location = new System.Drawing.Point(84, 95);
            this.lllabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lllabel.Name = "lllabel";
            this.lllabel.Size = new System.Drawing.Size(71, 20);
            this.lllabel.TabIndex = 358;
            this.lllabel.Text = "Change:";
            // 
            // summary_grd
            // 
            this.summary_grd.AllowUserToAddRows = false;
            this.summary_grd.AllowUserToDeleteRows = false;
            this.summary_grd.AllowUserToResizeColumns = false;
            this.summary_grd.AllowUserToResizeRows = false;
            this.summary_grd.BackgroundColor = System.Drawing.Color.White;
            this.summary_grd.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.summary_grd.Location = new System.Drawing.Point(16, 402);
            this.summary_grd.Margin = new System.Windows.Forms.Padding(4);
            this.summary_grd.Name = "summary_grd";
            this.summary_grd.ReadOnly = true;
            this.summary_grd.RowHeadersVisible = false;
            this.summary_grd.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.summary_grd.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.summary_grd.Size = new System.Drawing.Size(468, 196);
            this.summary_grd.TabIndex = 373;
            this.summary_grd.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.summary_grd_CellClick);
            this.summary_grd.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.summary_grd_CellContentClick);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(12, 379);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(90, 20);
            this.label6.TabIndex = 341;
            this.label6.Text = "Summary: ";
            // 
            // trt_chart
            // 
            this.trt_chart.AutoSize = true;
            this.trt_chart.Location = new System.Drawing.Point(1128, 9);
            this.trt_chart.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.trt_chart.Name = "trt_chart";
            this.trt_chart.Size = new System.Drawing.Size(40, 17);
            this.trt_chart.TabIndex = 374;
            this.trt_chart.Text = "chart";
            this.trt_chart.Visible = false;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(223, 615);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(107, 20);
            this.label11.TabIndex = 375;
            this.label11.Text = "Amount Due:";
            // 
            // amnt_due
            // 
            this.amnt_due.AutoSize = true;
            this.amnt_due.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.amnt_due.Location = new System.Drawing.Point(365, 615);
            this.amnt_due.Name = "amnt_due";
            this.amnt_due.Size = new System.Drawing.Size(0, 20);
            this.amnt_due.TabIndex = 376;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(325, 615);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(38, 20);
            this.label4.TabIndex = 377;
            this.label4.Text = "Php";
            // 
            // button_inventory
            // 
            this.button_inventory.Activecolor = System.Drawing.Color.Teal;
            this.button_inventory.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(229)))), ((int)(((byte)(229)))));
            this.button_inventory.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button_inventory.BorderRadius = 0;
            this.button_inventory.ButtonText = "Inventory";
            this.button_inventory.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_inventory.DisabledColor = System.Drawing.Color.Gray;
            this.button_inventory.Iconcolor = System.Drawing.Color.Transparent;
            this.button_inventory.Iconimage = null;
            this.button_inventory.Iconimage_right = null;
            this.button_inventory.Iconimage_right_Selected = null;
            this.button_inventory.Iconimage_Selected = null;
            this.button_inventory.IconMarginLeft = 0;
            this.button_inventory.IconMarginRight = 0;
            this.button_inventory.IconRightVisible = true;
            this.button_inventory.IconRightZoom = 0D;
            this.button_inventory.IconVisible = true;
            this.button_inventory.IconZoom = 70D;
            this.button_inventory.IsTab = false;
            this.button_inventory.Location = new System.Drawing.Point(99, 607);
            this.button_inventory.Margin = new System.Windows.Forms.Padding(5);
            this.button_inventory.Name = "button_inventory";
            this.button_inventory.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(229)))), ((int)(((byte)(229)))));
            this.button_inventory.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(216)))), ((int)(((byte)(216)))));
            this.button_inventory.OnHoverTextColor = System.Drawing.Color.White;
            this.button_inventory.selected = false;
            this.button_inventory.Size = new System.Drawing.Size(116, 36);
            this.button_inventory.TabIndex = 378;
            this.button_inventory.Text = "Inventory";
            this.button_inventory.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.button_inventory.Textcolor = System.Drawing.Color.Black;
            this.button_inventory.TextFont = new System.Drawing.Font("Lucida Console", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_inventory.Click += new System.EventHandler(this.button_inventory_Click);
            // 
            // panel_inv
            // 
            this.panel_inv.Controls.Add(this.label_label);
            this.panel_inv.Controls.Add(this.label_inv);
            this.panel_inv.Controls.Add(this.label_inv_id);
            this.panel_inv.Controls.Add(this.label_expirey);
            this.panel_inv.Controls.Add(this.box_expiry);
            this.panel_inv.Controls.Add(this.button_cancel_inv);
            this.panel_inv.Controls.Add(this.label_quant);
            this.panel_inv.Controls.Add(this.label8);
            this.panel_inv.Controls.Add(this.label_desc);
            this.panel_inv.Controls.Add(this.label_item);
            this.panel_inv.Controls.Add(this.button_deduct);
            this.panel_inv.Controls.Add(this.button_add);
            this.panel_inv.Controls.Add(this.label_desription);
            this.panel_inv.Controls.Add(this.label_inventory_name);
            this.panel_inv.Controls.Add(this.dataGridView_inventory);
            this.panel_inv.Location = new System.Drawing.Point(5, 356);
            this.panel_inv.Margin = new System.Windows.Forms.Padding(4);
            this.panel_inv.Name = "panel_inv";
            this.panel_inv.Size = new System.Drawing.Size(536, 303);
            this.panel_inv.TabIndex = 108;
            this.panel_inv.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // label_label
            // 
            this.label_label.AutoSize = true;
            this.label_label.Location = new System.Drawing.Point(465, 233);
            this.label_label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_label.Name = "label_label";
            this.label_label.Size = new System.Drawing.Size(40, 17);
            this.label_label.TabIndex = 376;
            this.label_label.Text = "chart";
            this.label_label.Visible = false;
            // 
            // label_inv
            // 
            this.label_inv.AutoSize = true;
            this.label_inv.Location = new System.Drawing.Point(421, 214);
            this.label_inv.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_inv.Name = "label_inv";
            this.label_inv.Size = new System.Drawing.Size(0, 17);
            this.label_inv.TabIndex = 375;
            this.label_inv.Visible = false;
            // 
            // label_inv_id
            // 
            this.label_inv_id.AutoSize = true;
            this.label_inv_id.Font = new System.Drawing.Font("Lucida Console", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_inv_id.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label_inv_id.Location = new System.Drawing.Point(340, 212);
            this.label_inv_id.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_inv_id.Name = "label_inv_id";
            this.label_inv_id.Size = new System.Drawing.Size(0, 17);
            this.label_inv_id.TabIndex = 368;
            // 
            // label_expirey
            // 
            this.label_expirey.AutoSize = true;
            this.label_expirey.Font = new System.Drawing.Font("Lucida Console", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_expirey.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label_expirey.Location = new System.Drawing.Point(52, 268);
            this.label_expirey.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_expirey.Name = "label_expirey";
            this.label_expirey.Size = new System.Drawing.Size(108, 17);
            this.label_expirey.TabIndex = 367;
            this.label_expirey.Text = "Quantity :";
            // 
            // box_expiry
            // 
            this.box_expiry.CalendarFont = new System.Drawing.Font("Arial", 10.25F);
            this.box_expiry.CustomFormat = "MMMM dd, yyyy";
            this.box_expiry.Font = new System.Drawing.Font("Arial", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.box_expiry.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.box_expiry.Location = new System.Drawing.Point(171, 268);
            this.box_expiry.Margin = new System.Windows.Forms.Padding(4);
            this.box_expiry.Name = "box_expiry";
            this.box_expiry.Size = new System.Drawing.Size(161, 20);
            this.box_expiry.TabIndex = 366;
            // 
            // button_cancel_inv
            // 
            this.button_cancel_inv.Activecolor = System.Drawing.Color.Teal;
            this.button_cancel_inv.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(229)))), ((int)(((byte)(229)))));
            this.button_cancel_inv.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button_cancel_inv.BorderRadius = 0;
            this.button_cancel_inv.ButtonText = "X";
            this.button_cancel_inv.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_cancel_inv.DisabledColor = System.Drawing.Color.Gray;
            this.button_cancel_inv.Iconcolor = System.Drawing.Color.Transparent;
            this.button_cancel_inv.Iconimage = null;
            this.button_cancel_inv.Iconimage_right = null;
            this.button_cancel_inv.Iconimage_right_Selected = null;
            this.button_cancel_inv.Iconimage_Selected = null;
            this.button_cancel_inv.IconMarginLeft = 0;
            this.button_cancel_inv.IconMarginRight = 0;
            this.button_cancel_inv.IconRightVisible = true;
            this.button_cancel_inv.IconRightZoom = 0D;
            this.button_cancel_inv.IconVisible = true;
            this.button_cancel_inv.IconZoom = 70D;
            this.button_cancel_inv.IsTab = false;
            this.button_cancel_inv.Location = new System.Drawing.Point(491, 5);
            this.button_cancel_inv.Margin = new System.Windows.Forms.Padding(5);
            this.button_cancel_inv.Name = "button_cancel_inv";
            this.button_cancel_inv.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(229)))), ((int)(((byte)(229)))));
            this.button_cancel_inv.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(216)))), ((int)(((byte)(216)))));
            this.button_cancel_inv.OnHoverTextColor = System.Drawing.Color.White;
            this.button_cancel_inv.selected = false;
            this.button_cancel_inv.Size = new System.Drawing.Size(40, 30);
            this.button_cancel_inv.TabIndex = 365;
            this.button_cancel_inv.Text = "X";
            this.button_cancel_inv.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.button_cancel_inv.Textcolor = System.Drawing.Color.Black;
            this.button_cancel_inv.TextFont = new System.Drawing.Font("Lucida Console", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_cancel_inv.Click += new System.EventHandler(this.button_cancel_inv_Click);
            // 
            // label_quant
            // 
            this.label_quant.AutoSize = true;
            this.label_quant.Font = new System.Drawing.Font("Lucida Console", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_quant.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label_quant.Location = new System.Drawing.Point(176, 247);
            this.label_quant.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_quant.Name = "label_quant";
            this.label_quant.Size = new System.Drawing.Size(0, 17);
            this.label_quant.TabIndex = 335;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Lucida Console", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label8.Location = new System.Drawing.Point(41, 246);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(108, 17);
            this.label8.TabIndex = 334;
            this.label8.Text = "Quantity :";
            // 
            // label_desc
            // 
            this.label_desc.AutoSize = true;
            this.label_desc.Font = new System.Drawing.Font("Lucida Console", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_desc.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label_desc.Location = new System.Drawing.Point(176, 231);
            this.label_desc.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_desc.Name = "label_desc";
            this.label_desc.Size = new System.Drawing.Size(0, 17);
            this.label_desc.TabIndex = 333;
            // 
            // label_item
            // 
            this.label_item.AutoSize = true;
            this.label_item.Font = new System.Drawing.Font("Lucida Console", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_item.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label_item.Location = new System.Drawing.Point(176, 214);
            this.label_item.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_item.Name = "label_item";
            this.label_item.Size = new System.Drawing.Size(0, 17);
            this.label_item.TabIndex = 332;
            // 
            // button_deduct
            // 
            this.button_deduct.ActiveBorderThickness = 1;
            this.button_deduct.ActiveCornerRadius = 20;
            this.button_deduct.ActiveFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(216)))), ((int)(((byte)(216)))));
            this.button_deduct.ActiveForecolor = System.Drawing.Color.White;
            this.button_deduct.ActiveLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(233)))), ((int)(((byte)(233)))), ((int)(((byte)(233)))));
            this.button_deduct.BackColor = System.Drawing.SystemColors.Control;
            this.button_deduct.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button_deduct.BackgroundImage")));
            this.button_deduct.ButtonText = "Deduct";
            this.button_deduct.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_deduct.Font = new System.Drawing.Font("Lucida Console", 9.25F);
            this.button_deduct.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(202)))), ((int)(((byte)(254)))));
            this.button_deduct.IdleBorderThickness = 1;
            this.button_deduct.IdleCornerRadius = 20;
            this.button_deduct.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(233)))), ((int)(((byte)(233)))), ((int)(((byte)(233)))));
            this.button_deduct.IdleForecolor = System.Drawing.Color.Black;
            this.button_deduct.IdleLineColor = System.Drawing.Color.Black;
            this.button_deduct.Location = new System.Drawing.Point(351, 252);
            this.button_deduct.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.button_deduct.Name = "button_deduct";
            this.button_deduct.Size = new System.Drawing.Size(87, 38);
            this.button_deduct.TabIndex = 331;
            this.button_deduct.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.button_deduct.Click += new System.EventHandler(this.button_deduct_Click);
            // 
            // button_add
            // 
            this.button_add.ActiveBorderThickness = 1;
            this.button_add.ActiveCornerRadius = 20;
            this.button_add.ActiveFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(216)))), ((int)(((byte)(216)))));
            this.button_add.ActiveForecolor = System.Drawing.Color.White;
            this.button_add.ActiveLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(233)))), ((int)(((byte)(233)))), ((int)(((byte)(233)))));
            this.button_add.BackColor = System.Drawing.SystemColors.Control;
            this.button_add.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button_add.BackgroundImage")));
            this.button_add.ButtonText = "Add";
            this.button_add.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_add.Font = new System.Drawing.Font("Lucida Console", 9.25F);
            this.button_add.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(202)))), ((int)(((byte)(254)))));
            this.button_add.IdleBorderThickness = 1;
            this.button_add.IdleCornerRadius = 20;
            this.button_add.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(233)))), ((int)(((byte)(233)))), ((int)(((byte)(233)))));
            this.button_add.IdleForecolor = System.Drawing.Color.Black;
            this.button_add.IdleLineColor = System.Drawing.Color.Black;
            this.button_add.Location = new System.Drawing.Point(448, 252);
            this.button_add.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.button_add.Name = "button_add";
            this.button_add.Size = new System.Drawing.Size(79, 38);
            this.button_add.TabIndex = 330;
            this.button_add.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.button_add.Click += new System.EventHandler(this.button_add_Click);
            // 
            // label_desription
            // 
            this.label_desription.AutoSize = true;
            this.label_desription.Font = new System.Drawing.Font("Lucida Console", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_desription.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label_desription.Location = new System.Drawing.Point(20, 230);
            this.label_desription.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_desription.Name = "label_desription";
            this.label_desription.Size = new System.Drawing.Size(138, 17);
            this.label_desription.TabIndex = 329;
            this.label_desription.Text = "Description :";
            // 
            // label_inventory_name
            // 
            this.label_inventory_name.AutoSize = true;
            this.label_inventory_name.Font = new System.Drawing.Font("Lucida Console", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_inventory_name.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label_inventory_name.Location = new System.Drawing.Point(41, 214);
            this.label_inventory_name.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_inventory_name.Name = "label_inventory_name";
            this.label_inventory_name.Size = new System.Drawing.Size(118, 17);
            this.label_inventory_name.TabIndex = 326;
            this.label_inventory_name.Text = "Item Name :";
            this.label_inventory_name.Click += new System.EventHandler(this.label_inventory_name_Click);
            // 
            // dataGridView_inventory
            // 
            this.dataGridView_inventory.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView_inventory.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_inventory.Location = new System.Drawing.Point(4, 38);
            this.dataGridView_inventory.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridView_inventory.Name = "dataGridView_inventory";
            this.dataGridView_inventory.Size = new System.Drawing.Size(519, 166);
            this.dataGridView_inventory.TabIndex = 0;
            this.dataGridView_inventory.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // button_finish
            // 
            this.button_finish.Activecolor = System.Drawing.Color.Teal;
            this.button_finish.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(229)))), ((int)(((byte)(229)))));
            this.button_finish.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button_finish.BorderRadius = 0;
            this.button_finish.ButtonText = "Finish ";
            this.button_finish.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_finish.DisabledColor = System.Drawing.Color.Gray;
            this.button_finish.Iconcolor = System.Drawing.Color.Transparent;
            this.button_finish.Iconimage = null;
            this.button_finish.Iconimage_right = null;
            this.button_finish.Iconimage_right_Selected = null;
            this.button_finish.Iconimage_Selected = null;
            this.button_finish.IconMarginLeft = 0;
            this.button_finish.IconMarginRight = 0;
            this.button_finish.IconRightVisible = true;
            this.button_finish.IconRightZoom = 0D;
            this.button_finish.IconVisible = true;
            this.button_finish.IconZoom = 70D;
            this.button_finish.IsTab = false;
            this.button_finish.Location = new System.Drawing.Point(623, 587);
            this.button_finish.Margin = new System.Windows.Forms.Padding(5);
            this.button_finish.Name = "button_finish";
            this.button_finish.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(229)))), ((int)(((byte)(229)))));
            this.button_finish.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(216)))), ((int)(((byte)(216)))));
            this.button_finish.OnHoverTextColor = System.Drawing.Color.White;
            this.button_finish.selected = false;
            this.button_finish.Size = new System.Drawing.Size(359, 50);
            this.button_finish.TabIndex = 375;
            this.button_finish.Text = "Finish ";
            this.button_finish.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.button_finish.Textcolor = System.Drawing.Color.Black;
            this.button_finish.TextFont = new System.Drawing.Font("Lucida Console", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_finish.Click += new System.EventHandler(this.button_finish_Click);
            // 
            // panel_alert
            // 
            this.panel_alert.BackColor = System.Drawing.SystemColors.ControlDark;
            this.panel_alert.Controls.Add(this.button_check_inv);
            this.panel_alert.Controls.Add(this.label7);
            this.panel_alert.Controls.Add(this.button_yes);
            this.panel_alert.Location = new System.Drawing.Point(512, 238);
            this.panel_alert.Margin = new System.Windows.Forms.Padding(4);
            this.panel_alert.Name = "panel_alert";
            this.panel_alert.Size = new System.Drawing.Size(493, 217);
            this.panel_alert.TabIndex = 379;
            // 
            // button_check_inv
            // 
            this.button_check_inv.Activecolor = System.Drawing.Color.Teal;
            this.button_check_inv.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(229)))), ((int)(((byte)(229)))));
            this.button_check_inv.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button_check_inv.BorderRadius = 0;
            this.button_check_inv.ButtonText = "Inventory";
            this.button_check_inv.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_check_inv.DisabledColor = System.Drawing.Color.Gray;
            this.button_check_inv.Iconcolor = System.Drawing.Color.Transparent;
            this.button_check_inv.Iconimage = null;
            this.button_check_inv.Iconimage_right = null;
            this.button_check_inv.Iconimage_right_Selected = null;
            this.button_check_inv.Iconimage_Selected = null;
            this.button_check_inv.IconMarginLeft = 0;
            this.button_check_inv.IconMarginRight = 0;
            this.button_check_inv.IconRightVisible = true;
            this.button_check_inv.IconRightZoom = 0D;
            this.button_check_inv.IconVisible = true;
            this.button_check_inv.IconZoom = 70D;
            this.button_check_inv.IsTab = false;
            this.button_check_inv.Location = new System.Drawing.Point(257, 135);
            this.button_check_inv.Margin = new System.Windows.Forms.Padding(5);
            this.button_check_inv.Name = "button_check_inv";
            this.button_check_inv.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(229)))), ((int)(((byte)(229)))));
            this.button_check_inv.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(216)))), ((int)(((byte)(216)))));
            this.button_check_inv.OnHoverTextColor = System.Drawing.Color.White;
            this.button_check_inv.selected = false;
            this.button_check_inv.Size = new System.Drawing.Size(133, 36);
            this.button_check_inv.TabIndex = 365;
            this.button_check_inv.Text = "Inventory";
            this.button_check_inv.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.button_check_inv.Textcolor = System.Drawing.Color.Black;
            this.button_check_inv.TextFont = new System.Drawing.Font("Lucida Console", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_check_inv.Click += new System.EventHandler(this.button_check_inv_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(52, 98);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(369, 20);
            this.label7.TabIndex = 109;
            this.label7.Text = "Have you update the inventory?";
            // 
            // button_yes
            // 
            this.button_yes.Activecolor = System.Drawing.Color.Teal;
            this.button_yes.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(229)))), ((int)(((byte)(229)))));
            this.button_yes.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button_yes.BorderRadius = 0;
            this.button_yes.ButtonText = "Yes";
            this.button_yes.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_yes.DisabledColor = System.Drawing.Color.Gray;
            this.button_yes.Iconcolor = System.Drawing.Color.Transparent;
            this.button_yes.Iconimage = null;
            this.button_yes.Iconimage_right = null;
            this.button_yes.Iconimage_right_Selected = null;
            this.button_yes.Iconimage_Selected = null;
            this.button_yes.IconMarginLeft = 0;
            this.button_yes.IconMarginRight = 0;
            this.button_yes.IconRightVisible = true;
            this.button_yes.IconRightZoom = 0D;
            this.button_yes.IconVisible = true;
            this.button_yes.IconZoom = 70D;
            this.button_yes.IsTab = false;
            this.button_yes.Location = new System.Drawing.Point(97, 135);
            this.button_yes.Margin = new System.Windows.Forms.Padding(5);
            this.button_yes.Name = "button_yes";
            this.button_yes.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(229)))), ((int)(((byte)(229)))));
            this.button_yes.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(216)))), ((int)(((byte)(216)))));
            this.button_yes.OnHoverTextColor = System.Drawing.Color.White;
            this.button_yes.selected = false;
            this.button_yes.Size = new System.Drawing.Size(133, 36);
            this.button_yes.TabIndex = 364;
            this.button_yes.Text = "Yes";
            this.button_yes.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.button_yes.Textcolor = System.Drawing.Color.Black;
            this.button_yes.TextFont = new System.Drawing.Font("Lucida Console", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_yes.Click += new System.EventHandler(this.button_yes_Click);
            // 
            // label_unq
            // 
            this.label_unq.AutoSize = true;
            this.label_unq.Location = new System.Drawing.Point(1031, 14);
            this.label_unq.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_unq.Name = "label_unq";
            this.label_unq.Size = new System.Drawing.Size(40, 17);
            this.label_unq.TabIndex = 380;
            this.label_unq.Text = "chart";
            // 
            // form_dentalchart
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(1387, 673);
            this.Controls.Add(this.label_unq);
            this.Controls.Add(this.panel_alert);
            this.Controls.Add(this.button_finish);
            this.Controls.Add(this.panel_inv);
            this.Controls.Add(this.panel_chart);
            this.Controls.Add(this.panel_pay2);
            this.Controls.Add(this.button_inventory);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.amnt_due);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.trt_chart);
            this.Controls.Add(this.ptn_lst_pnl);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.summary_grd);
            this.Controls.Add(this.groupBox_dccash);
            this.Controls.Add(this.panel_Check);
            this.Controls.Add(this.trt_grd);
            this.Controls.Add(this.dccheckid);
            this.Controls.Add(this.dccashid);
            this.Controls.Add(this.treatment_id);
            this.Controls.Add(this.button_edit);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.button_finalizecash);
            this.Controls.Add(this.panel_pay);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "form_dentalchart";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "form_dentalchart";
            this.Load += new System.EventHandler(this.form_dentalchart_Load);
            this.panel_chart.ResumeLayout(false);
            this.panel_chart.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.L)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ptn_lst_pnl.ResumeLayout(false);
            this.ptn_lst_pnl.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ptn_grid)).EndInit();
            this.groupBox_dccash.ResumeLayout(false);
            this.groupBox_dccash.PerformLayout();
            this.panel_pay.ResumeLayout(false);
            this.panel_pay.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trt_grd)).EndInit();
            this.panel_Check.ResumeLayout(false);
            this.panel_Check.PerformLayout();
            this.panel_pay2.ResumeLayout(false);
            this.panel_pay2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.summary_grd)).EndInit();
            this.panel_inv.ResumeLayout(false);
            this.panel_inv.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_inventory)).EndInit();
            this.panel_alert.ResumeLayout(false);
            this.panel_alert.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label treatment_id;
        private System.Windows.Forms.Panel panel_chart;
        private System.Windows.Forms.CheckBox L30;
        private System.Windows.Forms.CheckBox L24;
        private System.Windows.Forms.CheckBox L22;
        private System.Windows.Forms.CheckBox L29;
        private System.Windows.Forms.CheckBox L25;
        private System.Windows.Forms.CheckBox U5;
        private System.Windows.Forms.CheckBox L23;
        private System.Windows.Forms.CheckBox L26;
        private System.Windows.Forms.CheckBox U6;
        private System.Windows.Forms.CheckBox U10;
        private System.Windows.Forms.CheckBox L27;
        private System.Windows.Forms.CheckBox U7;
        private System.Windows.Forms.CheckBox U11;
        private System.Windows.Forms.CheckBox L28;
        private System.Windows.Forms.CheckBox U8;
        private System.Windows.Forms.CheckBox U12;
        private System.Windows.Forms.CheckBox U3;
        private System.Windows.Forms.CheckBox U9;
        private System.Windows.Forms.CheckBox U13;
        private System.Windows.Forms.CheckBox L31;
        private System.Windows.Forms.CheckBox L21;
        private System.Windows.Forms.CheckBox U14;
        private System.Windows.Forms.CheckBox U4;
        private System.Windows.Forms.CheckBox L20;
        private System.Windows.Forms.CheckBox U15;
        private System.Windows.Forms.CheckBox U2;
        private System.Windows.Forms.CheckBox L19;
        private System.Windows.Forms.CheckBox U16;
        private System.Windows.Forms.CheckBox U1;
        private System.Windows.Forms.CheckBox L17;
        private System.Windows.Forms.CheckBox L18;
        private System.Windows.Forms.CheckBox L32;
        private System.Windows.Forms.PictureBox L;
        private Bunifu.Framework.UI.BunifuFlatButton button_edit;
        private System.Windows.Forms.TextBox toothcnt;
        private Bunifu.Framework.UI.BunifuFlatButton resetbut;
        private System.Windows.Forms.TextBox textBox_grandtotal;
        private System.Windows.Forms.TextBox textBox_Charges;
        private System.Windows.Forms.Label grandtotal;
        private System.Windows.Forms.Label charges;
        private System.Windows.Forms.TextBox textBox_toothinv;
        private System.Windows.Forms.Label toothinvolved;
        internal System.Windows.Forms.GroupBox groupBox3;
        internal System.Windows.Forms.TextBox patn;
        internal System.Windows.Forms.TextBox patid;
        internal System.Windows.Forms.Label label2;
        internal System.Windows.Forms.Button button2;
        internal System.Windows.Forms.TextBox appid;
        private System.Windows.Forms.Panel ptn_lst_pnl;
        private System.Windows.Forms.TextBox ptn_nme;
        private System.Windows.Forms.Button closeb;
        private System.Windows.Forms.DataGridView ptn_grid;
        private System.Windows.Forms.Button ptn_add;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label sched_id1;
        private System.Windows.Forms.Label dccashid;
        private System.Windows.Forms.Label dccheckid;
        private System.Windows.Forms.GroupBox groupBox_dccash;
        private System.Windows.Forms.TextBox grandtotalcash;
        private System.Windows.Forms.TextBox chargescash;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox toothinvcash;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox treatmentcash;
        private System.Windows.Forms.Label label1;
        private Bunifu.Framework.UI.BunifuFlatButton button_finalizecash;
        private System.Windows.Forms.Panel panel_pay;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton1;
        private System.Windows.Forms.DataGridView trt_grd;
        private Bunifu.Framework.UI.BunifuFlatButton button_Addcheck;
        private System.Windows.Forms.TextBox textBox_trtment1;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.ComboBox comboBox_mode;
        private System.Windows.Forms.ComboBox comboBox_Type;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Panel panel_Check;
        private System.Windows.Forms.DateTimePicker scd_dte;
        internal System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label scd_id;
        private System.Windows.Forms.DateTimePicker dptdue;
        private System.Windows.Forms.Label paymentdue;
        private System.Windows.Forms.Label checknumber;
        private System.Windows.Forms.TextBox textBox_Checknumber;
        private System.Windows.Forms.Panel panel_pay2;
        private Bunifu.Framework.UI.BunifuFlatButton button_pay2;
        private System.Windows.Forms.TextBox textBox_change;
        private System.Windows.Forms.Label lllabel;
        private System.Windows.Forms.TextBox textBox_amntpaid;
        private System.Windows.Forms.Label llabel;
        private System.Windows.Forms.TextBox textBox_total_paid;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.DataGridView summary_grd;
        internal System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label pr_id;
        private System.Windows.Forms.Label trt_chart;
        internal System.Windows.Forms.Label label11;
        internal System.Windows.Forms.Label amnt_due;
        internal System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label_bank;
        private System.Windows.Forms.ComboBox comboBox_bank;
        private Bunifu.Framework.UI.BunifuFlatButton button_inventory;
        private System.Windows.Forms.Panel panel_inv;
        private System.Windows.Forms.DataGridView dataGridView_inventory;
        private System.Windows.Forms.Label label_inventory_name;
        private System.Windows.Forms.Label label_desription;
        private Bunifu.Framework.UI.BunifuThinButton2 button_add;
        private System.Windows.Forms.Label label_quant;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label_desc;
        private System.Windows.Forms.Label label_item;
        private Bunifu.Framework.UI.BunifuThinButton2 button_deduct;
        private Bunifu.Framework.UI.BunifuFlatButton button_cancel_pay;
        private Bunifu.Framework.UI.BunifuFlatButton button_cancel_inv;
        private System.Windows.Forms.Label label_expirey;
        private System.Windows.Forms.DateTimePicker box_expiry;
        private System.Windows.Forms.Label label_inv_id;
        private System.Windows.Forms.Label label_label;
        private System.Windows.Forms.Label label_inv;
        internal System.Windows.Forms.Button button_paycash;
        private Bunifu.Framework.UI.BunifuFlatButton button_finish;
        private System.Windows.Forms.DateTimePicker date_pdc;
        private System.Windows.Forms.Label label_pdc;
        private System.Windows.Forms.Panel panel_alert;
        private Bunifu.Framework.UI.BunifuFlatButton button_check_inv;
        private System.Windows.Forms.Label label7;
        private Bunifu.Framework.UI.BunifuFlatButton button_yes;
        private System.Windows.Forms.Label label_unq;
        private System.Windows.Forms.TextBox balance;
        private System.Windows.Forms.Label label9;
        internal System.Windows.Forms.Button button_pay;
    }
}