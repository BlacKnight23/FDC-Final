﻿namespace Accounting
{
    partial class form_patient
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(form_patient));
            this.panelmedhist = new System.Windows.Forms.Panel();
            this.panel_accounts = new System.Windows.Forms.Panel();
            this.chosen_balance = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.text_balance = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.button_accounts_close = new System.Windows.Forms.Button();
            this.DGV_accounts = new System.Windows.Forms.DataGridView();
            this.button_accounts = new System.Windows.Forms.Button();
            this.label_balance = new System.Windows.Forms.Label();
            this.textBox_balance = new System.Windows.Forms.TextBox();
            this.dateTimePicker_pdc = new System.Windows.Forms.DateTimePicker();
            this.label__pdc = new System.Windows.Forms.Label();
            this.panel_hist = new System.Windows.Forms.Panel();
            this.button_close_hist = new System.Windows.Forms.Button();
            this.dataGridView_hist = new System.Windows.Forms.DataGridView();
            this.panel1 = new System.Windows.Forms.Panel();
            this.date_pdc = new System.Windows.Forms.DateTimePicker();
            this.label_pdc = new System.Windows.Forms.Label();
            this.comboBox_bank = new System.Windows.Forms.ComboBox();
            this.label_bank = new System.Windows.Forms.Label();
            this.textBox_checknumber_cheque = new System.Windows.Forms.TextBox();
            this.button_cancell = new System.Windows.Forms.Button();
            this.button_payy = new System.Windows.Forms.Button();
            this.labelcheck = new System.Windows.Forms.Label();
            this.comboBox_mop = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.textBox_amount_cashcheque = new System.Windows.Forms.TextBox();
            this.label_paymentdue = new System.Windows.Forms.Label();
            this.label_amountpaid = new System.Windows.Forms.Label();
            this.button_paymenthist = new System.Windows.Forms.Button();
            this.label_appointmentt_id = new System.Windows.Forms.Label();
            this.textBox_type = new System.Windows.Forms.TextBox();
            this.label_treatment_id = new System.Windows.Forms.Label();
            this.label_paymentdate = new System.Windows.Forms.Label();
            this.date_payment = new System.Windows.Forms.DateTimePicker();
            this.label11 = new System.Windows.Forms.Label();
            this.label_appntid = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.DGV_dentaloperation = new System.Windows.Forms.DataGridView();
            this.textBox_mop = new System.Windows.Forms.TextBox();
            this.checknumber = new System.Windows.Forms.Label();
            this.textBox_grandtotal = new System.Windows.Forms.TextBox();
            this.textBox_Checknumber = new System.Windows.Forms.TextBox();
            this.grandtotal = new System.Windows.Forms.Label();
            this.textBox_amount_paid = new System.Windows.Forms.TextBox();
            this.due_payment = new System.Windows.Forms.DateTimePicker();
            this.DGV_applist = new System.Windows.Forms.DataGridView();
            this.DGV_appointment = new System.Windows.Forms.DataGridView();
            this.paneldental = new System.Windows.Forms.Panel();
            this.dataGridView_ov = new System.Windows.Forms.DataGridView();
            this.button_view = new Bunifu.Framework.UI.BunifuFlatButton();
            this.patient_name = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.date_due = new System.Windows.Forms.DataGridView();
            this.L30 = new System.Windows.Forms.CheckBox();
            this.L29 = new System.Windows.Forms.CheckBox();
            this.L23 = new System.Windows.Forms.CheckBox();
            this.U10 = new System.Windows.Forms.CheckBox();
            this.U11 = new System.Windows.Forms.CheckBox();
            this.U12 = new System.Windows.Forms.CheckBox();
            this.U13 = new System.Windows.Forms.CheckBox();
            this.U14 = new System.Windows.Forms.CheckBox();
            this.U15 = new System.Windows.Forms.CheckBox();
            this.U16 = new System.Windows.Forms.CheckBox();
            this.L17 = new System.Windows.Forms.CheckBox();
            this.L18 = new System.Windows.Forms.CheckBox();
            this.L19 = new System.Windows.Forms.CheckBox();
            this.L20 = new System.Windows.Forms.CheckBox();
            this.L21 = new System.Windows.Forms.CheckBox();
            this.U9 = new System.Windows.Forms.CheckBox();
            this.U8 = new System.Windows.Forms.CheckBox();
            this.U7 = new System.Windows.Forms.CheckBox();
            this.U6 = new System.Windows.Forms.CheckBox();
            this.U5 = new System.Windows.Forms.CheckBox();
            this.L22 = new System.Windows.Forms.CheckBox();
            this.L24 = new System.Windows.Forms.CheckBox();
            this.L25 = new System.Windows.Forms.CheckBox();
            this.L26 = new System.Windows.Forms.CheckBox();
            this.L27 = new System.Windows.Forms.CheckBox();
            this.L28 = new System.Windows.Forms.CheckBox();
            this.U3 = new System.Windows.Forms.CheckBox();
            this.L31 = new System.Windows.Forms.CheckBox();
            this.U4 = new System.Windows.Forms.CheckBox();
            this.U2 = new System.Windows.Forms.CheckBox();
            this.U1 = new System.Windows.Forms.CheckBox();
            this.L32 = new System.Windows.Forms.CheckBox();
            this.L = new System.Windows.Forms.PictureBox();
            this.DGV_paymenthist = new System.Windows.Forms.DataGridView();
            this.bunifuCustomLabel1 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.button_searchday = new Bunifu.Framework.UI.BunifuThinButton2();
            this.button_searchmonth = new Bunifu.Framework.UI.BunifuThinButton2();
            this.tab_medicalhist = new Bunifu.Framework.UI.BunifuFlatButton();
            this.tab_dentalchart = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuSeparator1 = new Bunifu.Framework.UI.BunifuSeparator();
            this.tab_patientinfo = new Bunifu.Framework.UI.BunifuFlatButton();
            this.label_id = new System.Windows.Forms.Label();
            this.patientinfo = new System.Windows.Forms.Panel();
            this.label13 = new System.Windows.Forms.Label();
            this.aa = new System.Windows.Forms.TextBox();
            this.panel_pending = new System.Windows.Forms.Panel();
            this.button_exit_pending = new Bunifu.Framework.UI.BunifuFlatButton();
            this.dataGridView_pending = new System.Windows.Forms.DataGridView();
            this.button_pending = new Bunifu.Framework.UI.BunifuFlatButton();
            this.label_apaid = new System.Windows.Forms.Label();
            this.label_gtotal = new System.Windows.Forms.Label();
            this.label_status = new System.Windows.Forms.Label();
            this.button_update = new Bunifu.Framework.UI.BunifuThinButton2();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.button_reset = new Bunifu.Framework.UI.BunifuThinButton2();
            this.label1 = new System.Windows.Forms.Label();
            this.button_create = new Bunifu.Framework.UI.BunifuThinButton2();
            this.textBox_firstname = new System.Windows.Forms.TextBox();
            this.textBox_lastname = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox_address = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox_contact1 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.birth_date = new System.Windows.Forms.DateTimePicker();
            this.combo_gender = new System.Windows.Forms.ComboBox();
            this.textBox_age = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.panelmedhist.SuspendLayout();
            this.panel_accounts.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_accounts)).BeginInit();
            this.panel_hist.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_hist)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_dentaloperation)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_applist)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_appointment)).BeginInit();
            this.paneldental.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_ov)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.date_due)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.L)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_paymenthist)).BeginInit();
            this.patientinfo.SuspendLayout();
            this.panel_pending.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_pending)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // panelmedhist
            // 
            this.panelmedhist.Controls.Add(this.panel_accounts);
            this.panelmedhist.Controls.Add(this.button_accounts);
            this.panelmedhist.Controls.Add(this.label_balance);
            this.panelmedhist.Controls.Add(this.textBox_balance);
            this.panelmedhist.Controls.Add(this.dateTimePicker_pdc);
            this.panelmedhist.Controls.Add(this.label__pdc);
            this.panelmedhist.Controls.Add(this.panel_hist);
            this.panelmedhist.Controls.Add(this.panel1);
            this.panelmedhist.Controls.Add(this.label_paymentdue);
            this.panelmedhist.Controls.Add(this.label_amountpaid);
            this.panelmedhist.Controls.Add(this.button_paymenthist);
            this.panelmedhist.Controls.Add(this.label_appointmentt_id);
            this.panelmedhist.Controls.Add(this.textBox_type);
            this.panelmedhist.Controls.Add(this.label_treatment_id);
            this.panelmedhist.Controls.Add(this.label_paymentdate);
            this.panelmedhist.Controls.Add(this.date_payment);
            this.panelmedhist.Controls.Add(this.label11);
            this.panelmedhist.Controls.Add(this.label_appntid);
            this.panelmedhist.Controls.Add(this.label4);
            this.panelmedhist.Controls.Add(this.label9);
            this.panelmedhist.Controls.Add(this.label10);
            this.panelmedhist.Controls.Add(this.DGV_dentaloperation);
            this.panelmedhist.Controls.Add(this.textBox_mop);
            this.panelmedhist.Controls.Add(this.checknumber);
            this.panelmedhist.Controls.Add(this.textBox_grandtotal);
            this.panelmedhist.Controls.Add(this.textBox_Checknumber);
            this.panelmedhist.Controls.Add(this.grandtotal);
            this.panelmedhist.Controls.Add(this.textBox_amount_paid);
            this.panelmedhist.Controls.Add(this.due_payment);
            this.panelmedhist.Controls.Add(this.DGV_applist);
            this.panelmedhist.Controls.Add(this.DGV_appointment);
            this.panelmedhist.Location = new System.Drawing.Point(1, 114);
            this.panelmedhist.Margin = new System.Windows.Forms.Padding(4);
            this.panelmedhist.Name = "panelmedhist";
            this.panelmedhist.Size = new System.Drawing.Size(1188, 551);
            this.panelmedhist.TabIndex = 18;
            this.panelmedhist.Paint += new System.Windows.Forms.PaintEventHandler(this.panelmedhist_Paint);
            // 
            // panel_accounts
            // 
            this.panel_accounts.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel_accounts.Controls.Add(this.chosen_balance);
            this.panel_accounts.Controls.Add(this.label15);
            this.panel_accounts.Controls.Add(this.text_balance);
            this.panel_accounts.Controls.Add(this.label14);
            this.panel_accounts.Controls.Add(this.button_accounts_close);
            this.panel_accounts.Controls.Add(this.DGV_accounts);
            this.panel_accounts.Location = new System.Drawing.Point(310, 21);
            this.panel_accounts.Margin = new System.Windows.Forms.Padding(4);
            this.panel_accounts.Name = "panel_accounts";
            this.panel_accounts.Size = new System.Drawing.Size(878, 202);
            this.panel_accounts.TabIndex = 386;
            this.panel_accounts.Visible = false;
            // 
            // chosen_balance
            // 
            this.chosen_balance.AutoSize = true;
            this.chosen_balance.BackColor = System.Drawing.SystemColors.Control;
            this.chosen_balance.Font = new System.Drawing.Font("Lucida Console", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chosen_balance.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.chosen_balance.Location = new System.Drawing.Point(676, 169);
            this.chosen_balance.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.chosen_balance.Name = "chosen_balance";
            this.chosen_balance.Size = new System.Drawing.Size(98, 17);
            this.chosen_balance.TabIndex = 389;
            this.chosen_balance.Text = "Balance_C";
            this.chosen_balance.Visible = false;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.SystemColors.Control;
            this.label15.Font = new System.Drawing.Font("Lucida Console", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label15.Location = new System.Drawing.Point(147, 174);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(38, 17);
            this.label15.TabIndex = 388;
            this.label15.Text = "Php";
            // 
            // text_balance
            // 
            this.text_balance.AutoSize = true;
            this.text_balance.BackColor = System.Drawing.SystemColors.Control;
            this.text_balance.Font = new System.Drawing.Font("Lucida Console", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.text_balance.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.text_balance.Location = new System.Drawing.Point(172, 175);
            this.text_balance.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.text_balance.Name = "text_balance";
            this.text_balance.Size = new System.Drawing.Size(68, 17);
            this.text_balance.TabIndex = 387;
            this.text_balance.Text = "232323";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Lucida Console", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.Black;
            this.label14.Location = new System.Drawing.Point(4, 173);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(158, 17);
            this.label14.TabIndex = 386;
            this.label14.Text = "Total Balance: ";
            // 
            // button_accounts_close
            // 
            this.button_accounts_close.Location = new System.Drawing.Point(777, 162);
            this.button_accounts_close.Margin = new System.Windows.Forms.Padding(4);
            this.button_accounts_close.Name = "button_accounts_close";
            this.button_accounts_close.Size = new System.Drawing.Size(68, 28);
            this.button_accounts_close.TabIndex = 385;
            this.button_accounts_close.Text = "Close";
            this.button_accounts_close.UseVisualStyleBackColor = true;
            this.button_accounts_close.Click += new System.EventHandler(this.button2_Click);
            // 
            // DGV_accounts
            // 
            this.DGV_accounts.AllowUserToAddRows = false;
            this.DGV_accounts.AllowUserToDeleteRows = false;
            this.DGV_accounts.BackgroundColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.DGV_accounts.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.DGV_accounts.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.DGV_accounts.DefaultCellStyle = dataGridViewCellStyle2;
            this.DGV_accounts.Location = new System.Drawing.Point(4, 5);
            this.DGV_accounts.Margin = new System.Windows.Forms.Padding(4);
            this.DGV_accounts.Name = "DGV_accounts";
            this.DGV_accounts.ReadOnly = true;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.DGV_accounts.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.DGV_accounts.RowHeadersVisible = false;
            this.DGV_accounts.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.DGV_accounts.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DGV_accounts.Size = new System.Drawing.Size(870, 151);
            this.DGV_accounts.TabIndex = 382;
            this.DGV_accounts.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DGV_accounts_CellContentClick);
            // 
            // button_accounts
            // 
            this.button_accounts.Location = new System.Drawing.Point(351, 501);
            this.button_accounts.Margin = new System.Windows.Forms.Padding(4);
            this.button_accounts.Name = "button_accounts";
            this.button_accounts.Size = new System.Drawing.Size(135, 28);
            this.button_accounts.TabIndex = 390;
            this.button_accounts.Text = "Accounts";
            this.button_accounts.UseVisualStyleBackColor = true;
            this.button_accounts.Click += new System.EventHandler(this.button1_Click);
            // 
            // label_balance
            // 
            this.label_balance.AutoSize = true;
            this.label_balance.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_balance.Location = new System.Drawing.Point(347, 348);
            this.label_balance.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_balance.Name = "label_balance";
            this.label_balance.Size = new System.Drawing.Size(85, 20);
            this.label_balance.TabIndex = 388;
            this.label_balance.Text = "Balance =";
            // 
            // textBox_balance
            // 
            this.textBox_balance.Enabled = false;
            this.textBox_balance.Location = new System.Drawing.Point(507, 347);
            this.textBox_balance.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_balance.Name = "textBox_balance";
            this.textBox_balance.ReadOnly = true;
            this.textBox_balance.Size = new System.Drawing.Size(91, 22);
            this.textBox_balance.TabIndex = 387;
            // 
            // dateTimePicker_pdc
            // 
            this.dateTimePicker_pdc.CustomFormat = "yyyy-MM-dd";
            this.dateTimePicker_pdc.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker_pdc.Location = new System.Drawing.Point(507, 478);
            this.dateTimePicker_pdc.Margin = new System.Windows.Forms.Padding(4);
            this.dateTimePicker_pdc.Name = "dateTimePicker_pdc";
            this.dateTimePicker_pdc.Size = new System.Drawing.Size(200, 22);
            this.dateTimePicker_pdc.TabIndex = 386;
            // 
            // label__pdc
            // 
            this.label__pdc.AutoSize = true;
            this.label__pdc.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label__pdc.Location = new System.Drawing.Point(347, 477);
            this.label__pdc.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label__pdc.Name = "label__pdc";
            this.label__pdc.Size = new System.Drawing.Size(55, 20);
            this.label__pdc.TabIndex = 385;
            this.label__pdc.Text = "PDC :";
            // 
            // panel_hist
            // 
            this.panel_hist.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel_hist.Controls.Add(this.button_close_hist);
            this.panel_hist.Controls.Add(this.dataGridView_hist);
            this.panel_hist.Location = new System.Drawing.Point(310, 20);
            this.panel_hist.Margin = new System.Windows.Forms.Padding(4);
            this.panel_hist.Name = "panel_hist";
            this.panel_hist.Size = new System.Drawing.Size(878, 202);
            this.panel_hist.TabIndex = 384;
            // 
            // button_close_hist
            // 
            this.button_close_hist.Location = new System.Drawing.Point(405, 164);
            this.button_close_hist.Margin = new System.Windows.Forms.Padding(4);
            this.button_close_hist.Name = "button_close_hist";
            this.button_close_hist.Size = new System.Drawing.Size(68, 28);
            this.button_close_hist.TabIndex = 385;
            this.button_close_hist.Text = "Close";
            this.button_close_hist.UseVisualStyleBackColor = true;
            this.button_close_hist.Click += new System.EventHandler(this.button_close_hist_Click);
            // 
            // dataGridView_hist
            // 
            this.dataGridView_hist.AllowUserToAddRows = false;
            this.dataGridView_hist.AllowUserToDeleteRows = false;
            this.dataGridView_hist.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView_hist.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_hist.Location = new System.Drawing.Point(4, 5);
            this.dataGridView_hist.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridView_hist.Name = "dataGridView_hist";
            this.dataGridView_hist.ReadOnly = true;
            this.dataGridView_hist.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView_hist.Size = new System.Drawing.Size(870, 151);
            this.dataGridView_hist.TabIndex = 382;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.date_pdc);
            this.panel1.Controls.Add(this.label_pdc);
            this.panel1.Controls.Add(this.comboBox_bank);
            this.panel1.Controls.Add(this.label_bank);
            this.panel1.Controls.Add(this.textBox_checknumber_cheque);
            this.panel1.Controls.Add(this.button_cancell);
            this.panel1.Controls.Add(this.button_payy);
            this.panel1.Controls.Add(this.labelcheck);
            this.panel1.Controls.Add(this.comboBox_mop);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.textBox_amount_cashcheque);
            this.panel1.Location = new System.Drawing.Point(777, 248);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(357, 239);
            this.panel1.TabIndex = 376;
            // 
            // date_pdc
            // 
            this.date_pdc.CustomFormat = "yyyy-MM-dd";
            this.date_pdc.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.date_pdc.Location = new System.Drawing.Point(166, 157);
            this.date_pdc.Margin = new System.Windows.Forms.Padding(4);
            this.date_pdc.Name = "date_pdc";
            this.date_pdc.Size = new System.Drawing.Size(163, 22);
            this.date_pdc.TabIndex = 387;
            // 
            // label_pdc
            // 
            this.label_pdc.AutoSize = true;
            this.label_pdc.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_pdc.Location = new System.Drawing.Point(19, 155);
            this.label_pdc.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_pdc.Name = "label_pdc";
            this.label_pdc.Size = new System.Drawing.Size(89, 20);
            this.label_pdc.TabIndex = 386;
            this.label_pdc.Text = "Post Date:";
            // 
            // comboBox_bank
            // 
            this.comboBox_bank.FormattingEnabled = true;
            this.comboBox_bank.Items.AddRange(new object[] {
            "BDO",
            "BPI",
            "SECURITY"});
            this.comboBox_bank.Location = new System.Drawing.Point(164, 122);
            this.comboBox_bank.Margin = new System.Windows.Forms.Padding(4);
            this.comboBox_bank.Name = "comboBox_bank";
            this.comboBox_bank.Size = new System.Drawing.Size(164, 24);
            this.comboBox_bank.TabIndex = 385;
            // 
            // label_bank
            // 
            this.label_bank.AutoSize = true;
            this.label_bank.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_bank.Location = new System.Drawing.Point(19, 122);
            this.label_bank.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_bank.Name = "label_bank";
            this.label_bank.Size = new System.Drawing.Size(52, 20);
            this.label_bank.TabIndex = 384;
            this.label_bank.Text = "Bank:";
            // 
            // textBox_checknumber_cheque
            // 
            this.textBox_checknumber_cheque.Location = new System.Drawing.Point(164, 85);
            this.textBox_checknumber_cheque.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_checknumber_cheque.Name = "textBox_checknumber_cheque";
            this.textBox_checknumber_cheque.Size = new System.Drawing.Size(164, 22);
            this.textBox_checknumber_cheque.TabIndex = 383;
            // 
            // button_cancell
            // 
            this.button_cancell.Location = new System.Drawing.Point(196, 193);
            this.button_cancell.Margin = new System.Windows.Forms.Padding(4);
            this.button_cancell.Name = "button_cancell";
            this.button_cancell.Size = new System.Drawing.Size(100, 28);
            this.button_cancell.TabIndex = 382;
            this.button_cancell.Text = "Cancel";
            this.button_cancell.UseVisualStyleBackColor = true;
            this.button_cancell.Click += new System.EventHandler(this.button_cancell_Click);
            // 
            // button_payy
            // 
            this.button_payy.Location = new System.Drawing.Point(80, 194);
            this.button_payy.Margin = new System.Windows.Forms.Padding(4);
            this.button_payy.Name = "button_payy";
            this.button_payy.Size = new System.Drawing.Size(100, 28);
            this.button_payy.TabIndex = 377;
            this.button_payy.Text = "Pay";
            this.button_payy.UseVisualStyleBackColor = true;
            this.button_payy.Click += new System.EventHandler(this.button_payy_Click);
            // 
            // labelcheck
            // 
            this.labelcheck.AutoSize = true;
            this.labelcheck.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelcheck.Location = new System.Drawing.Point(19, 90);
            this.labelcheck.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelcheck.Name = "labelcheck";
            this.labelcheck.Size = new System.Drawing.Size(125, 20);
            this.labelcheck.TabIndex = 380;
            this.labelcheck.Text = "Check Number:";
            // 
            // comboBox_mop
            // 
            this.comboBox_mop.FormattingEnabled = true;
            this.comboBox_mop.Items.AddRange(new object[] {
            "Cash",
            "Cheque"});
            this.comboBox_mop.Location = new System.Drawing.Point(164, 50);
            this.comboBox_mop.Margin = new System.Windows.Forms.Padding(4);
            this.comboBox_mop.Name = "comboBox_mop";
            this.comboBox_mop.Size = new System.Drawing.Size(164, 24);
            this.comboBox_mop.TabIndex = 378;
            this.comboBox_mop.SelectedIndexChanged += new System.EventHandler(this.comboBox_mop_SelectedIndexChanged);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Lucida Console", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Black;
            this.label12.Location = new System.Drawing.Point(20, 23);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(78, 17);
            this.label12.TabIndex = 377;
            this.label12.Text = "Amount:";
            // 
            // textBox_amount_cashcheque
            // 
            this.textBox_amount_cashcheque.Location = new System.Drawing.Point(164, 18);
            this.textBox_amount_cashcheque.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_amount_cashcheque.Name = "textBox_amount_cashcheque";
            this.textBox_amount_cashcheque.Size = new System.Drawing.Size(164, 22);
            this.textBox_amount_cashcheque.TabIndex = 0;
            // 
            // label_paymentdue
            // 
            this.label_paymentdue.AutoSize = true;
            this.label_paymentdue.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_paymentdue.Location = new System.Drawing.Point(348, 448);
            this.label_paymentdue.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_paymentdue.Name = "label_paymentdue";
            this.label_paymentdue.Size = new System.Drawing.Size(120, 20);
            this.label_paymentdue.TabIndex = 374;
            this.label_paymentdue.Text = "Payment Due :";
            // 
            // label_amountpaid
            // 
            this.label_amountpaid.AutoSize = true;
            this.label_amountpaid.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_amountpaid.Location = new System.Drawing.Point(347, 315);
            this.label_amountpaid.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_amountpaid.Name = "label_amountpaid";
            this.label_amountpaid.Size = new System.Drawing.Size(109, 20);
            this.label_amountpaid.TabIndex = 373;
            this.label_amountpaid.Text = "Amount Paid:";
            // 
            // button_paymenthist
            // 
            this.button_paymenthist.Location = new System.Drawing.Point(716, 313);
            this.button_paymenthist.Margin = new System.Windows.Forms.Padding(4);
            this.button_paymenthist.Name = "button_paymenthist";
            this.button_paymenthist.Size = new System.Drawing.Size(43, 27);
            this.button_paymenthist.TabIndex = 381;
            this.button_paymenthist.Text = "<>";
            this.button_paymenthist.UseVisualStyleBackColor = true;
            this.button_paymenthist.Click += new System.EventHandler(this.button_paymenthist_Click);
            // 
            // label_appointmentt_id
            // 
            this.label_appointmentt_id.AutoSize = true;
            this.label_appointmentt_id.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label_appointmentt_id.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label_appointmentt_id.Location = new System.Drawing.Point(545, 224);
            this.label_appointmentt_id.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_appointmentt_id.Name = "label_appointmentt_id";
            this.label_appointmentt_id.Size = new System.Drawing.Size(56, 17);
            this.label_appointmentt_id.TabIndex = 371;
            this.label_appointmentt_id.Text = "232323";
            this.label_appointmentt_id.Visible = false;
            // 
            // textBox_type
            // 
            this.textBox_type.Enabled = false;
            this.textBox_type.Location = new System.Drawing.Point(610, 248);
            this.textBox_type.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_type.Name = "textBox_type";
            this.textBox_type.ReadOnly = true;
            this.textBox_type.Size = new System.Drawing.Size(97, 22);
            this.textBox_type.TabIndex = 369;
            // 
            // label_treatment_id
            // 
            this.label_treatment_id.AutoSize = true;
            this.label_treatment_id.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label_treatment_id.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label_treatment_id.Location = new System.Drawing.Point(485, 224);
            this.label_treatment_id.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_treatment_id.Name = "label_treatment_id";
            this.label_treatment_id.Size = new System.Drawing.Size(56, 17);
            this.label_treatment_id.TabIndex = 368;
            this.label_treatment_id.Text = "232323";
            this.label_treatment_id.Visible = false;
            // 
            // label_paymentdate
            // 
            this.label_paymentdate.AutoSize = true;
            this.label_paymentdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_paymentdate.Location = new System.Drawing.Point(347, 417);
            this.label_paymentdate.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_paymentdate.Name = "label_paymentdate";
            this.label_paymentdate.Size = new System.Drawing.Size(125, 20);
            this.label_paymentdate.TabIndex = 367;
            this.label_paymentdate.Text = "Payment Date :";
            // 
            // date_payment
            // 
            this.date_payment.CustomFormat = "yyyy-MM-dd";
            this.date_payment.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.date_payment.Location = new System.Drawing.Point(506, 411);
            this.date_payment.Margin = new System.Windows.Forms.Padding(4);
            this.date_payment.Name = "date_payment";
            this.date_payment.Size = new System.Drawing.Size(200, 22);
            this.date_payment.TabIndex = 13;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(347, 249);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(139, 20);
            this.label11.TabIndex = 365;
            this.label11.Text = "Mode of Payment";
            // 
            // label_appntid
            // 
            this.label_appntid.AutoSize = true;
            this.label_appntid.Location = new System.Drawing.Point(601, 10);
            this.label_appntid.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_appntid.Name = "label_appntid";
            this.label_appntid.Size = new System.Drawing.Size(0, 17);
            this.label_appntid.TabIndex = 166;
            this.label_appntid.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.label_appntid.Visible = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Lucida Console", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(318, 226);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(158, 17);
            this.label4.TabIndex = 162;
            this.label4.Text = "Invoice Details";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Lucida Console", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(318, 6);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(168, 17);
            this.label9.TabIndex = 161;
            this.label9.Text = "Dental Operation";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Lucida Console", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(39, 9);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(118, 17);
            this.label10.TabIndex = 160;
            this.label10.Text = "Appointment";
            // 
            // DGV_dentaloperation
            // 
            this.DGV_dentaloperation.AllowUserToAddRows = false;
            this.DGV_dentaloperation.AllowUserToDeleteRows = false;
            this.DGV_dentaloperation.BackgroundColor = System.Drawing.Color.White;
            this.DGV_dentaloperation.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGV_dentaloperation.Location = new System.Drawing.Point(309, 30);
            this.DGV_dentaloperation.Margin = new System.Windows.Forms.Padding(4);
            this.DGV_dentaloperation.Name = "DGV_dentaloperation";
            this.DGV_dentaloperation.ReadOnly = true;
            this.DGV_dentaloperation.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DGV_dentaloperation.Size = new System.Drawing.Size(835, 190);
            this.DGV_dentaloperation.TabIndex = 155;
            this.DGV_dentaloperation.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DGV_dentaloperation_CellContentClick);
            // 
            // textBox_mop
            // 
            this.textBox_mop.Enabled = false;
            this.textBox_mop.Location = new System.Drawing.Point(507, 248);
            this.textBox_mop.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_mop.Name = "textBox_mop";
            this.textBox_mop.ReadOnly = true;
            this.textBox_mop.Size = new System.Drawing.Size(97, 22);
            this.textBox_mop.TabIndex = 356;
            // 
            // checknumber
            // 
            this.checknumber.AutoSize = true;
            this.checknumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checknumber.Location = new System.Drawing.Point(347, 383);
            this.checknumber.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.checknumber.Name = "checknumber";
            this.checknumber.Size = new System.Drawing.Size(130, 20);
            this.checknumber.TabIndex = 350;
            this.checknumber.Text = "Check Number :";
            this.checknumber.Click += new System.EventHandler(this.checknumber_Click);
            // 
            // textBox_grandtotal
            // 
            this.textBox_grandtotal.Enabled = false;
            this.textBox_grandtotal.Location = new System.Drawing.Point(507, 277);
            this.textBox_grandtotal.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_grandtotal.Name = "textBox_grandtotal";
            this.textBox_grandtotal.ReadOnly = true;
            this.textBox_grandtotal.Size = new System.Drawing.Size(200, 22);
            this.textBox_grandtotal.TabIndex = 0;
            // 
            // textBox_Checknumber
            // 
            this.textBox_Checknumber.Enabled = false;
            this.textBox_Checknumber.Location = new System.Drawing.Point(504, 381);
            this.textBox_Checknumber.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_Checknumber.Name = "textBox_Checknumber";
            this.textBox_Checknumber.ReadOnly = true;
            this.textBox_Checknumber.Size = new System.Drawing.Size(201, 22);
            this.textBox_Checknumber.TabIndex = 0;
            // 
            // grandtotal
            // 
            this.grandtotal.AutoSize = true;
            this.grandtotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grandtotal.Location = new System.Drawing.Point(348, 282);
            this.grandtotal.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.grandtotal.Name = "grandtotal";
            this.grandtotal.Size = new System.Drawing.Size(102, 20);
            this.grandtotal.TabIndex = 8;
            this.grandtotal.Text = "Grand Total:";
            // 
            // textBox_amount_paid
            // 
            this.textBox_amount_paid.Enabled = false;
            this.textBox_amount_paid.Location = new System.Drawing.Point(507, 313);
            this.textBox_amount_paid.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_amount_paid.Name = "textBox_amount_paid";
            this.textBox_amount_paid.ReadOnly = true;
            this.textBox_amount_paid.Size = new System.Drawing.Size(200, 22);
            this.textBox_amount_paid.TabIndex = 372;
            // 
            // due_payment
            // 
            this.due_payment.CustomFormat = "yyyy-MM-dd";
            this.due_payment.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.due_payment.Location = new System.Drawing.Point(506, 443);
            this.due_payment.Margin = new System.Windows.Forms.Padding(4);
            this.due_payment.Name = "due_payment";
            this.due_payment.Size = new System.Drawing.Size(200, 22);
            this.due_payment.TabIndex = 375;
            // 
            // DGV_applist
            // 
            this.DGV_applist.AllowUserToAddRows = false;
            this.DGV_applist.AllowUserToDeleteRows = false;
            this.DGV_applist.BackgroundColor = System.Drawing.Color.White;
            this.DGV_applist.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGV_applist.Location = new System.Drawing.Point(43, 31);
            this.DGV_applist.Margin = new System.Windows.Forms.Padding(4);
            this.DGV_applist.Name = "DGV_applist";
            this.DGV_applist.ReadOnly = true;
            this.DGV_applist.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DGV_applist.Size = new System.Drawing.Size(267, 475);
            this.DGV_applist.TabIndex = 389;
            this.DGV_applist.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DGV_applist_CellContentClick);
            // 
            // DGV_appointment
            // 
            this.DGV_appointment.AllowUserToAddRows = false;
            this.DGV_appointment.AllowUserToDeleteRows = false;
            this.DGV_appointment.BackgroundColor = System.Drawing.Color.White;
            this.DGV_appointment.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGV_appointment.Location = new System.Drawing.Point(43, 30);
            this.DGV_appointment.Margin = new System.Windows.Forms.Padding(4);
            this.DGV_appointment.Name = "DGV_appointment";
            this.DGV_appointment.ReadOnly = true;
            this.DGV_appointment.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DGV_appointment.Size = new System.Drawing.Size(267, 475);
            this.DGV_appointment.TabIndex = 154;
            this.DGV_appointment.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DGV_appointment_CellContentClick);
            // 
            // paneldental
            // 
            this.paneldental.Controls.Add(this.dataGridView_ov);
            this.paneldental.Controls.Add(this.button_view);
            this.paneldental.Controls.Add(this.patient_name);
            this.paneldental.Controls.Add(this.date_due);
            this.paneldental.Controls.Add(this.L30);
            this.paneldental.Controls.Add(this.L29);
            this.paneldental.Controls.Add(this.L23);
            this.paneldental.Controls.Add(this.U10);
            this.paneldental.Controls.Add(this.U11);
            this.paneldental.Controls.Add(this.U12);
            this.paneldental.Controls.Add(this.U13);
            this.paneldental.Controls.Add(this.U14);
            this.paneldental.Controls.Add(this.U15);
            this.paneldental.Controls.Add(this.U16);
            this.paneldental.Controls.Add(this.L17);
            this.paneldental.Controls.Add(this.L18);
            this.paneldental.Controls.Add(this.L19);
            this.paneldental.Controls.Add(this.L20);
            this.paneldental.Controls.Add(this.L21);
            this.paneldental.Controls.Add(this.U9);
            this.paneldental.Controls.Add(this.U8);
            this.paneldental.Controls.Add(this.U7);
            this.paneldental.Controls.Add(this.U6);
            this.paneldental.Controls.Add(this.U5);
            this.paneldental.Controls.Add(this.L22);
            this.paneldental.Controls.Add(this.L24);
            this.paneldental.Controls.Add(this.L25);
            this.paneldental.Controls.Add(this.L26);
            this.paneldental.Controls.Add(this.L27);
            this.paneldental.Controls.Add(this.L28);
            this.paneldental.Controls.Add(this.U3);
            this.paneldental.Controls.Add(this.L31);
            this.paneldental.Controls.Add(this.U4);
            this.paneldental.Controls.Add(this.U2);
            this.paneldental.Controls.Add(this.U1);
            this.paneldental.Controls.Add(this.L32);
            this.paneldental.Controls.Add(this.L);
            this.paneldental.Controls.Add(this.DGV_paymenthist);
            this.paneldental.Controls.Add(this.bunifuCustomLabel1);
            this.paneldental.Location = new System.Drawing.Point(1, 113);
            this.paneldental.Margin = new System.Windows.Forms.Padding(4);
            this.paneldental.Name = "paneldental";
            this.paneldental.Size = new System.Drawing.Size(1188, 551);
            this.paneldental.TabIndex = 165;
            // 
            // dataGridView_ov
            // 
            this.dataGridView_ov.AllowUserToAddRows = false;
            this.dataGridView_ov.AllowUserToDeleteRows = false;
            this.dataGridView_ov.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView_ov.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_ov.Location = new System.Drawing.Point(15, 300);
            this.dataGridView_ov.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridView_ov.Name = "dataGridView_ov";
            this.dataGridView_ov.ReadOnly = true;
            this.dataGridView_ov.Size = new System.Drawing.Size(632, 217);
            this.dataGridView_ov.TabIndex = 385;
            // 
            // button_view
            // 
            this.button_view.Activecolor = System.Drawing.Color.Teal;
            this.button_view.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(229)))), ((int)(((byte)(229)))));
            this.button_view.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button_view.BorderRadius = 0;
            this.button_view.ButtonText = "View";
            this.button_view.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_view.DisabledColor = System.Drawing.Color.Gray;
            this.button_view.Iconcolor = System.Drawing.Color.Transparent;
            this.button_view.Iconimage = null;
            this.button_view.Iconimage_right = null;
            this.button_view.Iconimage_right_Selected = null;
            this.button_view.Iconimage_Selected = null;
            this.button_view.IconMarginLeft = 0;
            this.button_view.IconMarginRight = 0;
            this.button_view.IconRightVisible = true;
            this.button_view.IconRightZoom = 0D;
            this.button_view.IconVisible = true;
            this.button_view.IconZoom = 70D;
            this.button_view.IsTab = false;
            this.button_view.Location = new System.Drawing.Point(472, 30);
            this.button_view.Margin = new System.Windows.Forms.Padding(5);
            this.button_view.Name = "button_view";
            this.button_view.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(229)))), ((int)(((byte)(229)))));
            this.button_view.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(216)))), ((int)(((byte)(216)))));
            this.button_view.OnHoverTextColor = System.Drawing.Color.White;
            this.button_view.selected = false;
            this.button_view.Size = new System.Drawing.Size(184, 30);
            this.button_view.TabIndex = 251;
            this.button_view.Text = "View";
            this.button_view.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.button_view.Textcolor = System.Drawing.Color.Black;
            this.button_view.TextFont = new System.Drawing.Font("Lucida Console", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_view.Visible = false;
            this.button_view.Click += new System.EventHandler(this.button_view_Click);
            // 
            // patient_name
            // 
            this.patient_name.AutoSize = true;
            this.patient_name.Font = new System.Drawing.Font("Lucida Console", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.patient_name.Location = new System.Drawing.Point(307, 30);
            this.patient_name.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.patient_name.Name = "patient_name";
            this.patient_name.Size = new System.Drawing.Size(157, 30);
            this.patient_name.TabIndex = 250;
            this.patient_name.Text = "--------";
            // 
            // date_due
            // 
            this.date_due.AllowUserToAddRows = false;
            this.date_due.AllowUserToDeleteRows = false;
            this.date_due.BackgroundColor = System.Drawing.Color.White;
            this.date_due.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.date_due.Location = new System.Drawing.Point(15, 89);
            this.date_due.Margin = new System.Windows.Forms.Padding(4);
            this.date_due.Name = "date_due";
            this.date_due.ReadOnly = true;
            this.date_due.Size = new System.Drawing.Size(632, 204);
            this.date_due.TabIndex = 248;
            this.date_due.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.date_due_CellContentClick);
            // 
            // L30
            // 
            this.L30.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.L30.AutoSize = true;
            this.L30.Location = new System.Drawing.Point(767, 359);
            this.L30.Margin = new System.Windows.Forms.Padding(4);
            this.L30.Name = "L30";
            this.L30.Size = new System.Drawing.Size(18, 17);
            this.L30.TabIndex = 247;
            this.L30.UseVisualStyleBackColor = true;
            this.L30.CheckedChanged += new System.EventHandler(this.L30_CheckedChanged);
            // 
            // L29
            // 
            this.L29.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.L29.AutoSize = true;
            this.L29.Location = new System.Drawing.Point(787, 393);
            this.L29.Margin = new System.Windows.Forms.Padding(4);
            this.L29.Name = "L29";
            this.L29.Size = new System.Drawing.Size(18, 17);
            this.L29.TabIndex = 246;
            this.L29.UseVisualStyleBackColor = true;
            this.L29.CheckedChanged += new System.EventHandler(this.L29_CheckedChanged);
            // 
            // L23
            // 
            this.L23.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.L23.AutoSize = true;
            this.L23.Location = new System.Drawing.Point(957, 454);
            this.L23.Margin = new System.Windows.Forms.Padding(4);
            this.L23.Name = "L23";
            this.L23.Size = new System.Drawing.Size(18, 17);
            this.L23.TabIndex = 245;
            this.L23.UseVisualStyleBackColor = true;
            this.L23.CheckedChanged += new System.EventHandler(this.L23_CheckedChanged);
            // 
            // U10
            // 
            this.U10.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.U10.AutoSize = true;
            this.U10.Location = new System.Drawing.Point(975, 69);
            this.U10.Margin = new System.Windows.Forms.Padding(4);
            this.U10.Name = "U10";
            this.U10.Size = new System.Drawing.Size(18, 17);
            this.U10.TabIndex = 244;
            this.U10.UseVisualStyleBackColor = true;
            this.U10.CheckedChanged += new System.EventHandler(this.U10_CheckedChanged);
            // 
            // U11
            // 
            this.U11.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.U11.AutoSize = true;
            this.U11.Location = new System.Drawing.Point(1000, 90);
            this.U11.Margin = new System.Windows.Forms.Padding(4);
            this.U11.Name = "U11";
            this.U11.Size = new System.Drawing.Size(18, 17);
            this.U11.TabIndex = 243;
            this.U11.UseVisualStyleBackColor = true;
            this.U11.CheckedChanged += new System.EventHandler(this.U11_CheckedChanged);
            // 
            // U12
            // 
            this.U12.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.U12.AutoSize = true;
            this.U12.Location = new System.Drawing.Point(1020, 116);
            this.U12.Margin = new System.Windows.Forms.Padding(4);
            this.U12.Name = "U12";
            this.U12.Size = new System.Drawing.Size(18, 17);
            this.U12.TabIndex = 242;
            this.U12.UseVisualStyleBackColor = true;
            this.U12.CheckedChanged += new System.EventHandler(this.U12_CheckedChanged);
            // 
            // U13
            // 
            this.U13.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.U13.AutoSize = true;
            this.U13.Location = new System.Drawing.Point(1044, 143);
            this.U13.Margin = new System.Windows.Forms.Padding(4);
            this.U13.Name = "U13";
            this.U13.Size = new System.Drawing.Size(18, 17);
            this.U13.TabIndex = 241;
            this.U13.UseVisualStyleBackColor = true;
            this.U13.CheckedChanged += new System.EventHandler(this.U13_CheckedChanged);
            // 
            // U14
            // 
            this.U14.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.U14.AutoSize = true;
            this.U14.Location = new System.Drawing.Point(1057, 171);
            this.U14.Margin = new System.Windows.Forms.Padding(4);
            this.U14.Name = "U14";
            this.U14.Size = new System.Drawing.Size(18, 17);
            this.U14.TabIndex = 240;
            this.U14.UseVisualStyleBackColor = true;
            this.U14.CheckedChanged += new System.EventHandler(this.U14_CheckedChanged);
            // 
            // U15
            // 
            this.U15.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.U15.AutoSize = true;
            this.U15.Location = new System.Drawing.Point(1067, 204);
            this.U15.Margin = new System.Windows.Forms.Padding(4);
            this.U15.Name = "U15";
            this.U15.Size = new System.Drawing.Size(18, 17);
            this.U15.TabIndex = 239;
            this.U15.UseVisualStyleBackColor = true;
            this.U15.CheckedChanged += new System.EventHandler(this.U15_CheckedChanged);
            // 
            // U16
            // 
            this.U16.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.U16.AutoSize = true;
            this.U16.Location = new System.Drawing.Point(1061, 238);
            this.U16.Margin = new System.Windows.Forms.Padding(4);
            this.U16.Name = "U16";
            this.U16.Size = new System.Drawing.Size(18, 17);
            this.U16.TabIndex = 238;
            this.U16.UseVisualStyleBackColor = true;
            this.U16.CheckedChanged += new System.EventHandler(this.U16_CheckedChanged);
            // 
            // L17
            // 
            this.L17.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.L17.AutoSize = true;
            this.L17.Location = new System.Drawing.Point(1064, 289);
            this.L17.Margin = new System.Windows.Forms.Padding(4);
            this.L17.Name = "L17";
            this.L17.Size = new System.Drawing.Size(18, 17);
            this.L17.TabIndex = 237;
            this.L17.UseVisualStyleBackColor = true;
            this.L17.CheckedChanged += new System.EventHandler(this.L17_CheckedChanged);
            // 
            // L18
            // 
            this.L18.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.L18.AutoSize = true;
            this.L18.Location = new System.Drawing.Point(1065, 321);
            this.L18.Margin = new System.Windows.Forms.Padding(4);
            this.L18.Name = "L18";
            this.L18.Size = new System.Drawing.Size(18, 17);
            this.L18.TabIndex = 236;
            this.L18.UseVisualStyleBackColor = true;
            this.L18.CheckedChanged += new System.EventHandler(this.L18_CheckedChanged);
            // 
            // L19
            // 
            this.L19.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.L19.AutoSize = true;
            this.L19.Location = new System.Drawing.Point(1059, 356);
            this.L19.Margin = new System.Windows.Forms.Padding(4);
            this.L19.Name = "L19";
            this.L19.Size = new System.Drawing.Size(18, 17);
            this.L19.TabIndex = 235;
            this.L19.UseVisualStyleBackColor = true;
            this.L19.CheckedChanged += new System.EventHandler(this.L19_CheckedChanged);
            // 
            // L20
            // 
            this.L20.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.L20.AutoSize = true;
            this.L20.Location = new System.Drawing.Point(1039, 389);
            this.L20.Margin = new System.Windows.Forms.Padding(4);
            this.L20.Name = "L20";
            this.L20.Size = new System.Drawing.Size(18, 17);
            this.L20.TabIndex = 234;
            this.L20.UseVisualStyleBackColor = true;
            this.L20.CheckedChanged += new System.EventHandler(this.L20_CheckedChanged);
            // 
            // L21
            // 
            this.L21.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.L21.AutoSize = true;
            this.L21.Location = new System.Drawing.Point(1011, 418);
            this.L21.Margin = new System.Windows.Forms.Padding(4);
            this.L21.Name = "L21";
            this.L21.Size = new System.Drawing.Size(18, 17);
            this.L21.TabIndex = 233;
            this.L21.UseVisualStyleBackColor = true;
            this.L21.CheckedChanged += new System.EventHandler(this.L21_CheckedChanged);
            // 
            // U9
            // 
            this.U9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.U9.AutoSize = true;
            this.U9.Location = new System.Drawing.Point(933, 58);
            this.U9.Margin = new System.Windows.Forms.Padding(4);
            this.U9.Name = "U9";
            this.U9.Size = new System.Drawing.Size(18, 17);
            this.U9.TabIndex = 232;
            this.U9.UseVisualStyleBackColor = true;
            this.U9.CheckedChanged += new System.EventHandler(this.U9_CheckedChanged);
            // 
            // U8
            // 
            this.U8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.U8.AutoSize = true;
            this.U8.Location = new System.Drawing.Point(885, 59);
            this.U8.Margin = new System.Windows.Forms.Padding(4);
            this.U8.Name = "U8";
            this.U8.Size = new System.Drawing.Size(18, 17);
            this.U8.TabIndex = 231;
            this.U8.UseVisualStyleBackColor = true;
            this.U8.CheckedChanged += new System.EventHandler(this.U8_CheckedChanged);
            // 
            // U7
            // 
            this.U7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.U7.AutoSize = true;
            this.U7.Location = new System.Drawing.Point(847, 70);
            this.U7.Margin = new System.Windows.Forms.Padding(4);
            this.U7.Name = "U7";
            this.U7.Size = new System.Drawing.Size(18, 17);
            this.U7.TabIndex = 230;
            this.U7.UseVisualStyleBackColor = true;
            this.U7.CheckedChanged += new System.EventHandler(this.U7_CheckedChanged);
            // 
            // U6
            // 
            this.U6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.U6.AutoSize = true;
            this.U6.Location = new System.Drawing.Point(819, 89);
            this.U6.Margin = new System.Windows.Forms.Padding(4);
            this.U6.Name = "U6";
            this.U6.Size = new System.Drawing.Size(18, 17);
            this.U6.TabIndex = 229;
            this.U6.UseVisualStyleBackColor = true;
            this.U6.CheckedChanged += new System.EventHandler(this.U6_CheckedChanged);
            // 
            // U5
            // 
            this.U5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.U5.AutoSize = true;
            this.U5.Location = new System.Drawing.Point(796, 113);
            this.U5.Margin = new System.Windows.Forms.Padding(4);
            this.U5.Name = "U5";
            this.U5.Size = new System.Drawing.Size(18, 17);
            this.U5.TabIndex = 228;
            this.U5.UseVisualStyleBackColor = true;
            this.U5.CheckedChanged += new System.EventHandler(this.U5_CheckedChanged);
            // 
            // L22
            // 
            this.L22.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.L22.AutoSize = true;
            this.L22.Location = new System.Drawing.Point(984, 442);
            this.L22.Margin = new System.Windows.Forms.Padding(4);
            this.L22.Name = "L22";
            this.L22.Size = new System.Drawing.Size(18, 17);
            this.L22.TabIndex = 227;
            this.L22.UseVisualStyleBackColor = true;
            this.L22.CheckedChanged += new System.EventHandler(this.L22_CheckedChanged);
            // 
            // L24
            // 
            this.L24.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.L24.AutoSize = true;
            this.L24.Location = new System.Drawing.Point(927, 459);
            this.L24.Margin = new System.Windows.Forms.Padding(4);
            this.L24.Name = "L24";
            this.L24.Size = new System.Drawing.Size(18, 17);
            this.L24.TabIndex = 226;
            this.L24.UseVisualStyleBackColor = true;
            this.L24.CheckedChanged += new System.EventHandler(this.L24_CheckedChanged);
            // 
            // L25
            // 
            this.L25.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.L25.AutoSize = true;
            this.L25.Location = new System.Drawing.Point(896, 460);
            this.L25.Margin = new System.Windows.Forms.Padding(4);
            this.L25.Name = "L25";
            this.L25.Size = new System.Drawing.Size(18, 17);
            this.L25.TabIndex = 225;
            this.L25.UseVisualStyleBackColor = true;
            this.L25.CheckedChanged += new System.EventHandler(this.L25_CheckedChanged);
            // 
            // L26
            // 
            this.L26.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.L26.AutoSize = true;
            this.L26.Location = new System.Drawing.Point(867, 455);
            this.L26.Margin = new System.Windows.Forms.Padding(4);
            this.L26.Name = "L26";
            this.L26.Size = new System.Drawing.Size(18, 17);
            this.L26.TabIndex = 224;
            this.L26.UseVisualStyleBackColor = true;
            this.L26.CheckedChanged += new System.EventHandler(this.L26_CheckedChanged);
            // 
            // L27
            // 
            this.L27.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.L27.AutoSize = true;
            this.L27.Location = new System.Drawing.Point(839, 443);
            this.L27.Margin = new System.Windows.Forms.Padding(4);
            this.L27.Name = "L27";
            this.L27.Size = new System.Drawing.Size(18, 17);
            this.L27.TabIndex = 223;
            this.L27.UseVisualStyleBackColor = true;
            this.L27.CheckedChanged += new System.EventHandler(this.L27_CheckedChanged);
            // 
            // L28
            // 
            this.L28.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.L28.AutoSize = true;
            this.L28.Location = new System.Drawing.Point(815, 421);
            this.L28.Margin = new System.Windows.Forms.Padding(4);
            this.L28.Name = "L28";
            this.L28.Size = new System.Drawing.Size(18, 17);
            this.L28.TabIndex = 222;
            this.L28.UseVisualStyleBackColor = true;
            this.L28.CheckedChanged += new System.EventHandler(this.L28_CheckedChanged);
            // 
            // U3
            // 
            this.U3.AutoSize = true;
            this.U3.Location = new System.Drawing.Point(761, 171);
            this.U3.Margin = new System.Windows.Forms.Padding(4);
            this.U3.Name = "U3";
            this.U3.Size = new System.Drawing.Size(18, 17);
            this.U3.TabIndex = 221;
            this.U3.UseVisualStyleBackColor = true;
            this.U3.CheckedChanged += new System.EventHandler(this.U3_CheckedChanged);
            // 
            // L31
            // 
            this.L31.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.L31.AutoSize = true;
            this.L31.Location = new System.Drawing.Point(757, 325);
            this.L31.Margin = new System.Windows.Forms.Padding(4);
            this.L31.Name = "L31";
            this.L31.Size = new System.Drawing.Size(18, 17);
            this.L31.TabIndex = 220;
            this.L31.UseVisualStyleBackColor = true;
            this.L31.CheckedChanged += new System.EventHandler(this.L31_CheckedChanged);
            // 
            // U4
            // 
            this.U4.AutoSize = true;
            this.U4.Location = new System.Drawing.Point(777, 140);
            this.U4.Margin = new System.Windows.Forms.Padding(4);
            this.U4.Name = "U4";
            this.U4.Size = new System.Drawing.Size(18, 17);
            this.U4.TabIndex = 219;
            this.U4.UseVisualStyleBackColor = true;
            this.U4.CheckedChanged += new System.EventHandler(this.U4_CheckedChanged);
            // 
            // U2
            // 
            this.U2.AutoSize = true;
            this.U2.Location = new System.Drawing.Point(753, 204);
            this.U2.Margin = new System.Windows.Forms.Padding(4);
            this.U2.Name = "U2";
            this.U2.Size = new System.Drawing.Size(18, 17);
            this.U2.TabIndex = 218;
            this.U2.UseVisualStyleBackColor = true;
            this.U2.CheckedChanged += new System.EventHandler(this.U2_CheckedChanged);
            // 
            // U1
            // 
            this.U1.AutoSize = true;
            this.U1.Location = new System.Drawing.Point(755, 234);
            this.U1.Margin = new System.Windows.Forms.Padding(4);
            this.U1.Name = "U1";
            this.U1.Size = new System.Drawing.Size(18, 17);
            this.U1.TabIndex = 217;
            this.U1.UseVisualStyleBackColor = true;
            this.U1.CheckedChanged += new System.EventHandler(this.U1_CheckedChanged);
            // 
            // L32
            // 
            this.L32.AutoSize = true;
            this.L32.Location = new System.Drawing.Point(759, 287);
            this.L32.Margin = new System.Windows.Forms.Padding(4);
            this.L32.Name = "L32";
            this.L32.Size = new System.Drawing.Size(18, 17);
            this.L32.TabIndex = 216;
            this.L32.UseVisualStyleBackColor = true;
            this.L32.CheckedChanged += new System.EventHandler(this.L32_CheckedChanged);
            // 
            // L
            // 
            this.L.Image = ((System.Drawing.Image)(resources.GetObject("L.Image")));
            this.L.Location = new System.Drawing.Point(680, -1);
            this.L.Margin = new System.Windows.Forms.Padding(4);
            this.L.Name = "L";
            this.L.Size = new System.Drawing.Size(488, 555);
            this.L.TabIndex = 215;
            this.L.TabStop = false;
            this.L.Click += new System.EventHandler(this.L_Click);
            // 
            // DGV_paymenthist
            // 
            this.DGV_paymenthist.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGV_paymenthist.Location = new System.Drawing.Point(681, 2);
            this.DGV_paymenthist.Margin = new System.Windows.Forms.Padding(4);
            this.DGV_paymenthist.Name = "DGV_paymenthist";
            this.DGV_paymenthist.Size = new System.Drawing.Size(349, 209);
            this.DGV_paymenthist.TabIndex = 384;
            // 
            // bunifuCustomLabel1
            // 
            this.bunifuCustomLabel1.AutoSize = true;
            this.bunifuCustomLabel1.Font = new System.Drawing.Font("Lucida Console", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel1.Location = new System.Drawing.Point(19, 30);
            this.bunifuCustomLabel1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.bunifuCustomLabel1.Name = "bunifuCustomLabel1";
            this.bunifuCustomLabel1.Size = new System.Drawing.Size(247, 30);
            this.bunifuCustomLabel1.TabIndex = 249;
            this.bunifuCustomLabel1.Text = "Patient Name:";
            // 
            // button_searchday
            // 
            this.button_searchday.ActiveBorderThickness = 1;
            this.button_searchday.ActiveCornerRadius = 20;
            this.button_searchday.ActiveFillColor = System.Drawing.Color.Aquamarine;
            this.button_searchday.ActiveForecolor = System.Drawing.Color.Black;
            this.button_searchday.ActiveLineColor = System.Drawing.Color.White;
            this.button_searchday.BackColor = System.Drawing.SystemColors.Control;
            this.button_searchday.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button_searchday.BackgroundImage")));
            this.button_searchday.ButtonText = "Search";
            this.button_searchday.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_searchday.Font = new System.Drawing.Font("Lucida Console", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_searchday.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(202)))), ((int)(((byte)(254)))));
            this.button_searchday.IdleBorderThickness = 1;
            this.button_searchday.IdleCornerRadius = 20;
            this.button_searchday.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(233)))), ((int)(((byte)(233)))), ((int)(((byte)(233)))));
            this.button_searchday.IdleForecolor = System.Drawing.Color.Black;
            this.button_searchday.IdleLineColor = System.Drawing.Color.Black;
            this.button_searchday.Location = new System.Drawing.Point(243, 48);
            this.button_searchday.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.button_searchday.Name = "button_searchday";
            this.button_searchday.Size = new System.Drawing.Size(76, 33);
            this.button_searchday.TabIndex = 164;
            this.button_searchday.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button_searchmonth
            // 
            this.button_searchmonth.ActiveBorderThickness = 1;
            this.button_searchmonth.ActiveCornerRadius = 20;
            this.button_searchmonth.ActiveFillColor = System.Drawing.Color.Aquamarine;
            this.button_searchmonth.ActiveForecolor = System.Drawing.Color.Black;
            this.button_searchmonth.ActiveLineColor = System.Drawing.Color.White;
            this.button_searchmonth.BackColor = System.Drawing.SystemColors.Control;
            this.button_searchmonth.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button_searchmonth.BackgroundImage")));
            this.button_searchmonth.ButtonText = "Search";
            this.button_searchmonth.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_searchmonth.Font = new System.Drawing.Font("Lucida Console", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_searchmonth.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(202)))), ((int)(((byte)(254)))));
            this.button_searchmonth.IdleBorderThickness = 1;
            this.button_searchmonth.IdleCornerRadius = 20;
            this.button_searchmonth.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(233)))), ((int)(((byte)(233)))), ((int)(((byte)(233)))));
            this.button_searchmonth.IdleForecolor = System.Drawing.Color.Black;
            this.button_searchmonth.IdleLineColor = System.Drawing.Color.Black;
            this.button_searchmonth.Location = new System.Drawing.Point(583, 48);
            this.button_searchmonth.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.button_searchmonth.Name = "button_searchmonth";
            this.button_searchmonth.Size = new System.Drawing.Size(75, 33);
            this.button_searchmonth.TabIndex = 163;
            this.button_searchmonth.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tab_medicalhist
            // 
            this.tab_medicalhist.Activecolor = System.Drawing.Color.Teal;
            this.tab_medicalhist.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(229)))), ((int)(((byte)(229)))));
            this.tab_medicalhist.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tab_medicalhist.BorderRadius = 0;
            this.tab_medicalhist.ButtonText = "Medical History";
            this.tab_medicalhist.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tab_medicalhist.DisabledColor = System.Drawing.Color.Gray;
            this.tab_medicalhist.Iconcolor = System.Drawing.Color.Transparent;
            this.tab_medicalhist.Iconimage = null;
            this.tab_medicalhist.Iconimage_right = null;
            this.tab_medicalhist.Iconimage_right_Selected = null;
            this.tab_medicalhist.Iconimage_Selected = null;
            this.tab_medicalhist.IconMarginLeft = 0;
            this.tab_medicalhist.IconMarginRight = 0;
            this.tab_medicalhist.IconRightVisible = true;
            this.tab_medicalhist.IconRightZoom = 0D;
            this.tab_medicalhist.IconVisible = true;
            this.tab_medicalhist.IconZoom = 70D;
            this.tab_medicalhist.IsTab = false;
            this.tab_medicalhist.Location = new System.Drawing.Point(489, 26);
            this.tab_medicalhist.Margin = new System.Windows.Forms.Padding(5);
            this.tab_medicalhist.Name = "tab_medicalhist";
            this.tab_medicalhist.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(229)))), ((int)(((byte)(229)))));
            this.tab_medicalhist.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(216)))), ((int)(((byte)(216)))));
            this.tab_medicalhist.OnHoverTextColor = System.Drawing.Color.White;
            this.tab_medicalhist.selected = false;
            this.tab_medicalhist.Size = new System.Drawing.Size(243, 59);
            this.tab_medicalhist.TabIndex = 16;
            this.tab_medicalhist.Text = "Medical History";
            this.tab_medicalhist.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.tab_medicalhist.Textcolor = System.Drawing.Color.Black;
            this.tab_medicalhist.TextFont = new System.Drawing.Font("Lucida Console", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tab_medicalhist.Click += new System.EventHandler(this.tab_medicalhist_Click);
            // 
            // tab_dentalchart
            // 
            this.tab_dentalchart.AccessibleDescription = "";
            this.tab_dentalchart.Activecolor = System.Drawing.Color.Teal;
            this.tab_dentalchart.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(229)))), ((int)(((byte)(229)))));
            this.tab_dentalchart.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tab_dentalchart.BorderRadius = 0;
            this.tab_dentalchart.ButtonText = "Tooth History";
            this.tab_dentalchart.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tab_dentalchart.DisabledColor = System.Drawing.Color.Gray;
            this.tab_dentalchart.Iconcolor = System.Drawing.Color.Transparent;
            this.tab_dentalchart.Iconimage = null;
            this.tab_dentalchart.Iconimage_right = null;
            this.tab_dentalchart.Iconimage_right_Selected = null;
            this.tab_dentalchart.Iconimage_Selected = null;
            this.tab_dentalchart.IconMarginLeft = 0;
            this.tab_dentalchart.IconMarginRight = 0;
            this.tab_dentalchart.IconRightVisible = true;
            this.tab_dentalchart.IconRightZoom = 0D;
            this.tab_dentalchart.IconVisible = true;
            this.tab_dentalchart.IconZoom = 70D;
            this.tab_dentalchart.IsTab = false;
            this.tab_dentalchart.Location = new System.Drawing.Point(740, 26);
            this.tab_dentalchart.Margin = new System.Windows.Forms.Padding(5);
            this.tab_dentalchart.Name = "tab_dentalchart";
            this.tab_dentalchart.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(229)))), ((int)(((byte)(229)))));
            this.tab_dentalchart.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(216)))), ((int)(((byte)(216)))));
            this.tab_dentalchart.OnHoverTextColor = System.Drawing.Color.White;
            this.tab_dentalchart.selected = false;
            this.tab_dentalchart.Size = new System.Drawing.Size(243, 59);
            this.tab_dentalchart.TabIndex = 15;
            this.tab_dentalchart.Text = "Tooth History";
            this.tab_dentalchart.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.tab_dentalchart.Textcolor = System.Drawing.Color.Black;
            this.tab_dentalchart.TextFont = new System.Drawing.Font("Lucida Console", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tab_dentalchart.Click += new System.EventHandler(this.tab_dentalchart_Click);
            // 
            // bunifuSeparator1
            // 
            this.bunifuSeparator1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator1.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(105)))), ((int)(((byte)(105)))));
            this.bunifuSeparator1.LineThickness = 1;
            this.bunifuSeparator1.Location = new System.Drawing.Point(147, 92);
            this.bunifuSeparator1.Margin = new System.Windows.Forms.Padding(5);
            this.bunifuSeparator1.Name = "bunifuSeparator1";
            this.bunifuSeparator1.Size = new System.Drawing.Size(929, 27);
            this.bunifuSeparator1.TabIndex = 13;
            this.bunifuSeparator1.Transparency = 255;
            this.bunifuSeparator1.Vertical = false;
            // 
            // tab_patientinfo
            // 
            this.tab_patientinfo.Activecolor = System.Drawing.Color.Teal;
            this.tab_patientinfo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(229)))), ((int)(((byte)(229)))));
            this.tab_patientinfo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tab_patientinfo.BorderRadius = 0;
            this.tab_patientinfo.ButtonText = "Patient Information";
            this.tab_patientinfo.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tab_patientinfo.DisabledColor = System.Drawing.Color.Gray;
            this.tab_patientinfo.Iconcolor = System.Drawing.Color.Transparent;
            this.tab_patientinfo.Iconimage = null;
            this.tab_patientinfo.Iconimage_right = null;
            this.tab_patientinfo.Iconimage_right_Selected = null;
            this.tab_patientinfo.Iconimage_Selected = null;
            this.tab_patientinfo.IconMarginLeft = 0;
            this.tab_patientinfo.IconMarginRight = 0;
            this.tab_patientinfo.IconRightVisible = true;
            this.tab_patientinfo.IconRightZoom = 0D;
            this.tab_patientinfo.IconVisible = true;
            this.tab_patientinfo.IconZoom = 70D;
            this.tab_patientinfo.IsTab = false;
            this.tab_patientinfo.Location = new System.Drawing.Point(239, 26);
            this.tab_patientinfo.Margin = new System.Windows.Forms.Padding(5);
            this.tab_patientinfo.Name = "tab_patientinfo";
            this.tab_patientinfo.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(229)))), ((int)(((byte)(229)))));
            this.tab_patientinfo.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(216)))), ((int)(((byte)(216)))));
            this.tab_patientinfo.OnHoverTextColor = System.Drawing.Color.White;
            this.tab_patientinfo.selected = false;
            this.tab_patientinfo.Size = new System.Drawing.Size(243, 59);
            this.tab_patientinfo.TabIndex = 12;
            this.tab_patientinfo.Text = "Patient Information";
            this.tab_patientinfo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.tab_patientinfo.Textcolor = System.Drawing.Color.Black;
            this.tab_patientinfo.TextFont = new System.Drawing.Font("Lucida Console", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tab_patientinfo.Click += new System.EventHandler(this.tab_patientinfo_Click);
            // 
            // label_id
            // 
            this.label_id.AutoSize = true;
            this.label_id.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label_id.ForeColor = System.Drawing.SystemColors.Control;
            this.label_id.Location = new System.Drawing.Point(53, 42);
            this.label_id.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_id.Name = "label_id";
            this.label_id.Size = new System.Drawing.Size(54, 17);
            this.label_id.TabIndex = 18;
            this.label_id.Text = "label13";
            this.label_id.Visible = false;
            // 
            // patientinfo
            // 
            this.patientinfo.Controls.Add(this.label13);
            this.patientinfo.Controls.Add(this.aa);
            this.patientinfo.Controls.Add(this.panel_pending);
            this.patientinfo.Controls.Add(this.button_pending);
            this.patientinfo.Controls.Add(this.label_apaid);
            this.patientinfo.Controls.Add(this.label_gtotal);
            this.patientinfo.Controls.Add(this.label_status);
            this.patientinfo.Controls.Add(this.button_update);
            this.patientinfo.Controls.Add(this.dataGridView1);
            this.patientinfo.Controls.Add(this.button_reset);
            this.patientinfo.Controls.Add(this.label1);
            this.patientinfo.Controls.Add(this.button_create);
            this.patientinfo.Controls.Add(this.textBox_firstname);
            this.patientinfo.Controls.Add(this.textBox_lastname);
            this.patientinfo.Controls.Add(this.label2);
            this.patientinfo.Controls.Add(this.textBox_address);
            this.patientinfo.Controls.Add(this.label8);
            this.patientinfo.Controls.Add(this.label3);
            this.patientinfo.Controls.Add(this.textBox_contact1);
            this.patientinfo.Controls.Add(this.label5);
            this.patientinfo.Controls.Add(this.birth_date);
            this.patientinfo.Controls.Add(this.combo_gender);
            this.patientinfo.Controls.Add(this.textBox_age);
            this.patientinfo.Controls.Add(this.label6);
            this.patientinfo.Controls.Add(this.label7);
            this.patientinfo.Location = new System.Drawing.Point(-4, 118);
            this.patientinfo.Margin = new System.Windows.Forms.Padding(4);
            this.patientinfo.Name = "patientinfo";
            this.patientinfo.Size = new System.Drawing.Size(1419, 551);
            this.patientinfo.TabIndex = 19;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Lucida Console", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label13.Location = new System.Drawing.Point(848, 7);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(68, 17);
            this.label13.TabIndex = 390;
            this.label13.Text = "Search";
            // 
            // aa
            // 
            this.aa.Font = new System.Drawing.Font("Lucida Console", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.aa.Location = new System.Drawing.Point(852, 27);
            this.aa.Margin = new System.Windows.Forms.Padding(4);
            this.aa.Name = "aa";
            this.aa.Size = new System.Drawing.Size(319, 31);
            this.aa.TabIndex = 389;
            this.aa.TextChanged += new System.EventHandler(this.aa_TextChanged);
            // 
            // panel_pending
            // 
            this.panel_pending.Controls.Add(this.button_exit_pending);
            this.panel_pending.Controls.Add(this.dataGridView_pending);
            this.panel_pending.Location = new System.Drawing.Point(284, 89);
            this.panel_pending.Margin = new System.Windows.Forms.Padding(4);
            this.panel_pending.Name = "panel_pending";
            this.panel_pending.Size = new System.Drawing.Size(877, 409);
            this.panel_pending.TabIndex = 388;
            // 
            // button_exit_pending
            // 
            this.button_exit_pending.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(229)))), ((int)(((byte)(229)))));
            this.button_exit_pending.BackColor = System.Drawing.Color.LightGray;
            this.button_exit_pending.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button_exit_pending.BorderRadius = 0;
            this.button_exit_pending.ButtonText = "X";
            this.button_exit_pending.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_exit_pending.DisabledColor = System.Drawing.Color.Gray;
            this.button_exit_pending.Iconcolor = System.Drawing.Color.Transparent;
            this.button_exit_pending.Iconimage = null;
            this.button_exit_pending.Iconimage_right = null;
            this.button_exit_pending.Iconimage_right_Selected = null;
            this.button_exit_pending.Iconimage_Selected = null;
            this.button_exit_pending.IconMarginLeft = 0;
            this.button_exit_pending.IconMarginRight = 0;
            this.button_exit_pending.IconRightVisible = true;
            this.button_exit_pending.IconRightZoom = 0D;
            this.button_exit_pending.IconVisible = true;
            this.button_exit_pending.IconZoom = 70D;
            this.button_exit_pending.IsTab = false;
            this.button_exit_pending.Location = new System.Drawing.Point(824, 5);
            this.button_exit_pending.Margin = new System.Windows.Forms.Padding(5);
            this.button_exit_pending.Name = "button_exit_pending";
            this.button_exit_pending.Normalcolor = System.Drawing.Color.LightGray;
            this.button_exit_pending.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(216)))), ((int)(((byte)(216)))));
            this.button_exit_pending.OnHoverTextColor = System.Drawing.Color.White;
            this.button_exit_pending.selected = false;
            this.button_exit_pending.Size = new System.Drawing.Size(48, 32);
            this.button_exit_pending.TabIndex = 390;
            this.button_exit_pending.Text = "X";
            this.button_exit_pending.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.button_exit_pending.Textcolor = System.Drawing.Color.Black;
            this.button_exit_pending.TextFont = new System.Drawing.Font("Lucida Console", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_exit_pending.Click += new System.EventHandler(this.button_exit_pending_Click);
            // 
            // dataGridView_pending
            // 
            this.dataGridView_pending.AllowUserToAddRows = false;
            this.dataGridView_pending.AllowUserToDeleteRows = false;
            this.dataGridView_pending.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView_pending.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_pending.Location = new System.Drawing.Point(17, 38);
            this.dataGridView_pending.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridView_pending.Name = "dataGridView_pending";
            this.dataGridView_pending.ReadOnly = true;
            this.dataGridView_pending.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView_pending.Size = new System.Drawing.Size(848, 342);
            this.dataGridView_pending.TabIndex = 389;
            // 
            // button_pending
            // 
            this.button_pending.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(229)))), ((int)(((byte)(229)))), ((int)(((byte)(229)))));
            this.button_pending.BackColor = System.Drawing.Color.LightGray;
            this.button_pending.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button_pending.BorderRadius = 0;
            this.button_pending.ButtonText = "Pending";
            this.button_pending.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_pending.DisabledColor = System.Drawing.Color.Gray;
            this.button_pending.Iconcolor = System.Drawing.Color.Transparent;
            this.button_pending.Iconimage = null;
            this.button_pending.Iconimage_right = null;
            this.button_pending.Iconimage_right_Selected = null;
            this.button_pending.Iconimage_Selected = null;
            this.button_pending.IconMarginLeft = 0;
            this.button_pending.IconMarginRight = 0;
            this.button_pending.IconRightVisible = true;
            this.button_pending.IconRightZoom = 0D;
            this.button_pending.IconVisible = true;
            this.button_pending.IconZoom = 70D;
            this.button_pending.IsTab = false;
            this.button_pending.Location = new System.Drawing.Point(685, 32);
            this.button_pending.Margin = new System.Windows.Forms.Padding(5);
            this.button_pending.Name = "button_pending";
            this.button_pending.Normalcolor = System.Drawing.Color.LightGray;
            this.button_pending.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(216)))), ((int)(((byte)(216)))));
            this.button_pending.OnHoverTextColor = System.Drawing.Color.White;
            this.button_pending.selected = false;
            this.button_pending.Size = new System.Drawing.Size(113, 32);
            this.button_pending.TabIndex = 387;
            this.button_pending.Text = "Pending";
            this.button_pending.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.button_pending.Textcolor = System.Drawing.Color.Black;
            this.button_pending.TextFont = new System.Drawing.Font("Lucida Console", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_pending.Click += new System.EventHandler(this.button_add_supplier_Click);
            // 
            // label_apaid
            // 
            this.label_apaid.AutoSize = true;
            this.label_apaid.ForeColor = System.Drawing.SystemColors.Control;
            this.label_apaid.Location = new System.Drawing.Point(713, 11);
            this.label_apaid.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_apaid.Name = "label_apaid";
            this.label_apaid.Size = new System.Drawing.Size(54, 17);
            this.label_apaid.TabIndex = 386;
            this.label_apaid.Text = "label13";
            // 
            // label_gtotal
            // 
            this.label_gtotal.AutoSize = true;
            this.label_gtotal.ForeColor = System.Drawing.SystemColors.Control;
            this.label_gtotal.Location = new System.Drawing.Point(613, 11);
            this.label_gtotal.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_gtotal.Name = "label_gtotal";
            this.label_gtotal.Size = new System.Drawing.Size(54, 17);
            this.label_gtotal.TabIndex = 385;
            this.label_gtotal.Text = "label13";
            // 
            // label_status
            // 
            this.label_status.AutoSize = true;
            this.label_status.Font = new System.Drawing.Font("Lucida Console", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_status.ForeColor = System.Drawing.Color.Black;
            this.label_status.Location = new System.Drawing.Point(565, 52);
            this.label_status.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_status.Name = "label_status";
            this.label_status.Size = new System.Drawing.Size(0, 17);
            this.label_status.TabIndex = 188;
            // 
            // button_update
            // 
            this.button_update.ActiveBorderThickness = 1;
            this.button_update.ActiveCornerRadius = 20;
            this.button_update.ActiveFillColor = System.Drawing.Color.Aquamarine;
            this.button_update.ActiveForecolor = System.Drawing.Color.Black;
            this.button_update.ActiveLineColor = System.Drawing.Color.White;
            this.button_update.BackColor = System.Drawing.SystemColors.Control;
            this.button_update.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button_update.BackgroundImage")));
            this.button_update.ButtonText = "Update";
            this.button_update.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_update.Font = new System.Drawing.Font("Lucida Console", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_update.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(202)))), ((int)(((byte)(254)))));
            this.button_update.IdleBorderThickness = 1;
            this.button_update.IdleCornerRadius = 20;
            this.button_update.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(233)))), ((int)(((byte)(233)))), ((int)(((byte)(233)))));
            this.button_update.IdleForecolor = System.Drawing.Color.Black;
            this.button_update.IdleLineColor = System.Drawing.Color.Black;
            this.button_update.Location = new System.Drawing.Point(197, 458);
            this.button_update.Margin = new System.Windows.Forms.Padding(7, 5, 7, 5);
            this.button_update.Name = "button_update";
            this.button_update.Size = new System.Drawing.Size(101, 48);
            this.button_update.TabIndex = 186;
            this.button_update.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.button_update.Click += new System.EventHandler(this.button_update_Click_1);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(467, 76);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(701, 447);
            this.dataGridView1.TabIndex = 182;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick_1);
            // 
            // button_reset
            // 
            this.button_reset.ActiveBorderThickness = 1;
            this.button_reset.ActiveCornerRadius = 20;
            this.button_reset.ActiveFillColor = System.Drawing.Color.Aquamarine;
            this.button_reset.ActiveForecolor = System.Drawing.Color.Black;
            this.button_reset.ActiveLineColor = System.Drawing.Color.White;
            this.button_reset.BackColor = System.Drawing.SystemColors.Control;
            this.button_reset.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button_reset.BackgroundImage")));
            this.button_reset.ButtonText = "Reset";
            this.button_reset.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_reset.Font = new System.Drawing.Font("Lucida Console", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_reset.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(202)))), ((int)(((byte)(254)))));
            this.button_reset.IdleBorderThickness = 1;
            this.button_reset.IdleCornerRadius = 20;
            this.button_reset.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(233)))), ((int)(((byte)(233)))), ((int)(((byte)(233)))));
            this.button_reset.IdleForecolor = System.Drawing.Color.Black;
            this.button_reset.IdleLineColor = System.Drawing.Color.Black;
            this.button_reset.Location = new System.Drawing.Point(312, 458);
            this.button_reset.Margin = new System.Windows.Forms.Padding(7, 5, 7, 5);
            this.button_reset.Name = "button_reset";
            this.button_reset.Size = new System.Drawing.Size(101, 48);
            this.button_reset.TabIndex = 185;
            this.button_reset.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.button_reset.Click += new System.EventHandler(this.button_reset_Click_1);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Lucida Console", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(24, 71);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(98, 17);
            this.label1.TabIndex = 168;
            this.label1.Text = "Firstname";
            // 
            // button_create
            // 
            this.button_create.ActiveBorderThickness = 1;
            this.button_create.ActiveCornerRadius = 20;
            this.button_create.ActiveFillColor = System.Drawing.Color.Aquamarine;
            this.button_create.ActiveForecolor = System.Drawing.Color.Black;
            this.button_create.ActiveLineColor = System.Drawing.Color.White;
            this.button_create.BackColor = System.Drawing.SystemColors.Control;
            this.button_create.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button_create.BackgroundImage")));
            this.button_create.ButtonText = "Create";
            this.button_create.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_create.Font = new System.Drawing.Font("Lucida Console", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_create.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(202)))), ((int)(((byte)(254)))));
            this.button_create.IdleBorderThickness = 1;
            this.button_create.IdleCornerRadius = 20;
            this.button_create.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(233)))), ((int)(((byte)(233)))), ((int)(((byte)(233)))));
            this.button_create.IdleForecolor = System.Drawing.Color.Black;
            this.button_create.IdleLineColor = System.Drawing.Color.Black;
            this.button_create.Location = new System.Drawing.Point(83, 458);
            this.button_create.Margin = new System.Windows.Forms.Padding(7, 5, 7, 5);
            this.button_create.Name = "button_create";
            this.button_create.Size = new System.Drawing.Size(101, 48);
            this.button_create.TabIndex = 184;
            this.button_create.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.button_create.Click += new System.EventHandler(this.button_create_Click_1);
            // 
            // textBox_firstname
            // 
            this.textBox_firstname.Font = new System.Drawing.Font("Lucida Console", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_firstname.Location = new System.Drawing.Point(28, 91);
            this.textBox_firstname.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_firstname.Name = "textBox_firstname";
            this.textBox_firstname.Size = new System.Drawing.Size(181, 31);
            this.textBox_firstname.TabIndex = 169;
            // 
            // textBox_lastname
            // 
            this.textBox_lastname.Font = new System.Drawing.Font("Lucida Console", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_lastname.Location = new System.Drawing.Point(219, 91);
            this.textBox_lastname.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_lastname.Name = "textBox_lastname";
            this.textBox_lastname.Size = new System.Drawing.Size(239, 31);
            this.textBox_lastname.TabIndex = 170;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Lucida Console", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(215, 71);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(88, 17);
            this.label2.TabIndex = 171;
            this.label2.Text = "Lastname";
            // 
            // textBox_address
            // 
            this.textBox_address.Font = new System.Drawing.Font("Lucida Console", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_address.Location = new System.Drawing.Point(28, 256);
            this.textBox_address.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_address.Name = "textBox_address";
            this.textBox_address.Size = new System.Drawing.Size(429, 31);
            this.textBox_address.TabIndex = 172;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Lucida Console", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(24, 398);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(108, 17);
            this.label8.TabIndex = 181;
            this.label8.Text = "Contact #1";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Lucida Console", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(24, 236);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(78, 17);
            this.label3.TabIndex = 173;
            this.label3.Text = "Address";
            // 
            // textBox_contact1
            // 
            this.textBox_contact1.Font = new System.Drawing.Font("Lucida Console", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_contact1.Location = new System.Drawing.Point(28, 417);
            this.textBox_contact1.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_contact1.Name = "textBox_contact1";
            this.textBox_contact1.Size = new System.Drawing.Size(429, 31);
            this.textBox_contact1.TabIndex = 180;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Lucida Console", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(24, 313);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(38, 17);
            this.label5.TabIndex = 174;
            this.label5.Text = "Age";
            // 
            // birth_date
            // 
            this.birth_date.CustomFormat = "MMMM dd, yyyy";
            this.birth_date.Font = new System.Drawing.Font("Arial", 12.25F);
            this.birth_date.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.birth_date.Location = new System.Drawing.Point(28, 180);
            this.birth_date.Margin = new System.Windows.Forms.Padding(4);
            this.birth_date.Name = "birth_date";
            this.birth_date.Size = new System.Drawing.Size(429, 31);
            this.birth_date.TabIndex = 179;
            // 
            // combo_gender
            // 
            this.combo_gender.Font = new System.Drawing.Font("Lucida Console", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.combo_gender.FormattingEnabled = true;
            this.combo_gender.Items.AddRange(new object[] {
            "Male",
            "Female"});
            this.combo_gender.Location = new System.Drawing.Point(219, 332);
            this.combo_gender.Margin = new System.Windows.Forms.Padding(4);
            this.combo_gender.Name = "combo_gender";
            this.combo_gender.Size = new System.Drawing.Size(239, 32);
            this.combo_gender.TabIndex = 175;
            // 
            // textBox_age
            // 
            this.textBox_age.Font = new System.Drawing.Font("Lucida Console", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_age.Location = new System.Drawing.Point(28, 332);
            this.textBox_age.Margin = new System.Windows.Forms.Padding(4);
            this.textBox_age.Name = "textBox_age";
            this.textBox_age.Size = new System.Drawing.Size(181, 31);
            this.textBox_age.TabIndex = 178;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Lucida Console", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(215, 313);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(68, 17);
            this.label6.TabIndex = 176;
            this.label6.Text = "Gender";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Lucida Console", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(20, 160);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(98, 17);
            this.label7.TabIndex = 177;
            this.label7.Text = "Birthdate";
            // 
            // form_patient
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1220, 654);
            this.Controls.Add(this.label_id);
            this.Controls.Add(this.tab_medicalhist);
            this.Controls.Add(this.tab_dentalchart);
            this.Controls.Add(this.bunifuSeparator1);
            this.Controls.Add(this.tab_patientinfo);
            this.Controls.Add(this.panelmedhist);
            this.Controls.Add(this.paneldental);
            this.Controls.Add(this.patientinfo);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "form_patient";
            this.Text = "form_patient";
            this.Load += new System.EventHandler(this.form_patient_Load);
            this.panelmedhist.ResumeLayout(false);
            this.panelmedhist.PerformLayout();
            this.panel_accounts.ResumeLayout(false);
            this.panel_accounts.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_accounts)).EndInit();
            this.panel_hist.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_hist)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_dentaloperation)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_applist)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_appointment)).EndInit();
            this.paneldental.ResumeLayout(false);
            this.paneldental.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_ov)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.date_due)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.L)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_paymenthist)).EndInit();
            this.patientinfo.ResumeLayout(false);
            this.patientinfo.PerformLayout();
            this.panel_pending.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_pending)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Bunifu.Framework.UI.BunifuFlatButton tab_medicalhist;
        private Bunifu.Framework.UI.BunifuFlatButton tab_dentalchart;
        private Bunifu.Framework.UI.BunifuSeparator bunifuSeparator1;
        private Bunifu.Framework.UI.BunifuFlatButton tab_patientinfo;
        private System.Windows.Forms.Panel panelmedhist;
        private Bunifu.Framework.UI.BunifuThinButton2 button_searchday;
        private Bunifu.Framework.UI.BunifuThinButton2 button_searchmonth;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.DataGridView DGV_dentaloperation;
        private System.Windows.Forms.Label label_id;
        private System.Windows.Forms.Panel paneldental;
        private Bunifu.Framework.UI.BunifuFlatButton button_view;
        private Bunifu.Framework.UI.BunifuCustomLabel patient_name;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel1;
        private System.Windows.Forms.DataGridView date_due;
        private System.Windows.Forms.CheckBox L30;
        private System.Windows.Forms.CheckBox L29;
        private System.Windows.Forms.CheckBox L23;
        private System.Windows.Forms.CheckBox U10;
        private System.Windows.Forms.CheckBox U11;
        private System.Windows.Forms.CheckBox U12;
        private System.Windows.Forms.CheckBox U13;
        private System.Windows.Forms.CheckBox U14;
        private System.Windows.Forms.CheckBox U15;
        private System.Windows.Forms.CheckBox U16;
        private System.Windows.Forms.CheckBox L17;
        private System.Windows.Forms.CheckBox L18;
        private System.Windows.Forms.CheckBox L19;
        private System.Windows.Forms.CheckBox L20;
        private System.Windows.Forms.CheckBox L21;
        private System.Windows.Forms.CheckBox U9;
        private System.Windows.Forms.CheckBox U8;
        private System.Windows.Forms.CheckBox U7;
        private System.Windows.Forms.CheckBox U6;
        private System.Windows.Forms.CheckBox U5;
        private System.Windows.Forms.CheckBox L22;
        private System.Windows.Forms.CheckBox L24;
        private System.Windows.Forms.CheckBox L25;
        private System.Windows.Forms.CheckBox L26;
        private System.Windows.Forms.CheckBox L27;
        private System.Windows.Forms.CheckBox L28;
        private System.Windows.Forms.CheckBox U3;
        private System.Windows.Forms.CheckBox L31;
        private System.Windows.Forms.CheckBox U4;
        private System.Windows.Forms.CheckBox U2;
        private System.Windows.Forms.CheckBox U1;
        private System.Windows.Forms.CheckBox L32;
        private System.Windows.Forms.PictureBox L;
        private System.Windows.Forms.Panel patientinfo;
        private Bunifu.Framework.UI.BunifuThinButton2 button_update;
        private System.Windows.Forms.DataGridView dataGridView1;
        private Bunifu.Framework.UI.BunifuThinButton2 button_reset;
        private System.Windows.Forms.Label label1;
        private Bunifu.Framework.UI.BunifuThinButton2 button_create;
        private System.Windows.Forms.TextBox textBox_firstname;
        private System.Windows.Forms.TextBox textBox_lastname;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox_address;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox_contact1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DateTimePicker birth_date;
        private System.Windows.Forms.ComboBox combo_gender;
        private System.Windows.Forms.TextBox textBox_age;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label_appntid;
        private System.Windows.Forms.Label label_paymentdate;
        private System.Windows.Forms.DateTimePicker date_payment;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox textBox_mop;
        private System.Windows.Forms.Label checknumber;
        private System.Windows.Forms.TextBox textBox_grandtotal;
        private System.Windows.Forms.TextBox textBox_Checknumber;
        private System.Windows.Forms.Label grandtotal;
        private System.Windows.Forms.Label label_treatment_id;
        private System.Windows.Forms.TextBox textBox_type;
        private System.Windows.Forms.Label label_appointmentt_id;
        private System.Windows.Forms.Label label_amountpaid;
        private System.Windows.Forms.TextBox textBox_amount_paid;
        private System.Windows.Forms.DateTimePicker due_payment;
        private System.Windows.Forms.Label label_paymentdue;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridView DGV_paymenthist;
        private System.Windows.Forms.TextBox textBox_checknumber_cheque;
        private System.Windows.Forms.Button button_cancell;
        private System.Windows.Forms.Button button_payy;
        private System.Windows.Forms.Label labelcheck;
        private System.Windows.Forms.ComboBox comboBox_mop;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox textBox_amount_cashcheque;
        private System.Windows.Forms.Panel panel_hist;
        private System.Windows.Forms.DataGridView dataGridView_hist;
        private System.Windows.Forms.Button button_paymenthist;
        private System.Windows.Forms.Label label_bank;
        private System.Windows.Forms.Button button_close_hist;
        private System.Windows.Forms.ComboBox comboBox_bank;
        private System.Windows.Forms.Label label_status;
        private System.Windows.Forms.Label label_apaid;
        private System.Windows.Forms.Label label_gtotal;
        private System.Windows.Forms.Panel panel_pending;
        private System.Windows.Forms.DataGridView dataGridView_pending;
        private Bunifu.Framework.UI.BunifuFlatButton button_pending;
        private Bunifu.Framework.UI.BunifuFlatButton button_exit_pending;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox aa;
        private System.Windows.Forms.DataGridView dataGridView_ov;
        private System.Windows.Forms.DateTimePicker date_pdc;
        private System.Windows.Forms.Label label_pdc;
        private System.Windows.Forms.Label label__pdc;
        private System.Windows.Forms.DateTimePicker dateTimePicker_pdc;
        private System.Windows.Forms.Label label_balance;
        private System.Windows.Forms.TextBox textBox_balance;
        private System.Windows.Forms.DataGridView DGV_applist;
        private System.Windows.Forms.Button button_accounts;
        private System.Windows.Forms.Panel panel_accounts;
        private System.Windows.Forms.Button button_accounts_close;
        private System.Windows.Forms.DataGridView DGV_accounts;
        private System.Windows.Forms.Label text_balance;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label chosen_balance;
        private System.Windows.Forms.DataGridView DGV_appointment;
    }
}