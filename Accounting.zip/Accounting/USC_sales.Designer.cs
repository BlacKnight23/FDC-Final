﻿namespace Accounting
{
    partial class USC_sales
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.Label label9;
            System.Windows.Forms.Label Label51;
            System.Windows.Forms.Label Label49;
            System.Windows.Forms.Label Label48;
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.PDtxt = new System.Windows.Forms.TextBox();
            this.TPtxt = new System.Windows.Forms.TextBox();
            this.chrgtxt = new System.Windows.Forms.TextBox();
            this.GTtxt = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.button_go = new System.Windows.Forms.GroupBox();
            this.bunifuFlatButton5 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.label7 = new System.Windows.Forms.Label();
            this.dTP3 = new System.Windows.Forms.DateTimePicker();
            this.label6 = new System.Windows.Forms.Label();
            this.dTP2 = new System.Windows.Forms.DateTimePicker();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.textBox_patientname = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.textBox_patientid = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.textBox_invoicedate = new System.Windows.Forms.DateTimePicker();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox_invoiceno = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.bunifuFlatButton6 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuFlatButton4 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuFlatButton3 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.viewall_button = new Bunifu.Framework.UI.BunifuFlatButton();
            label9 = new System.Windows.Forms.Label();
            Label51 = new System.Windows.Forms.Label();
            Label49 = new System.Windows.Forms.Label();
            Label48 = new System.Windows.Forms.Label();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.button_go.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.ForeColor = System.Drawing.Color.Black;
            label9.Location = new System.Drawing.Point(27, 111);
            label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            label9.Name = "label9";
            label9.Size = new System.Drawing.Size(77, 13);
            label9.TabIndex = 320;
            label9.Text = "Payment Due :";
            // 
            // Label51
            // 
            Label51.AutoSize = true;
            Label51.ForeColor = System.Drawing.Color.Black;
            Label51.Location = new System.Drawing.Point(27, 85);
            Label51.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            Label51.Name = "Label51";
            Label51.Size = new System.Drawing.Size(61, 13);
            Label51.TabIndex = 319;
            Label51.Text = "Total Paid :";
            // 
            // Label49
            // 
            Label49.AutoSize = true;
            Label49.ForeColor = System.Drawing.Color.Black;
            Label49.Location = new System.Drawing.Point(28, 59);
            Label49.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            Label49.Name = "Label49";
            Label49.Size = new System.Drawing.Size(69, 13);
            Label49.TabIndex = 314;
            Label49.Text = "Grand Total :";
            // 
            // Label48
            // 
            Label48.AutoSize = true;
            Label48.ForeColor = System.Drawing.Color.Black;
            Label48.Location = new System.Drawing.Point(28, 34);
            Label48.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            Label48.Name = "Label48";
            Label48.Size = new System.Drawing.Size(52, 13);
            Label48.TabIndex = 313;
            Label48.Text = "Charges :";
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.Color.Transparent;
            this.groupBox4.Controls.Add(this.PDtxt);
            this.groupBox4.Controls.Add(label9);
            this.groupBox4.Controls.Add(this.TPtxt);
            this.groupBox4.Controls.Add(Label51);
            this.groupBox4.Controls.Add(this.chrgtxt);
            this.groupBox4.Controls.Add(this.GTtxt);
            this.groupBox4.Controls.Add(Label49);
            this.groupBox4.Controls.Add(Label48);
            this.groupBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.Location = new System.Drawing.Point(579, 239);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(285, 146);
            this.groupBox4.TabIndex = 320;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Overall";
            // 
            // PDtxt
            // 
            this.PDtxt.Location = new System.Drawing.Point(122, 111);
            this.PDtxt.Name = "PDtxt";
            this.PDtxt.ReadOnly = true;
            this.PDtxt.Size = new System.Drawing.Size(84, 20);
            this.PDtxt.TabIndex = 9;
            this.PDtxt.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // TPtxt
            // 
            this.TPtxt.Location = new System.Drawing.Point(122, 85);
            this.TPtxt.Name = "TPtxt";
            this.TPtxt.Size = new System.Drawing.Size(84, 20);
            this.TPtxt.TabIndex = 8;
            this.TPtxt.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // chrgtxt
            // 
            this.chrgtxt.Location = new System.Drawing.Point(122, 34);
            this.chrgtxt.Name = "chrgtxt";
            this.chrgtxt.ReadOnly = true;
            this.chrgtxt.Size = new System.Drawing.Size(84, 20);
            this.chrgtxt.TabIndex = 6;
            this.chrgtxt.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // GTtxt
            // 
            this.GTtxt.Location = new System.Drawing.Point(122, 59);
            this.GTtxt.Name = "GTtxt";
            this.GTtxt.ReadOnly = true;
            this.GTtxt.Size = new System.Drawing.Size(84, 20);
            this.GTtxt.TabIndex = 7;
            this.GTtxt.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(27, 208);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.Size = new System.Drawing.Size(522, 284);
            this.dataGridView1.TabIndex = 318;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // button_go
            // 
            this.button_go.Controls.Add(this.bunifuFlatButton5);
            this.button_go.Controls.Add(this.label7);
            this.button_go.Controls.Add(this.dTP3);
            this.button_go.Controls.Add(this.label6);
            this.button_go.Controls.Add(this.dTP2);
            this.button_go.Location = new System.Drawing.Point(21, 103);
            this.button_go.Name = "button_go";
            this.button_go.Size = new System.Drawing.Size(528, 84);
            this.button_go.TabIndex = 317;
            this.button_go.TabStop = false;
            this.button_go.Text = "Appointment Details";
            // 
            // bunifuFlatButton5
            // 
            this.bunifuFlatButton5.Activecolor = System.Drawing.Color.Teal;
            this.bunifuFlatButton5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(187)))), ((int)(((byte)(214)))));
            this.bunifuFlatButton5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton5.BorderRadius = 0;
            this.bunifuFlatButton5.ButtonText = "Go";
            this.bunifuFlatButton5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton5.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton5.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton5.Iconimage = null;
            this.bunifuFlatButton5.Iconimage_right = null;
            this.bunifuFlatButton5.Iconimage_right_Selected = null;
            this.bunifuFlatButton5.Iconimage_Selected = null;
            this.bunifuFlatButton5.IconMarginLeft = 0;
            this.bunifuFlatButton5.IconMarginRight = 0;
            this.bunifuFlatButton5.IconRightVisible = true;
            this.bunifuFlatButton5.IconRightZoom = 0D;
            this.bunifuFlatButton5.IconVisible = true;
            this.bunifuFlatButton5.IconZoom = 70D;
            this.bunifuFlatButton5.IsTab = false;
            this.bunifuFlatButton5.Location = new System.Drawing.Point(272, 48);
            this.bunifuFlatButton5.Name = "bunifuFlatButton5";
            this.bunifuFlatButton5.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(187)))), ((int)(((byte)(214)))));
            this.bunifuFlatButton5.OnHovercolor = System.Drawing.Color.Teal;
            this.bunifuFlatButton5.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton5.selected = false;
            this.bunifuFlatButton5.Size = new System.Drawing.Size(56, 21);
            this.bunifuFlatButton5.TabIndex = 324;
            this.bunifuFlatButton5.Text = "Go";
            this.bunifuFlatButton5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuFlatButton5.Textcolor = System.Drawing.Color.Black;
            this.bunifuFlatButton5.TextFont = new System.Drawing.Font("Lucida Console", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(158, 30);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(24, 15);
            this.label7.TabIndex = 7;
            this.label7.Text = "To:";
            // 
            // dTP3
            // 
            this.dTP3.CustomFormat = "dd/MMM/yyyy";
            this.dTP3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dTP3.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dTP3.Location = new System.Drawing.Point(161, 48);
            this.dTP3.Name = "dTP3";
            this.dTP3.Size = new System.Drawing.Size(108, 21);
            this.dTP3.TabIndex = 6;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(23, 30);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(39, 15);
            this.label6.TabIndex = 5;
            this.label6.Text = "From:";
            // 
            // dTP2
            // 
            this.dTP2.CustomFormat = "dd/MMM/yyyy";
            this.dTP2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dTP2.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dTP2.Location = new System.Drawing.Point(26, 48);
            this.dTP2.Name = "dTP2";
            this.dTP2.Size = new System.Drawing.Size(108, 21);
            this.dTP2.TabIndex = 4;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.textBox_patientname);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.button1);
            this.groupBox2.Controls.Add(this.textBox_patientid);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Location = new System.Drawing.Point(579, 132);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(285, 86);
            this.groupBox2.TabIndex = 316;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Patient Info";
            // 
            // textBox_patientname
            // 
            this.textBox_patientname.Location = new System.Drawing.Point(97, 53);
            this.textBox_patientname.Name = "textBox_patientname";
            this.textBox_patientname.Size = new System.Drawing.Size(179, 20);
            this.textBox_patientname.TabIndex = 9;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(6, 52);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(85, 15);
            this.label5.TabIndex = 8;
            this.label5.Text = "Patient Name:";
            // 
            // button1
            // 
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(211, 24);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(27, 21);
            this.button1.TabIndex = 7;
            this.button1.Text = "...";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // textBox_patientid
            // 
            this.textBox_patientid.Location = new System.Drawing.Point(97, 24);
            this.textBox_patientid.Name = "textBox_patientid";
            this.textBox_patientid.Size = new System.Drawing.Size(108, 20);
            this.textBox_patientid.TabIndex = 3;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(6, 25);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(63, 15);
            this.label4.TabIndex = 2;
            this.label4.Text = "Patient ID:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.textBox_invoicedate);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.textBox_invoiceno);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Location = new System.Drawing.Point(579, 24);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(285, 86);
            this.groupBox1.TabIndex = 315;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Invoice Info";
            // 
            // textBox_invoicedate
            // 
            this.textBox_invoicedate.CustomFormat = "dd/MMM/yyyy";
            this.textBox_invoicedate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_invoicedate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.textBox_invoicedate.Location = new System.Drawing.Point(89, 52);
            this.textBox_invoicedate.Name = "textBox_invoicedate";
            this.textBox_invoicedate.Size = new System.Drawing.Size(108, 21);
            this.textBox_invoicedate.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(6, 51);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(80, 15);
            this.label3.TabIndex = 2;
            this.label3.Text = " Invoice Date:";
            // 
            // textBox_invoiceno
            // 
            this.textBox_invoiceno.Location = new System.Drawing.Point(89, 25);
            this.textBox_invoiceno.Name = "textBox_invoiceno";
            this.textBox_invoiceno.Size = new System.Drawing.Size(108, 20);
            this.textBox_invoiceno.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(6, 25);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(76, 15);
            this.label2.TabIndex = 0;
            this.label2.Text = " Invoice No. :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Lucida Console", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(6, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(316, 37);
            this.label1.TabIndex = 314;
            this.label1.Text = "SALES INVOICE";
            // 
            // bunifuFlatButton6
            // 
            this.bunifuFlatButton6.Activecolor = System.Drawing.Color.Teal;
            this.bunifuFlatButton6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(187)))), ((int)(((byte)(214)))));
            this.bunifuFlatButton6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton6.BorderRadius = 0;
            this.bunifuFlatButton6.ButtonText = "Yearly";
            this.bunifuFlatButton6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton6.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton6.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton6.Iconimage = null;
            this.bunifuFlatButton6.Iconimage_right = null;
            this.bunifuFlatButton6.Iconimage_right_Selected = null;
            this.bunifuFlatButton6.Iconimage_Selected = null;
            this.bunifuFlatButton6.IconMarginLeft = 0;
            this.bunifuFlatButton6.IconMarginRight = 0;
            this.bunifuFlatButton6.IconRightVisible = true;
            this.bunifuFlatButton6.IconRightZoom = 0D;
            this.bunifuFlatButton6.IconVisible = true;
            this.bunifuFlatButton6.IconZoom = 70D;
            this.bunifuFlatButton6.IsTab = false;
            this.bunifuFlatButton6.Location = new System.Drawing.Point(276, 64);
            this.bunifuFlatButton6.Name = "bunifuFlatButton6";
            this.bunifuFlatButton6.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(187)))), ((int)(((byte)(214)))));
            this.bunifuFlatButton6.OnHovercolor = System.Drawing.Color.Teal;
            this.bunifuFlatButton6.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton6.selected = false;
            this.bunifuFlatButton6.Size = new System.Drawing.Size(76, 33);
            this.bunifuFlatButton6.TabIndex = 329;
            this.bunifuFlatButton6.Text = "Yearly";
            this.bunifuFlatButton6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuFlatButton6.Textcolor = System.Drawing.Color.Black;
            this.bunifuFlatButton6.TextFont = new System.Drawing.Font("Lucida Console", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // bunifuFlatButton4
            // 
            this.bunifuFlatButton4.Activecolor = System.Drawing.Color.Teal;
            this.bunifuFlatButton4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(187)))), ((int)(((byte)(214)))));
            this.bunifuFlatButton4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton4.BorderRadius = 0;
            this.bunifuFlatButton4.ButtonText = "Monthly";
            this.bunifuFlatButton4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton4.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton4.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton4.Iconimage = null;
            this.bunifuFlatButton4.Iconimage_right = null;
            this.bunifuFlatButton4.Iconimage_right_Selected = null;
            this.bunifuFlatButton4.Iconimage_Selected = null;
            this.bunifuFlatButton4.IconMarginLeft = 0;
            this.bunifuFlatButton4.IconMarginRight = 0;
            this.bunifuFlatButton4.IconRightVisible = true;
            this.bunifuFlatButton4.IconRightZoom = 0D;
            this.bunifuFlatButton4.IconVisible = true;
            this.bunifuFlatButton4.IconZoom = 70D;
            this.bunifuFlatButton4.IsTab = false;
            this.bunifuFlatButton4.Location = new System.Drawing.Point(376, 64);
            this.bunifuFlatButton4.Name = "bunifuFlatButton4";
            this.bunifuFlatButton4.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(187)))), ((int)(((byte)(214)))));
            this.bunifuFlatButton4.OnHovercolor = System.Drawing.Color.Teal;
            this.bunifuFlatButton4.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton4.selected = false;
            this.bunifuFlatButton4.Size = new System.Drawing.Size(76, 33);
            this.bunifuFlatButton4.TabIndex = 328;
            this.bunifuFlatButton4.Text = "Monthly";
            this.bunifuFlatButton4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuFlatButton4.Textcolor = System.Drawing.Color.Black;
            this.bunifuFlatButton4.TextFont = new System.Drawing.Font("Lucida Console", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // bunifuFlatButton3
            // 
            this.bunifuFlatButton3.Activecolor = System.Drawing.Color.Teal;
            this.bunifuFlatButton3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(187)))), ((int)(((byte)(214)))));
            this.bunifuFlatButton3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton3.BorderRadius = 0;
            this.bunifuFlatButton3.ButtonText = "Weekly";
            this.bunifuFlatButton3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton3.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton3.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton3.Iconimage = null;
            this.bunifuFlatButton3.Iconimage_right = null;
            this.bunifuFlatButton3.Iconimage_right_Selected = null;
            this.bunifuFlatButton3.Iconimage_Selected = null;
            this.bunifuFlatButton3.IconMarginLeft = 0;
            this.bunifuFlatButton3.IconMarginRight = 0;
            this.bunifuFlatButton3.IconRightVisible = true;
            this.bunifuFlatButton3.IconRightZoom = 0D;
            this.bunifuFlatButton3.IconVisible = true;
            this.bunifuFlatButton3.IconZoom = 70D;
            this.bunifuFlatButton3.IsTab = false;
            this.bunifuFlatButton3.Location = new System.Drawing.Point(473, 64);
            this.bunifuFlatButton3.Name = "bunifuFlatButton3";
            this.bunifuFlatButton3.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(187)))), ((int)(((byte)(214)))));
            this.bunifuFlatButton3.OnHovercolor = System.Drawing.Color.Teal;
            this.bunifuFlatButton3.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton3.selected = false;
            this.bunifuFlatButton3.Size = new System.Drawing.Size(76, 33);
            this.bunifuFlatButton3.TabIndex = 327;
            this.bunifuFlatButton3.Text = "Weekly";
            this.bunifuFlatButton3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuFlatButton3.Textcolor = System.Drawing.Color.Black;
            this.bunifuFlatButton3.TextFont = new System.Drawing.Font("Lucida Console", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // viewall_button
            // 
            this.viewall_button.Activecolor = System.Drawing.Color.Teal;
            this.viewall_button.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(187)))), ((int)(((byte)(214)))));
            this.viewall_button.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.viewall_button.BorderRadius = 0;
            this.viewall_button.ButtonText = "View All";
            this.viewall_button.Cursor = System.Windows.Forms.Cursors.Hand;
            this.viewall_button.DisabledColor = System.Drawing.Color.Gray;
            this.viewall_button.Iconcolor = System.Drawing.Color.Transparent;
            this.viewall_button.Iconimage = null;
            this.viewall_button.Iconimage_right = null;
            this.viewall_button.Iconimage_right_Selected = null;
            this.viewall_button.Iconimage_Selected = null;
            this.viewall_button.IconMarginLeft = 0;
            this.viewall_button.IconMarginRight = 0;
            this.viewall_button.IconRightVisible = true;
            this.viewall_button.IconRightZoom = 0D;
            this.viewall_button.IconVisible = true;
            this.viewall_button.IconZoom = 70D;
            this.viewall_button.IsTab = false;
            this.viewall_button.Location = new System.Drawing.Point(27, 64);
            this.viewall_button.Name = "viewall_button";
            this.viewall_button.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(187)))), ((int)(((byte)(214)))));
            this.viewall_button.OnHovercolor = System.Drawing.Color.Teal;
            this.viewall_button.OnHoverTextColor = System.Drawing.Color.White;
            this.viewall_button.selected = false;
            this.viewall_button.Size = new System.Drawing.Size(76, 33);
            this.viewall_button.TabIndex = 326;
            this.viewall_button.Text = "View All";
            this.viewall_button.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.viewall_button.Textcolor = System.Drawing.Color.Black;
            this.viewall_button.TextFont = new System.Drawing.Font("Lucida Console", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.viewall_button.Click += new System.EventHandler(this.viewall_button_Click);
            // 
            // USC_sales
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(233)))), ((int)(((byte)(233)))), ((int)(((byte)(233)))));
            this.Controls.Add(this.bunifuFlatButton6);
            this.Controls.Add(this.bunifuFlatButton4);
            this.Controls.Add(this.bunifuFlatButton3);
            this.Controls.Add(this.viewall_button);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.button_go);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label1);
            this.Name = "USC_sales";
            this.Size = new System.Drawing.Size(891, 552);
            this.Load += new System.EventHandler(this.USC_sales_Load);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.button_go.ResumeLayout(false);
            this.button_go.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.GroupBox groupBox4;
        internal System.Windows.Forms.TextBox PDtxt;
        internal System.Windows.Forms.TextBox TPtxt;
        internal System.Windows.Forms.TextBox chrgtxt;
        internal System.Windows.Forms.TextBox GTtxt;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.GroupBox button_go;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.DateTimePicker dTP3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DateTimePicker dTP2;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox textBox_patientname;
        private System.Windows.Forms.Label label5;
        internal System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox_patientid;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DateTimePicker textBox_invoicedate;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox_invoiceno;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton5;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton6;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton4;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton3;
        private Bunifu.Framework.UI.BunifuFlatButton viewall_button;
    }
}
